'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE,ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data
Imports System.Reflection

Namespace DotNetNuke

    Public Class SystemMessageController

        Public Function GetSystemMessages() As ArrayList

            Dim arrSystemMessages As New ArrayList

            ' get default messages
            Dim dr As IDataReader = DataProvider.Instance().GetSystemMessages()
            While dr.Read
                arrSystemMessages.Add(dr("MessageName"))
            End While
            dr.Close()

            Return arrSystemMessages

        End Function

        Public Function GetSystemMessage(ByVal PortalID As Integer, ByVal MessageName As String) As String

            Dim dr As IDataReader

            Dim strMessageValue As String = ""

            ' get default message
            dr = DataProvider.Instance().GetSystemMessage(Null.NullInteger, MessageName)
            If dr.Read Then
                strMessageValue = dr("MessageValue").ToString
            End If
            dr.Close()

            ' get portal override
            If Not Null.IsNull(PortalID) Then
                dr = DataProvider.Instance().GetSystemMessage(PortalID, MessageName)
                If dr.Read Then
                    strMessageValue = dr("MessageValue").ToString
                End If
                dr.Close()
            End If

            Return strMessageValue

        End Function

        Public Sub SetSystemMessage(ByVal PortalID As Integer, ByVal MessageName As String, ByVal MessageValue As String)

            Dim dr As IDataReader

            Dim strMessageValue As String = ""

            ' get default message
            dr = DataProvider.Instance().GetSystemMessage(Null.NullInteger, MessageName)
            If dr.Read Then
                strMessageValue = dr("MessageValue").ToString
            End If
            dr.Close()

            If Null.IsNull(PortalID) Then
                ' message was specified
                dr = DataProvider.Instance().GetSystemMessage(Null.NullInteger, MessageName)
                If dr.Read Then
                    ' update existing default message
                    DataProvider.Instance().UpdateSystemMessage(Null.NullInteger, MessageName, MessageValue)
                Else
                    ' add new default message
                    DataProvider.Instance().AddSystemMessage(Null.NullInteger, MessageName, MessageValue)
                End If
                dr.Close()
            Else
                ' updating portal override message
                If MessageValue <> strMessageValue Then
                    ' message is different from default
                    If MessageValue <> "" Then
                        ' message was specified
                        dr = DataProvider.Instance().GetSystemMessage(PortalID, MessageName)
                        If dr.Read Then
                            ' update existing portal override message
                            DataProvider.Instance().UpdateSystemMessage(PortalID, MessageName, MessageValue)
                        Else
                            ' add new portal override message
                            DataProvider.Instance().AddSystemMessage(PortalID, MessageName, MessageValue)
                        End If
                        dr.Close()
                    Else ' no message specified - delete portal override message
                        DataProvider.Instance().DeleteSystemMessage(PortalID, MessageName)
                    End If
                End If
            End If

        End Sub

        Public Function FormatSystemMessage(ByVal PortalID As Integer, ByVal MessageName As String, ByVal UserID As Integer) As String
            Return FormatSystemMessage(PortalID, MessageName, UserID, Nothing)
        End Function

        Public Function FormatSystemMessage(ByVal PortalID As Integer, ByVal MessageName As String, ByVal UserID As Integer, ByVal Custom As ArrayList) As String

            Dim strMessageValue As String = GetSystemMessage(PortalID, MessageName)

            If strMessageValue <> "" Then

                Dim strKey As String

                ' host values
                If InStr(1, strMessageValue, "Host:", CompareMethod.Text) <> 0 Then
                    Dim objHostSettings As Hashtable = PortalSettings.GetHostSettings()
                    For Each strKey In objHostSettings.Keys
                        If InStr(1, strMessageValue, "[Host:" & strKey & "]", CompareMethod.Text) <> 0 Then
                            strMessageValue = Replace(strMessageValue, "[Host:" & strKey & "]", objHostSettings(strKey).ToString, , , CompareMethod.Text)
                        End If
                    Next
                End If

                ' get portal values
                If InStr(1, strMessageValue, "Portal:", CompareMethod.Text) <> 0 Then
                    Dim objPortals As New PortalController
                    Dim objPortal As PortalInfo = objPortals.GetPortal(PortalID)
                    If Not objPortal Is Nothing Then
                        strMessageValue = PersonalizeSystemMessage(strMessageValue, "Portal:", objPortal, GetType(PortalInfo))
                    End If
                    strMessageValue = Replace(strMessageValue, "[Portal:URL]", GetPortalDomainName(objPortal.PortalAlias, HttpContext.Current.Request), , , CompareMethod.Text)
                End If

                If InStr(1, strMessageValue, "User:", CompareMethod.Text) <> 0 Then
                    ' get user values
                    Dim objUsers As New UserController
                    Dim objUser As UserInfo = objUsers.GetUser(PortalID, UserID)
                    If Not objUser Is Nothing Then
                        strMessageValue = PersonalizeSystemMessage(strMessageValue, "User:", objUser, GetType(UserInfo))
                    End If

                    ' get user profile values
                    If InStr(1, strMessageValue, "Profile:", CompareMethod.Text) <> 0 Then
                        Dim objProfiles As New PersonalizationController
                        Dim objProfile As PersonalizationInfo = objProfiles.LoadProfile(UserID, PortalID)
                        For Each strKey In objProfile.Profile.Keys
                            If InStr(1, strMessageValue, "[Profile:" & strKey & "]", CompareMethod.Text) <> 0 Then
                                strMessageValue = Replace(strMessageValue, "[Profile:" & strKey & "]", objProfile.Profile(strKey).ToString, , , CompareMethod.Text)
                            End If
                        Next
                    End If

                    strMessageValue = Replace(strMessageValue, "[User:VerificationCode]", PortalID.ToString & "-" & UserID.ToString, , , CompareMethod.Text)
                End If

                ' custom
                If InStr(1, strMessageValue, "Custom:", CompareMethod.Text) <> 0 Then
                    If Not Custom Is Nothing Then
                        Dim intIndex As Integer
                        For intIndex = 0 To Custom.Count - 1
                            strMessageValue = Replace(strMessageValue, "[Custom:" & intIndex.ToString & "]", Custom(intIndex).ToString, , , CompareMethod.Text)
                        Next intIndex
                    End If
                End If

                ' constants
                strMessageValue = Replace(strMessageValue, "[Date:Current]", Now().ToLongDateString, , , CompareMethod.Text)

            End If

            Return strMessageValue

        End Function

        Private Function PersonalizeSystemMessage(ByVal MessageValue As String, ByVal Prefix As String, ByVal objObject As Object, ByVal objType As Type) As String

            Dim intProperty As Integer
            Dim strPropertyName As String
            Dim strPropertyValue As String

            Dim objProperties As ArrayList = CBO.GetPropertyInfo(objType)

            For intProperty = 0 To objProperties.Count - 1
                strPropertyName = CType(objProperties(intProperty), PropertyInfo).Name
                If InStr(1, MessageValue, "[" & Prefix & strPropertyName & "]", CompareMethod.Text) <> 0 Then
                    strPropertyValue = CType(objProperties(intProperty), PropertyInfo).GetValue(objObject, Nothing).ToString()

                    ' special case for encrypted passwords
                    If (Prefix & strPropertyName = "User:Password") And Convert.ToString(Global.HostSettings("EncryptionKey")) <> "" Then
                        Dim objSecurity As New PortalSecurity
                        strPropertyValue = objSecurity.Decrypt(Global.HostSettings("EncryptionKey").ToString, strPropertyValue)
                    End If

                    MessageValue = Replace(MessageValue, "[" & Prefix & strPropertyName & "]", strPropertyValue, , , CompareMethod.Text)
                End If
            Next intProperty

            Return MessageValue

        End Function

    End Class

End Namespace
