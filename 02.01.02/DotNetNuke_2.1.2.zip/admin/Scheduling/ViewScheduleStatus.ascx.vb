'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Xml
Imports System.Configuration
Imports System.Net
Imports System.IO
Imports DotNetNuke.Scheduling

Namespace DotNetNuke.Scheduling

    Public Class ViewScheduleStatus

        Inherits DotNetNuke.PortalModuleControl
        Protected WithEvents dgScheduleQueue As System.Web.UI.WebControls.DataGrid
        Protected WithEvents pnlScheduleProcessing As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlScheduleQueue As System.Web.UI.WebControls.Panel
        Protected WithEvents lblStatus As System.Web.UI.WebControls.Label
        Protected WithEvents btnStart As System.Web.UI.WebControls.LinkButton
        Protected WithEvents btnStop As System.Web.UI.WebControls.LinkButton
        Protected WithEvents dgScheduleProcessing As System.Web.UI.WebControls.DataGrid
        Protected WithEvents lblMaxThreads As System.Web.UI.WebControls.Label
        Protected WithEvents lblActiveThreads As System.Web.UI.WebControls.Label
        Protected WithEvents lblFreeThreads As System.Web.UI.WebControls.Label
        Private Status As ScheduleStatus


#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            MyBase.Actions.Add(GetNextActionID, "Add Item to Schedule", "", URL:=EditURL(), secure:=SecurityAccessLevel.Admin, Visible:=True)

            InitializeComponent()


        End Sub

#End Region
        '*******************************************************
        '
        ' The Page_Load server event handler on this user control is used
        ' to populate the current site settings from the config system
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If SchedulingProvider.Instance.Enabled = True Then
                    If Not Page.IsPostBack Then
                        BindData()
                        BindStatus()
                    End If
                Else
                    Skin.AddModuleMessage(Me, "Scheduling is currently disabled due to the value of the 'enabled' setting in web.config.", Skins.ModuleMessage.ModuleMessageType.RedError)
                    lblStatus.Text = "Disabled"
                    btnStart.Enabled = False
                    btnStop.Enabled = False
                    lblFreeThreads.Text = "0"
                    lblActiveThreads.Text = "0"
                    lblMaxThreads.Text = "0"
                    pnlScheduleQueue.Visible = False
                    pnlScheduleProcessing.Visible = False
                End If
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub
        Private Sub BindStatus()
            Status = SchedulingProvider.Instance.GetScheduleStatus
            lblStatus.Text = Status.ToString()
            If Status = ScheduleStatus.STOPPED Then
                btnStart.Enabled = True
                btnStop.Enabled = False
            Else
                btnStart.Enabled = False
                btnStop.Enabled = True
            End If

        End Sub
        Private Sub BindData()

            lblFreeThreads.Text = SchedulingProvider.Instance.GetFreeThreadCount.ToString
            lblActiveThreads.Text = SchedulingProvider.Instance.GetActiveThreadCount.ToString
            lblMaxThreads.Text = SchedulingProvider.Instance.GetMaxThreadCount.ToString

            Dim arrScheduleQueue As Collection = SchedulingProvider.Instance.GetScheduleQueue
            If arrScheduleQueue.Count = 0 Then
                pnlScheduleQueue.Visible = False
            Else
                dgScheduleQueue.DataSource = arrScheduleQueue
                dgScheduleQueue.DataBind()
            End If

            Dim arrScheduleProcessing As Collection = SchedulingProvider.Instance.GetScheduleProcessing
            If arrScheduleProcessing.Count = 0 Then
                pnlScheduleProcessing.Visible = False
            Else
                dgScheduleProcessing.DataSource = arrScheduleProcessing
                dgScheduleProcessing.DataBind()
            End If
            If arrScheduleProcessing.Count = 0 And arrScheduleQueue.Count = 0 Then
                Skin.AddModuleMessage(Me, "There are no tasks in the queue and no tasks are processing.", Skins.ModuleMessage.ModuleMessageType.YellowWarning)
            End If

        End Sub

        Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
            Scheduling.SchedulingProvider.Instance.StartAndWaitForResponse()
            BindData()
            BindStatus()
        End Sub

        Private Sub btnStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStop.Click
            SchedulingProvider.Instance.Halt("Manually Stopped From Scheduler Status Page")
            BindData()
            BindStatus()
        End Sub

        Protected Function GetOverdueText(ByVal OverdueBy As Double) As String
            If OverdueBy > 0 Then
                Return OverdueBy.ToString
            Else
                Return ""
            End If
        End Function
    End Class

    Public Class ScheduleStatusSortRemainingTimeDescending
        Implements System.Collections.IComparer


        Public Function Compare(ByVal x As Object, ByVal y As Object) As Integer Implements System.Collections.IComparer.Compare
            Return CType(x, Scheduling.ScheduleHistoryItem).RemainingTime.CompareTo(CType(y, Scheduling.ScheduleHistoryItem).RemainingTime)
        End Function
    End Class

End Namespace