'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public Class ManageTabs
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents txtTabName As System.Web.UI.WebControls.TextBox
        Protected WithEvents valTabName As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents txtTitle As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtDescription As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtKeyWords As System.Web.UI.WebControls.TextBox
        Protected WithEvents cmdGoogle As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cboIcon As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cmdUpload As System.Web.UI.WebControls.HyperLink
        Protected WithEvents ctlSkin As SkinControl
        Protected WithEvents ctlContainer As SkinControl
        Protected WithEvents rowTemplate As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents cboTemplate As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cboTab As System.Web.UI.WebControls.DropDownList
        Protected WithEvents chkHidden As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkDisableLink As System.Web.UI.WebControls.CheckBox
        Protected WithEvents ctlAdminRoles As DotNetNuke.DualListControl
        Protected WithEvents ctlAuthRoles As DotNetNuke.DualListControl

        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

        Private strAction As String = ""

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this page is used
        ' to populate a tab's layout settings on the page
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim objModules As New ModuleController

                ' Obtain PortalSettings from Current Context
                Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

                ' Verify that the current user has access to edit this module
                If PortalSecurity.IsInRoles(_portalSettings.AdministratorRoleId.ToString) = False And PortalSecurity.IsInRoles(_portalSettings.ActiveTab.AdministratorRoles.ToString) = False Then
                    Response.Redirect(NavigateURL("Edit Access Denied"), True)
                End If

                If Not (Request.Params("action") Is Nothing) Then
                    strAction = Request.Params("action").ToLower
                End If

                If Page.IsPostBack = False Then

                    cmdDelete.Attributes.Add("onClick", "javascript:return confirm('Are You Sure You Wish To Delete This Item ?');")

                    ' load the list of files found in the upload directory
                    Dim LogoFileList As ArrayList = GetFileList(PortalId, glbImageFileTypes)
                    cboIcon.DataSource = LogoFileList
                    cboIcon.DataBind()
                    cmdUpload.NavigateUrl = NavigateURL("File Manager")

                    cboTab.DataSource = GetPortalTabs(_portalSettings.DesktopTabs, True)
                    cboTab.DataBind()

                    cboTemplate.DataSource = GetPortalTabs(_portalSettings.DesktopTabs, True, True)
                    cboTemplate.DataBind()

                    ' tab administrators can only manage their own tab
                    If PortalSecurity.IsInRoles(_portalSettings.AdministratorRoleId.ToString) = False Then
                        cboTab.Enabled = False
                    End If

                    ctlSkin.Width = "300px"
                    ctlSkin.SkinRoot = SkinInfo.RootSkin

                    ctlContainer.Width = "300px"
                    ctlContainer.SkinRoot = SkinInfo.RootContainer

                    Select Case strAction
                        Case "" ' add
                            InitializeTab()
                            cmdDelete.Visible = False
                            cmdGoogle.Visible = False
                        Case "edit"
                            BindData()
                            rowTemplate.Visible = False
                        Case "copy"
                            BindData()
                            If Not cboTemplate.Items.FindByValue(TabId.ToString) Is Nothing Then
                                cboTemplate.Items.FindByValue(TabId.ToString).Selected = True
                            End If
                            cmdDelete.Visible = False
                            cmdGoogle.Visible = False
                    End Select

                End If

            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        '*******************************************************
        '
        ' The cmdCancel_Click() handler cancels operation and redirects
        ' user to admin tab of their portal.
        '
        '*******************************************************

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)

            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        Sub InitializeTab()

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Populate Tab Names, etc.
            txtTabName.Text = ""
            txtTitle.Text = ""
            txtDescription.Text = ""
            txtKeyWords.Text = ""

            If _portalSettings.ActiveTab.ParentId <> _portalSettings.AdminTabId Then
                If Not cboTab.Items.FindByValue(TabId.ToString) Is Nothing Then
                    cboTab.Items.FindByValue(TabId.ToString).Selected = True
                End If
            End If

            ' hide the upload new file link until the tab has been saved
            cmdUpload.Visible = False

            chkHidden.Checked = False
            chkDisableLink.Checked = False

            ' declare roles
            Dim arrAvailableAuthRoles As New ArrayList
            Dim arrAssignedAuthRoles As New ArrayList
            Dim arrAvailableAdminRoles As New ArrayList
            Dim arrAssignedAdminRoles As New ArrayList

            ' add an entry for All Users for Auth Roles
            arrAssignedAuthRoles.Add(New ListItem("All Users", glbRoleAllUsers))
            ' add an entry for Unauthenticated Users for Auth Roles
            arrAvailableAuthRoles.Add(New ListItem("Unauthenticated Users", glbRoleUnauthUser))
            ' add an entry for All Users for Admin Roles
            arrAvailableAdminRoles.Add(New ListItem("All Users", glbRoleAllUsers))

            ' process portal roles
            Dim objRoles As New RoleController
            Dim objRole As RoleInfo
            Dim arrRoles As ArrayList = objRoles.GetPortalRoles(PortalId)

            For Each objRole In arrRoles
                Dim objListItem As New ListItem

                objListItem.Value = objRole.RoleID.ToString
                objListItem.Text = objRole.RoleName

                If objRole.RoleID = _portalSettings.AdministratorRoleId Or PortalSettings.ActiveTab.AdministratorRoles.IndexOf(objRole.RoleID & ";") <> -1 Then
                    arrAssignedAuthRoles.Add(objListItem)
                    arrAssignedAdminRoles.Add(objListItem)
                Else
                    arrAvailableAuthRoles.Add(objListItem)
                    arrAvailableAdminRoles.Add(objListItem)
                End If
            Next

            ' assign to duallist controls
            ctlAuthRoles.Available = arrAvailableAuthRoles
            ctlAuthRoles.Assigned = arrAssignedAuthRoles
            ctlAdminRoles.Available = arrAvailableAdminRoles
            ctlAdminRoles.Assigned = arrAssignedAdminRoles

        End Sub

        Private Sub cmdUpdate_Click(ByVal Sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                Dim intTabId As Integer = SaveTabData(strAction)

                Response.Redirect("~/" & glbDefaultPage & "?tabid=" & intTabId.ToString, True)

            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdDelete_Click(ByVal Sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
            Try

                Select Case TabId
                    Case PortalSettings.AdminTabId, PortalSettings.HomeTabId, PortalSettings.LoginTabId, PortalSettings.UserTabId
                        ' can not delete 
                    Case Else
                        Dim objTabs As New TabController

                        Dim objTab As TabInfo = objTabs.GetTab(TabId)
                        If Not objTab Is Nothing Then
                            objTab.IsDeleted = True
                            objTabs.UpdateTab(objTab)
                            Dim objEventLog As New Logging.EventLogController
                            objEventLog.AddLog(objTab, PortalSettings, UserId, "", Logging.EventLogInfo.EventLogType.TAB_SENT_TO_RECYCLE_BIN)
                        End If

                        Response.Redirect(GetPortalDomainName(PortalAlias, Request), True)
                End Select

            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        '*******************************************************
        '
        ' The SaveTabData helper method is used to persist the
        ' current tab settings to the database.
        '
        '*******************************************************

        Function SaveTabData(ByVal strAction As String) As Integer

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(Context.Items("PortalSettings"), PortalSettings)

            Dim objEventLog As New Logging.EventLogController
            ' Construct AdministratorRoles String
            Dim strAdministratorRoles As String = ""

            Dim item As ListItem
            Dim strRole As String

            For Each item In ctlAdminRoles.Assigned
                strAdministratorRoles += item.Value & ";"
            Next item
            ' add portal admin role if not specified
            If strAdministratorRoles.IndexOf(PortalSettings.AdministratorRoleId.ToString & ";") = -1 Then
                strAdministratorRoles += PortalSettings.AdministratorRoleId.ToString & ";"
            End If

            ' Construct AuthorizedRoles String
            Dim strAuthorizedRoles As String = ""

            For Each item In ctlAuthRoles.Assigned
                strAuthorizedRoles += item.Value & ";"
            Next item
            ' add portal admin role if not specified
            If strAuthorizedRoles.IndexOf(PortalSettings.AdministratorRoleId.ToString & ";") = -1 Then
                strAuthorizedRoles += PortalSettings.AdministratorRoleId.ToString & ";"
            End If

            Dim strIcon As String = ""
            If Not cboIcon.SelectedItem Is Nothing Then
                strIcon = cboIcon.SelectedItem.Value
            End If

            Dim objTabs As New TabController

            Dim objTab As New TabInfo
            objTab = CType(CBO.InitializeObject(objTab, GetType(TabInfo)), TabInfo)

            objTab.TabID = TabId
            objTab.PortalID = PortalId
            objTab.TabName = txtTabName.Text
            objTab.Title = txtTitle.Text
            objTab.Description = txtDescription.Text
            objTab.KeyWords = txtKeyWords.Text
            objTab.AuthorizedRoles = strAuthorizedRoles
            objTab.IsVisible = (Not chkHidden.Checked)
            objTab.DisableLink = chkDisableLink.Checked
            objTab.ParentId = Int32.Parse(cboTab.SelectedItem.Value)
            objTab.IconFile = strIcon
            objTab.AdministratorRoles = strAdministratorRoles
            objTab.IsDeleted = False

            If strAction = "edit" Then

                ' trap circular tab reference
                If objTab.TabID <> Int32.Parse(cboTab.SelectedItem.Value) Then
                    objTabs.UpdateTab(objTab)
                    objEventLog.AddLog(objTab, _portalSettings, UserId, "", Logging.EventLogInfo.EventLogType.TAB_UPDATED)
                End If

            Else ' add

                objTab.TabID = objTabs.AddTab(objTab)
                objEventLog.AddLog(objTab, _portalSettings, UserId, "", Logging.EventLogInfo.EventLogType.TAB_CREATED)

                If Int32.Parse(cboTemplate.SelectedItem.Value) <> -1 Then
                    ' copy all modules to new tab
                    objTabs.CopyTab(Int32.Parse(cboTemplate.SelectedItem.Value), objTab.TabID)
                End If
            End If

            Dim objSkins As New SkinController
            objSkins.SetSkin(SkinInfo.RootSkin, Null.NullInteger, objTab.TabID, Null.NullInteger, False, ctlSkin.SkinType, ctlSkin.SkinName, ctlSkin.SkinSrc)
            objSkins.SetSkin(SkinInfo.RootContainer, Null.NullInteger, objTab.TabID, Null.NullInteger, False, ctlContainer.SkinType, ctlContainer.SkinName, ctlContainer.SkinSrc)

            Return objTab.TabID

        End Function

        '*******************************************************
        '
        ' The BindData helper method is used to update the tab's
        ' layout panes with the current configuration information
        '
        '*******************************************************
        Sub BindData()

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(Context.Items("PortalSettings"), PortalSettings)

            Dim objTab As TabSettings = _portalSettings.ActiveTab

            If strAction <> "copy" Then
                txtTabName.Text = objTab.TabName
                txtTitle.Text = objTab.Title
                txtDescription.Text = objTab.Description
                txtKeyWords.Text = objTab.KeyWords
            End If

            If cboIcon.Items.Contains(New ListItem(objTab.IconFile)) Then
                cboIcon.Items.FindByText(objTab.IconFile).Selected = True
            End If

            If Not cboTab.Items.FindByValue(objTab.ParentId.ToString) Is Nothing Then
                cboTab.Items.FindByValue(objTab.ParentId.ToString).Selected = True
            End If
            chkHidden.Checked = (Not objTab.IsVisible)
            chkDisableLink.Checked = objTab.DisableLink

            ' declare roles
            Dim arrAvailableAuthRoles As New ArrayList
            Dim arrAvailableAdminRoles As New ArrayList

            ' add an entry of All Users for Auth Roles
            arrAvailableAuthRoles.Add(New ListItem("All Users", glbRoleAllUsers))
            ' add an entry of Unauthenticated Users for Auth Roles
            arrAvailableAuthRoles.Add(New ListItem("Unauthenticated Users", glbRoleUnauthUser))
            ' add an entry of All Users for Admin Roles
            arrAvailableAdminRoles.Add(New ListItem("All Users", glbRoleAllUsers))

            ' process portal roles
            Dim objRoles As New RoleController
            Dim objRole As RoleInfo
            Dim arrRoles As ArrayList = objRoles.GetPortalRoles(PortalId)
            For Each objRole In arrRoles
                arrAvailableAuthRoles.Add(New ListItem(objRole.RoleName, objRole.RoleID.ToString))
            Next
            For Each objRole In arrRoles
                arrAvailableAdminRoles.Add(New ListItem(objRole.RoleName, objRole.RoleID.ToString))
            Next

            Dim strRole As String
            Dim objListItem As ListItem

            ' populate authorized roles
            Dim arrAssignedAuthRoles As New ArrayList
            Dim arrAuthRoles As Array = Split(objTab.AuthorizedRoles, ";")
            For Each strRole In arrAuthRoles
                If strRole <> "" Then
                    For Each objListItem In arrAvailableAuthRoles
                        If objListItem.Value = strRole Then
                            arrAssignedAuthRoles.Add(objListItem)
                            arrAvailableAuthRoles.Remove(objListItem)
                            Exit For
                        End If
                    Next
                End If
            Next
            ctlAuthRoles.Available = arrAvailableAuthRoles
            ctlAuthRoles.Assigned = arrAssignedAuthRoles

            ' populate admin roles
            Dim arrAssignedAdminRoles As New ArrayList
            Dim arrAdminRoles As Array = Split(objTab.AdministratorRoles, ";")
            For Each strRole In arrAdminRoles
                If strRole <> "" Then
                    For Each objListItem In arrAvailableAdminRoles
                        If objListItem.Value = strRole Then
                            arrAssignedAdminRoles.Add(objListItem)
                            arrAvailableAdminRoles.Remove(objListItem)
                            Exit For
                        End If
                    Next
                End If
            Next
            ctlAdminRoles.Available = arrAvailableAdminRoles
            ctlAdminRoles.Assigned = arrAssignedAdminRoles

            Dim objSkins As New SkinController
            Dim objSkin As SkinInfo

            objSkin = objSkins.GetSkin(SkinInfo.RootSkin, PortalId, objTab.TabId, Null.NullInteger, False)
            If Not objSkin Is Nothing Then
                If objSkin.TabId = objTab.TabId Then
                    ctlSkin.SkinType = objSkin.SkinType
                    ctlSkin.SkinName = objSkin.SkinName
                    ctlSkin.SkinSrc = objSkin.SkinSrc
                End If
            End If

            objSkin = objSkins.GetSkin(SkinInfo.RootContainer, PortalId, objTab.TabId, Null.NullInteger, False)
            If Not objSkin Is Nothing Then
                If objSkin.TabId = objTab.TabId Then
                    ctlContainer.SkinType = objSkin.SkinType
                    ctlContainer.SkinName = objSkin.SkinName
                    ctlContainer.SkinSrc = objSkin.SkinSrc
                End If
            End If

        End Sub

        Private Sub cmdGoogle_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdGoogle.Click

            Try
                Dim strURL As String = ""
                Dim strComments As String = ""

                strComments += txtTitle.Text
                If txtDescription.Text <> "" Then
                    strComments += " " & txtDescription.Text
                End If
                If txtKeyWords.Text <> "" Then
                    strComments += " " & txtKeyWords.Text
                End If

                strURL += "http://www.google.com/addurl?q=" & HTTPPOSTEncode(AddHTTP(GetDomainName(Request)) & "/" & glbDefaultPage & "?tabid=" & TabId.ToString)
                strURL += "&dq=" & HTTPPOSTEncode(strComments)
                strURL += "&submit=Add+URL"

                Response.Redirect(strURL, True)

            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub

    End Class

End Namespace
