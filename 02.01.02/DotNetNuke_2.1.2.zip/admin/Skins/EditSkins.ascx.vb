'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System.IO
Imports System.Configuration
Imports System.Drawing
Imports System.Drawing.Imaging

Namespace DotNetNuke

    Public Class EditSkins

        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
        Protected WithEvents chkHost As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkSite As System.Web.UI.WebControls.CheckBox
        Protected WithEvents cboSkins As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cboContainers As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cmdRestore As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lblGallery As System.Web.UI.WebControls.Label
        Protected WithEvents pnlSkin As System.Web.UI.WebControls.Panel
        Protected WithEvents chkPortal As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkAdmin As System.Web.UI.WebControls.CheckBox
        Protected WithEvents cmdParse As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lblParse As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
 
                If Page.IsPostBack = False Then

                    lblMessage.Text = "<b>NOTE:</b>&nbsp;&nbsp;You must use the File Manager to upload your Skin or Container package."

                    cmdDelete.Attributes.Add("onClick", "javascript:return confirm('Are You Sure You Wish To Delete This Item ?');")

                    LoadSkins()
                    LoadContainers()

                    If Not Request.QueryString("action") Is Nothing Then
                        Dim strRoot As String = Request.QueryString("Root")
                        Dim strType As String = Request.QueryString("Type")
                        Dim strName As String = Request.QueryString("Name")
                        Dim strSrc As String = Request.QueryString("Src")

                        Select Case Request.QueryString("action")
                            Case "apply"
                                Dim objSkins As New SkinController
                                If strRoot = SkinInfo.RootSkin Then
                                    If chkPortal.Checked Then
                                        objSkins.SetSkin(SkinInfo.RootSkin, PortalId, Null.NullInteger, Null.NullInteger, False, strType, strName, strSrc)
                                    End If
                                    If chkAdmin.Checked Then
                                        objSkins.SetSkin(SkinInfo.RootSkin, PortalId, Null.NullInteger, Null.NullInteger, True, strType, strName, strSrc)
                                    End If
                                End If
                                If strRoot = SkinInfo.RootContainer Then
                                    If chkPortal.Checked Then
                                        objSkins.SetSkin(SkinInfo.RootContainer, PortalId, Null.NullInteger, Null.NullInteger, False, strType, strName, strSrc)
                                    End If
                                    If chkAdmin.Checked Then
                                        objSkins.SetSkin(SkinInfo.RootContainer, PortalId, Null.NullInteger, Null.NullInteger, True, strType, strName, strSrc)
                                    End If
                                End If
                                DataCache.ClearCoreCache(CoreCacheType.Portal, PortalId, True)
                                Response.Redirect(Request.RawUrl.Replace("&action=apply", ""))
                            Case "delete"
                                Select Case strType
                                    Case "G" ' global
                                        File.Delete(Request.MapPath(Global.HostPath & strRoot & "/" & strName & "/" & strSrc))
                                    Case "L" ' local
                                        File.Delete(Request.MapPath(PortalSettings.UploadDirectory & strRoot & "/" & strName & "/" & strSrc))
                                End Select
                                LoadSkins()
                                LoadContainers()
                        End Select
                    End If
                End If

            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cboSkins_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboSkins.SelectedIndexChanged

            ShowSkins()

        End Sub

        Private Sub cboContainers_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboContainers.SelectedIndexChanged

            ShowContainers()

        End Sub

        Private Sub ShowSkins()

            cboContainers.ClearSelection()

            Dim strGallery As String = ""

            If cboSkins.SelectedIndex > 0 Then
                strGallery += ProcessSkins(cboSkins.SelectedItem.Value)
                strGallery += ProcessContainers(cboSkins.SelectedItem.Value.Replace("\" & SkinInfo.RootSkin & "\", "\" & SkinInfo.RootContainer & "\"))
                pnlSkin.Visible = True
                If UserId = PortalSettings.SuperUserId Or cboSkins.SelectedItem.Value.IndexOf(Global.HostPath.Replace("/", "\")) = -1 Then
                    cmdParse.Visible = True
                    cmdDelete.Visible = True
                Else
                    cmdParse.Visible = False
                    cmdDelete.Visible = False
                End If

            Else
                pnlSkin.Visible = False
            End If

            lblGallery.Text = strGallery

        End Sub

        Private Sub ShowContainers()

            cboSkins.ClearSelection()

            Dim strGallery As String = ""

            If cboContainers.SelectedIndex > 0 Then
                strGallery = ProcessContainers(cboContainers.SelectedItem.Value)
                pnlSkin.Visible = True
                If UserId = PortalSettings.SuperUserId Or cboContainers.SelectedItem.Value.IndexOf(Global.HostPath.Replace("/", "\")) = -1 Then
                    cmdParse.Visible = True
                    cmdDelete.Visible = True
                Else
                    cmdParse.Visible = False
                    cmdDelete.Visible = False
                End If
            Else
                pnlSkin.Visible = False
            End If

            lblGallery.Text = strGallery

        End Sub

        Private Sub LoadSkins()

            Dim strRoot As String
            Dim strFolder As String
            Dim arrFolders As String()
            Dim strName As String

            cboSkins.Items.Clear()
            cboSkins.Items.Add("<Not Specified>")

            ' load host skins
            If chkHost.Checked Then
                strRoot = Request.MapPath(Global.HostPath & SkinInfo.RootSkin)
                If Directory.Exists(strRoot) Then
                    arrFolders = Directory.GetDirectories(strRoot)
                    For Each strFolder In arrFolders
                        strName = Mid(strFolder, InStrRev(strFolder, "\") + 1)
                        If strName <> "_default" Then
                            cboSkins.Items.Add(New ListItem(strName, strFolder))
                        End If
                    Next
                End If
            End If

            ' load portal skins
            If chkSite.Checked Then
                strRoot = Request.MapPath(PortalSettings.UploadDirectory & SkinInfo.RootSkin)
                If Directory.Exists(strRoot) Then
                    arrFolders = Directory.GetDirectories(strRoot)
                    For Each strFolder In arrFolders
                        strName = Mid(strFolder, InStrRev(strFolder, "\") + 1)
                        cboSkins.Items.Add(New ListItem(strName, strFolder))
                    Next
                End If
            End If

            If Not Page.IsPostBack Then
                If Not Request.QueryString("Name") Is Nothing Then
                    Dim strURL As String = Request.MapPath(GetSkinPath(Convert.ToString(Request.QueryString("Type")), SkinInfo.RootSkin, Convert.ToString(Request.QueryString("Name"))))
                    If Not cboSkins.Items.FindByValue(strURL) Is Nothing Then
                        cboSkins.Items.FindByValue(strURL).Selected = True
                        ShowSkins()
                    End If
                End If
            End If

        End Sub

        Private Sub LoadContainers()

            Dim strRoot As String
            Dim strFolder As String
            Dim arrFolders As String()
            Dim strName As String

            cboContainers.Items.Clear()
            cboContainers.Items.Add("<Not Specified>")

            ' load host containers
            If chkHost.Checked Then
                strRoot = Request.MapPath(Global.HostPath & SkinInfo.RootContainer)
                If Directory.Exists(strRoot) Then
                    arrFolders = Directory.GetDirectories(strRoot)
                    For Each strFolder In arrFolders
                        strName = Mid(strFolder, InStrRev(strFolder, "\") + 1)
                        strRoot = strFolder.Replace("\" & SkinInfo.RootContainer & "\", "\" & SkinInfo.RootSkin & "\")
                        If Directory.Exists(strRoot) = False Then
                            cboContainers.Items.Add(New ListItem(strName, strFolder))
                        End If
                    Next
                End If
            End If

            ' load portal containers
            If chkSite.Checked Then
                strRoot = Request.MapPath(PortalSettings.UploadDirectory & SkinInfo.RootContainer)
                If Directory.Exists(strRoot) Then
                    arrFolders = Directory.GetDirectories(strRoot)
                    For Each strFolder In arrFolders
                        strName = Mid(strFolder, InStrRev(strFolder, "\") + 1)
                        strRoot = strFolder.Replace("\" & SkinInfo.RootContainer & "\", "\" & SkinInfo.RootSkin & "\")
                        If Directory.Exists(strRoot) = False Then
                            cboContainers.Items.Add(New ListItem(strName, strFolder))
                        End If
                    Next
                End If
            End If

            If Not Page.IsPostBack Then
                If Not Request.QueryString("Name") Is Nothing Then
                    Dim strURL As String = Request.MapPath(GetSkinPath(Convert.ToString(Request.QueryString("Type")), Convert.ToString(Request.QueryString("Root")), Convert.ToString(Request.QueryString("Name"))))
                    If Not cboContainers.Items.FindByValue(strURL) Is Nothing Then
                        cboContainers.Items.FindByValue(strURL).Selected = True
                        ShowContainers()
                    End If
                End If
            End If

        End Sub

        Private Function ProcessSkins(ByVal strFolder As String) As String

            Dim strFile As String
            Dim arrFiles As String()
            Dim strGallery As String = ""
            Dim strSkinType As String = ""
            Dim strURL As String

            If Directory.Exists(strFolder) Then
                If strFolder.IndexOf(Global.HostPath.Replace("/", "\")) <> -1 Then
                    strSkinType = "G"
                Else
                    strSkinType = "L"
                End If

                strGallery = "<table border=""1"" cellspacing=""0"" cellpadding=""2"" width=""500"">"
                strGallery += "<tr><td align=""center"" bgcolor=""#CCCCCC"" class=""Head"">Skins</td></tr>"
                strGallery += "<tr><td align=""center"">"
                strGallery += "<table border=""0"" cellspacing=""4"" cellpadding=""4""><tr>"

                arrFiles = Directory.GetFiles(strFolder, "*.ascx")
                If arrFiles.Length = 0 Then
                    strGallery += "<td align=""center"" valign=""bottom"" class=""NormalBold"">No Skin Files Exist In Folder</td>"
                End If
                strFolder = Mid(strFolder, InStrRev(strFolder, "\") + 1)
                For Each strFile In arrFiles
                    strFile = strFile.ToLower
                    ' name
                    strGallery += "<td align=""center"" valign=""bottom"" class=""NormalBold"">"
                    strGallery += Path.GetFileNameWithoutExtension(strFile) & "<br>"
                    ' thumbnail
                    If File.Exists(strFile.Replace(".ascx", ".jpg")) Then
                        strURL = strFile.Substring(strFile.IndexOf("portals\"))
                        strGallery += "<a href=""" & strURL.Replace(".ascx", ".jpg") & """ target=""_new""><img src=""" & CreateThumbnail(strFile.Replace(".ascx", ".jpg")) & """ border=""1""></a>"
                    Else
                        strGallery += "<img src=""images/thumbnail.jpg"" border=""1"">"
                    End If
                    ' options 
                    strGallery += "<br><a class=""CommandButton"" href=""" & Global.ApplicationPath & "/" & glbDefaultPage & "?SkinType=" & strSkinType & "&SkinName=" & strFolder & "&SkinSrc=" & Path.GetFileName(strFile) & """ target=""_new"">Preview</a>"
                    strGallery += "&nbsp;&nbsp;|&nbsp;&nbsp;"
                    strGallery += "<a class=""CommandButton"" href=""" & Global.ApplicationPath & Globals.ApplicationURL.Replace("~", "") & "&Root=" & SkinInfo.RootSkin & "&Type=" & strSkinType & "&Name=" & strFolder & "&Src=" & Path.GetFileName(strFile) & "&action=apply"">Apply</a>"
                    If UserId = PortalSettings.SuperUserId Or strSkinType = "L" Then
                        strGallery += "&nbsp;&nbsp;|&nbsp;&nbsp;"
                        strGallery += "<a class=""CommandButton"" href=""" & Global.ApplicationPath & Globals.ApplicationURL.Replace("~", "") & "&Root=" & SkinInfo.RootSkin & "&Type=" & strSkinType & "&Name=" & strFolder & "&Src=" & Path.GetFileName(strFile) & "&action=delete"">Delete</a>"
                    End If
                    strGallery += "</td>"
                Next

                strGallery += "</tr></table><br>"
                strGallery += "</table><br>"
            End If

            Return strGallery

        End Function

        Private Function ProcessContainers(ByVal strFolder As String) As String

            Dim strFile As String
            Dim arrFiles As String()
            Dim strGallery As String = ""
            Dim strContainerType As String = ""
            Dim strURL As String

            If Directory.Exists(strFolder) Then
                If strFolder.IndexOf(Global.HostPath.Replace("/", "\")) <> -1 Then
                    strContainerType = "G"
                Else
                    strContainerType = "L"
                End If

                strGallery = "<table border=""1"" cellspacing=""0"" cellpadding=""2"" width=""500"">"
                strGallery += "<tr><td align=""center"" bgcolor=""#CCCCCC"" class=""Head"">Containers</td></tr>"
                strGallery += "<tr><td align=""center"">"
                strGallery += "<table border=""0"" cellspacing=""4"" cellpadding=""4""><tr>"

                arrFiles = Directory.GetFiles(strFolder, "*.ascx")
                If arrFiles.Length = 0 Then
                    strGallery += "<td align=""center"" valign=""bottom"" class=""NormalBold"">No Container Files Exist In Folder</td>"
                End If
                strFolder = Mid(strFolder, InStrRev(strFolder, "\") + 1)
                For Each strFile In arrFiles
                    strFile = strFile.ToLower
                    ' name
                    strGallery += "<td align=""center"" valign=""bottom"" class=""NormalBold"">"
                    strGallery += Path.GetFileNameWithoutExtension(strFile) & "<br>"
                    ' thumbnail
                    If File.Exists(strFile.Replace(".ascx", ".jpg")) Then
                        strURL = strFile.Substring(strFile.IndexOf("portals\"))
                        strGallery += "<a href=""" & strURL.Replace(".ascx", ".jpg") & """ target=""_new""><img src=""" & CreateThumbnail(strFile.Replace(".ascx", ".jpg")) & """ border=""1""></a>"
                    Else
                        strGallery += "<img src=""images/thumbnail.jpg"" border=""1"">"
                    End If
                    ' options 
                    strGallery += "<br><a class=""CommandButton"" href=""" & Global.ApplicationPath & "/" & glbDefaultPage & "?ContainerType=" & strContainerType & "&ContainerName=" & strFolder & "&ContainerSrc=" & Path.GetFileName(strFile) & """ target=""_new"">Preview</a>"
                    strGallery += "&nbsp;&nbsp;|&nbsp;&nbsp;"
                    strGallery += "<a class=""CommandButton"" href=""" & Global.ApplicationPath & Globals.ApplicationURL.Replace("~", "") & "&Root=" & SkinInfo.RootContainer & "&Type=" & strContainerType & "&Name=" & strFolder & "&Src=" & Path.GetFileName(strFile) & "&action=apply"">Apply</a>"
                    If UserId = PortalSettings.SuperUserId Or strContainerType = "L" Then
                        strGallery += "&nbsp;&nbsp;|&nbsp;&nbsp;"
                        strGallery += "<a class=""CommandButton"" href=""" & Global.ApplicationPath & Globals.ApplicationURL.Replace("~", "") & "&Root=" & SkinInfo.RootContainer & "&Type=" & strContainerType & "&Name=" & strFolder & "&Src=" & Path.GetFileName(strFile) & "&action=delete"">Delete</a>"
                    End If
                    strGallery += "</td>"
                Next

                strGallery += "</tr></table><br>"
                strGallery += "</table><br>"
            End If

            Return strGallery

        End Function

        Private Function CreateThumbnail(ByVal strImage As String) As String

            Dim blnCreate As Boolean = True

            Dim strThumbnail As String = strImage.Replace(Path.GetFileName(strImage), "thumbnail_" & Path.GetFileName(strImage))

            ' check if image has changed
            If File.Exists(strThumbnail) Then
                Dim d1 As Date = File.GetLastWriteTime(strThumbnail)
                Dim d2 As Date = File.GetLastWriteTime(strImage)
                If File.GetLastWriteTime(strThumbnail) = File.GetLastWriteTime(strImage) Then
                    blnCreate = False
                End If
            End If

            If blnCreate Then

                Dim dblScale As Double
                Dim intHeight As Integer
                Dim intWidth As Integer

                Dim intSize As Integer = 150 ' size of the thumbnail 

                Dim objImage As Image
                Try
                    objImage = objImage.FromFile(strImage)

                    ' scale the image to prevent distortion
                    If objImage.Height > objImage.Width Then
                        'The height was larger, so scale the width 
                        dblScale = intSize / objImage.Height
                        intHeight = intSize
                        intWidth = CInt(objImage.Width * dblScale)
                    Else
                        'The width was larger, so scale the height 
                        dblScale = intSize / objImage.Width
                        intWidth = intSize
                        intHeight = CInt(objImage.Height * dblScale)
                    End If

                    ' create the thumbnail image
                    Dim objThumbnail As Image
                    objThumbnail = objImage.GetThumbnailImage(intWidth, intHeight, Nothing, IntPtr.Zero)

                    ' delete the old file ( if it exists )
                    If File.Exists(strThumbnail) Then
                        File.Delete(strThumbnail)
                    End If

                    ' save the thumbnail image 
                    objThumbnail.Save(strThumbnail, objImage.RawFormat)

                    ' set the file attributes
                    File.SetAttributes(strThumbnail, FileAttributes.Normal)
                    File.SetLastWriteTime(strThumbnail, File.GetLastWriteTime(strImage))

                    ' tidy up
                    objImage.Dispose()
                    objThumbnail.Dispose()

                Catch

                    ' problem creating thumbnail

                End Try

            End If

            strThumbnail = strThumbnail.Substring(strThumbnail.IndexOf("portals\"))

            ' return thumbnail filename
            Return strThumbnail

        End Function

        Private Sub chkHost_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkHost.CheckedChanged

            LoadSkins()
            LoadContainers()

            ShowSkins()
            ShowContainers()

        End Sub

        Private Sub chkSite_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkSite.CheckedChanged

            LoadSkins()
            LoadContainers()

            ShowSkins()
            ShowContainers()

        End Sub

        Private Sub cmdRestore_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRestore.Click

            Dim objSkins As New SkinController
            If chkPortal.Checked Then
                objSkins.SetSkin(SkinInfo.RootSkin, PortalId, Null.NullInteger, Null.NullInteger, False, "", "", "")
                objSkins.SetSkin(SkinInfo.RootContainer, PortalId, Null.NullInteger, Null.NullInteger, False, "", "", "")
            End If
            If chkAdmin.Checked Then
                objSkins.SetSkin(SkinInfo.RootSkin, PortalId, Null.NullInteger, Null.NullInteger, True, "", "", "")
                objSkins.SetSkin(SkinInfo.RootContainer, PortalId, Null.NullInteger, Null.NullInteger, True, "", "", "")
            End If
            DataCache.ClearCoreCache(CoreCacheType.Portal, PortalId, True)
            Response.Redirect(Request.RawUrl)

        End Sub

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDelete.Click

            If cboSkins.SelectedIndex > 0 Then
                If Directory.Exists(cboSkins.SelectedItem.Value) Then
                    Globals.DeleteFolderRecursive(cboSkins.SelectedItem.Value)
                End If
                If Directory.Exists(cboSkins.SelectedItem.Value.Replace("\" & SkinInfo.RootSkin & "\", "\" & SkinInfo.RootContainer & "\")) Then
                    Globals.DeleteFolderRecursive(cboSkins.SelectedItem.Value.Replace("\" & SkinInfo.RootSkin & "\", "\" & SkinInfo.RootContainer & "\"))
                End If
            End If

            If cboContainers.SelectedIndex > 0 Then
                If Directory.Exists(cboContainers.SelectedItem.Value) Then
                    Globals.DeleteFolderRecursive(cboContainers.SelectedItem.Value)
                End If
            End If

            LoadSkins()
            LoadContainers()

            ShowSkins()
            ShowContainers()

        End Sub

        Private Sub cmdParse_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdParse.Click

            Dim strFolder As String
            Dim strType As String
            Dim strRoot As String
            Dim strName As String

            Dim strParse As String = ""

            If cboSkins.SelectedIndex > 0 Then
                strFolder = cboSkins.SelectedItem.Value
                If strFolder.IndexOf(Global.HostPath.Replace("/", "\")) <> -1 Then
                    strType = "G"
                Else
                    strType = "L"
                End If
                strRoot = SkinInfo.RootSkin
                strName = cboSkins.SelectedItem.Text
                strParse += ParseSkinPackage(strType, strRoot, strName, strFolder)

                strFolder = cboSkins.SelectedItem.Value.Replace("\" & SkinInfo.RootSkin & "\", "\" & SkinInfo.RootContainer & "\")
                strRoot = SkinInfo.RootContainer
                strParse += ParseSkinPackage(strType, strRoot, strName, strFolder)
            End If

            If cboContainers.SelectedIndex > 0 Then
                strFolder = cboContainers.SelectedItem.Value
                If strFolder.IndexOf(Global.HostPath.Replace("/", "\")) <> -1 Then
                    strType = "G"
                Else
                    strType = "L"
                End If
                strRoot = SkinInfo.RootContainer
                strName = cboContainers.SelectedItem.Text
                strParse += ParseSkinPackage(strType, strRoot, strName, strFolder)
            End If

            lblParse.Text = strParse

            If cboSkins.SelectedIndex > 0 Then
                ShowSkins()
            End If
            If cboContainers.SelectedIndex > 0 Then
                ShowContainers()
            End If

        End Sub

        Private Function ParseSkinPackage(ByVal strType As String, ByVal strRoot As String, ByVal strName As String, ByVal strFolder As String) As String

            Dim strRootPath As String
            Select Case strType
                Case "G" ' global
                    strRootPath = Global.HostPath
                Case "L" ' local
                    strRootPath = PortalSettings.UploadDirectory
            End Select

            Dim objSkinFiles As New SkinFileProcessor(strRootPath, strRoot, strName)
            Dim arrSkinFiles As New ArrayList

            Dim strFile As String
            Dim arrFiles As String()

            If Directory.Exists(strFolder) Then
                arrFiles = Directory.GetFiles(strFolder)
                For Each strFile In arrFiles
                    Select Case Path.GetExtension(strFile)
                        Case ".htm", ".html"
                            arrSkinFiles.Add(strFile)
                    End Select
                Next
            End If

            Return objSkinFiles.ProcessList(arrSkinFiles)

        End Function

        Private Function GetSkinPath(ByVal Type As String, ByVal Root As String, ByVal Name As String) As String

            Dim strPath As String

            Select Case Type
                Case "G" ' global
                    strPath = Global.HostPath & Root & "/" & Name
                Case "L" ' local
                    strPath = PortalSettings.UploadDirectory & Root & "/" & Name
            End Select

            Return strPath

        End Function

    End Class

End Namespace