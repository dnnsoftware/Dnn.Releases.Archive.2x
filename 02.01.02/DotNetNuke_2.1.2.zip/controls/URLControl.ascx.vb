'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System.IO

Namespace DotNetNuke

    Public Class UrlControl

        Inherits System.Web.UI.UserControl

        Protected WithEvents optUrl As System.Web.UI.WebControls.RadioButtonList
        Protected WithEvents cboUrl As System.Web.UI.WebControls.DropDownList
        Protected WithEvents txtUrl As System.Web.UI.WebControls.TextBox
        Protected WithEvents cmdUrl As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton
        Protected WithEvents chkLog As System.Web.UI.WebControls.CheckBox

        Private _Width As String = ""
        Private _ShowUrls As Boolean = True
        Private _ShowTabs As Boolean = True
        Private _ShowFiles As Boolean = True
        Private _ShowLog As Boolean = True
        Private _Url As String = ""
        Private _UrlType As String = ""
        Private _FileFilter As String = ""

        ' public properties
        Public Property Width() As String
            Get
                Width = Convert.ToString(ViewState("SkinControlWidth"))
            End Get
            Set(ByVal Value As String)
                _Width = Value
            End Set
        End Property

        Public WriteOnly Property ShowUrls() As Boolean
            Set(ByVal Value As Boolean)
                _ShowUrls = Value
            End Set
        End Property

        Public WriteOnly Property ShowTabs() As Boolean
            Set(ByVal Value As Boolean)
                _ShowTabs = Value
            End Set
        End Property

        Public WriteOnly Property ShowFiles() As Boolean
            Set(ByVal Value As Boolean)
                _ShowFiles = Value
            End Set
        End Property

        Public WriteOnly Property ShowLog() As Boolean
            Set(ByVal Value As Boolean)
                _ShowLog = Value
            End Set
        End Property

        Public Property Url() As String
            Get
                ' Obtain PortalSettings from Current Context
                Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

                Url = ""

                Select Case optUrl.SelectedItem.Value
                    Case "U"
                        If cboUrl.Visible Then
                            If Not cboUrl.SelectedItem Is Nothing Then
                                Url = cboUrl.SelectedItem.Value
                            End If
                        Else
                            Url = AddHTTP(txtUrl.Text)
                        End If
                    Case "T"
                        If Not cboUrl.SelectedItem Is Nothing Then
                            Url = cboUrl.SelectedItem.Value
                        End If
                    Case "F"
                        If Not cboUrl.SelectedItem Is Nothing Then
                            Url = cboUrl.SelectedItem.Value
                        End If
                End Select
            End Get
            Set(ByVal Value As String)
                _Url = Value
            End Set
        End Property

        Public Property UrlType() As String
            Get
                UrlType = optUrl.SelectedItem.Value
            End Get
            Set(ByVal Value As String)
                _UrlType = Value
            End Set
        End Property

        Public WriteOnly Property FileFilter() As String
            Set(ByVal Value As String)
                _FileFilter = Value
            End Set
        End Property

        Public ReadOnly Property Log() As Boolean
            Get
                If chkLog.Visible = True Then
                    Log = chkLog.Checked
                Else
                    Log = False
                End If
            End Get
        End Property

#Region " Web Form Designer Generated Code "


        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this page is used
        ' to populate the role information for the page
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                If Not Page.IsPostBack Then

                    cmdDelete.Attributes.Add("onClick", "javascript:return confirm('Are You Sure You Wish To Delete This Item ?');")

                    ' set width of control
                    If _Width <> "" Then
                        cboUrl.Width = System.Web.UI.WebControls.Unit.Parse(_Width)
                        txtUrl.Width = System.Web.UI.WebControls.Unit.Parse(_Width)
                    End If

                    If _ShowUrls Then
                        optUrl.Items.Add(New ListItem("Url", "U"))
                    End If
                    If _ShowTabs Then
                        optUrl.Items.Add(New ListItem("Tab", "T"))
                    End If
                    If _ShowFiles Then
                        optUrl.Items.Add(New ListItem("File", "F"))
                    End If
                    chkLog.Visible = _ShowLog

                    ShowControls()

                    ' save persistent values
                    ViewState("SkinControlWidth") = _Width

                End If

            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub optUrl_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles optUrl.SelectedIndexChanged
            ShowControls()
        End Sub

        Private Sub cmdUrl_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUrl.Click

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Select Case cmdUrl.Text
                Case "Add"
                    cboUrl.Visible = False
                    txtUrl.Visible = True
                    cmdUrl.Text = "Select"
                    cmdDelete.Visible = False
                Case "Select"
                    cboUrl.Visible = True
                    txtUrl.Visible = False
                    cmdUrl.Text = "Add"
                    cmdDelete.Visible = PortalSecurity.IsInRole(_portalSettings.AdministratorRoleId.ToString)
                Case "Upload"
                    Response.Redirect(ApplicationURL() & "&ctl=File Manager", True)
            End Select

        End Sub

        Private Sub ShowControls()

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim objUrls As New UrlController

            ' set url type
            If optUrl.SelectedItem Is Nothing Then
                If _Url <> "" Then
                    Dim objUrlTracking As UrlTrackingInfo = objUrls.GetUrlTracking(_portalSettings.PortalId, _Url)
                    If Not objUrlTracking Is Nothing Then
                        optUrl.Items.FindByValue(objUrlTracking.UrlType).Selected = True
                        chkLog.Checked = objUrlTracking.LogActivity
                    Else ' the url does not exist in the tracking table
                        If _Url.IndexOf("://") = -1 And _Url.IndexOf("~") = -1 And _Url.IndexOf("\\") = -1 Then
                            If IsNumeric(_Url) Then
                                optUrl.Items.FindByValue("T").Selected = True
                            Else
                                optUrl.Items.FindByValue("F").Selected = True
                            End If
                        Else
                            optUrl.Items.FindByValue("U").Selected = True
                        End If
                        chkLog.Checked = False
                    End If
                Else
                    If _UrlType <> "" Then
                        If Not optUrl.Items.FindByValue(_UrlType) Is Nothing Then
                            optUrl.Items.FindByValue(_UrlType).Selected = True
                        Else
                            optUrl.Items(0).Selected = True
                        End If
                    Else
                        optUrl.Items(0).Selected = True
                    End If
                    chkLog.Checked = False
                End If
            End If

            ' clear listitems
            cboUrl.Items.Clear()

            ' load listitems
            Select Case optUrl.SelectedItem.Value
                Case "U" ' Url
                    cboUrl.Visible = False
                    txtUrl.Visible = True
                    txtUrl.Text = _Url
                    cmdUrl.Text = "Select"
                    cmdUrl.Visible = True
                    cmdDelete.Visible = False
                    cboUrl.DataSource = objUrls.GetUrls(_portalSettings.PortalId)
                    cboUrl.DataValueField = "Url"
                    cboUrl.DataTextField = "Url"
                Case "T" ' tab
                    cboUrl.Visible = True
                    txtUrl.Visible = False
                    cmdUrl.Visible = False
                    cboUrl.DataSource = GetPortalTabs(_portalSettings.DesktopTabs, False, True)
                    cboUrl.DataValueField = "TabId"
                    cboUrl.DataTextField = "TabName"
                    cmdDelete.Visible = False
                Case "F" ' file
                    cboUrl.Visible = True
                    txtUrl.Visible = False
                    cmdUrl.Text = "Upload"
                    cmdUrl.Visible = True
                    cboUrl.DataSource = GetFileList(_portalSettings.PortalId, _FileFilter, False)
                    cboUrl.DataValueField = "Value"
                    cboUrl.DataTextField = "Text"
                    cmdDelete.Visible = False
            End Select

            cboUrl.DataBind()

            If Not cboUrl.Items.FindByValue(_Url) Is Nothing Then
                cboUrl.Items.FindByValue(_Url).Selected = True
            End If

        End Sub

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
            If Not cboUrl.SelectedItem Is Nothing Then
                ' Obtain PortalSettings from Current Context
                Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

                Dim objUrls As New UrlController
                objUrls.DeleteUrl(_portalSettings.PortalId, cboUrl.SelectedItem.Value)

                ShowControls()
            End If
        End Sub

    End Class

End Namespace
