Imports System
Imports System.Web.UI


Namespace DotNetNuke.Web.UI.WebControls

    ''' <summary>
    ''' ITreeNodeWriter interface declaration. All the objects which want to implement
    ''' a writer class for the TreeNode should inherit from this interface.
    ''' </summary>
    Friend Interface ITreeNodeWriter
        ''' <summary>
        ''' When implemented renders an Node inside the tree.
        ''' </summary>
        ''' <param name="writer"></param>
        ''' <param name="Node"></param>
        Sub RenderNode(ByVal writer As HtmlTextWriter, ByVal Node As TreeNode)
    End Interface 'ITreeNodeWriter

    ''' <summary>
    ''' IDNNTreeWriter interface declaration. All the objects which want to implement
    ''' a writer class for the DNNTree should inherit from this interface.
    ''' </summary>
    Friend Interface IDNNTreeWriter
        ''' <summary>
        ''' When implemented renders the tree.
        ''' </summary>
        ''' <param name="writer"></param>
        ''' <param name="tree"></param>
        Sub RenderTree(ByVal writer As HtmlTextWriter, ByVal tree As DNNTree)
    End Interface
End Namespace