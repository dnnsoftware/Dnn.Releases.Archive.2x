Imports System
Imports System.Web.UI
Imports System.Web.UI.WebControls
Namespace DotNetNuke.Web.UI.WebControls

    Friend Class DNNTreeWriter
        Inherits WebControl
        Implements IDNNTreeWriter
        Private _tree As DNNTree

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub New()
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="writer"></param>
        ''' <param name="tree"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub RenderTree(ByVal writer As HtmlTextWriter, ByVal tree As DnnTree) Implements IDNNTreeWriter.RenderTree
            _tree = tree
            RenderControl(writer)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="writer"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Overloads Overrides Sub RenderContents(ByVal writer As HtmlTextWriter)
            writer.AddAttribute(HtmlTextWriterAttribute.Width, "100%")
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "DNNTree")
            writer.RenderBeginTag(HtmlTextWriterTag.Div)
            RenderChildren(writer)
            writer.RenderEndTag()
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="writer"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Overloads Overrides Sub RenderChildren(ByVal writer As HtmlTextWriter)
            Dim TempNode As TreeNode
            For Each TempNode In _tree.TreeNodes
                TempNode.Render(writer)
            Next
        End Sub

    End Class
End Namespace
