Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Diagnostics
Imports System.Xml

Namespace DotNetNuke.Web.UI.WebControls

    Public Class DNNTreeBuilder
        Inherits ControlBuilder

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="tagName"></param>
        ''' <param name="attribs"></param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overloads Overrides Function GetChildControlType(ByVal tagName As String, ByVal attribs As IDictionary) As Type
            If tagName.ToUpper.EndsWith("TreeNode") Then
                Return GetType(TreeNode)
            End If
            Return Nothing
        End Function

    End Class

    <ControlBuilderAttribute(GetType(DNNTreeBuilder)), _
    DefaultProperty("Nodes"), _
    ToolboxData("<{0}:DNNTree runat=server></{0}:DNNTree>")> _
    Public Class DnnTree
        Inherits WebControl
        Implements IPostBackEventHandler

        Public Class DNNTreeEventArgs
            Inherits EventArgs
            Private _node As TreeNode

            ''' -----------------------------------------------------------------------------
            ''' <summary>
            ''' 
            ''' </summary>
            ''' <param name="node"></param>
            ''' <remarks>
            ''' </remarks>
            ''' <history>
            ''' 	[jbrinkman]	5/6/2004	Created
            ''' </history>
            ''' -----------------------------------------------------------------------------
            Public Sub New(ByVal node As TreeNode)
                Me._node = node
            End Sub

            ''' -----------------------------------------------------------------------------
            ''' <summary>
            ''' 
            ''' </summary>
            ''' <returns></returns>
            ''' <remarks>
            ''' </remarks>
            ''' <history>
            ''' 	[jbrinkman]	5/6/2004	Created
            ''' </history>
            ''' -----------------------------------------------------------------------------
            Public ReadOnly Property Node() As TreeNode
                Get
                    Return _node
                End Get
            End Property
        End Class

        Public Delegate Sub DNNTreeEventHandler(ByVal source As Object, ByVal e As DNNTreeEventArgs)

        Event Expand As DNNTreeEventHandler

        Event Collapse As DNNTreeEventHandler
        Private _root As TreeNode
        Private _images As NodeImageCollection

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Browsable(True), PersistenceMode(PersistenceMode.InnerProperty)> _
                Public ReadOnly Property TreeNodes() As TreeNodeCollection
            Get
                Return Root.TreeNodes
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), DefaultValue(0), PersistenceMode(PersistenceMode.Attribute)> _
                Public Property IndentWidth() As Integer
            Get
                Dim Indent As Object = ViewState("IndentWidth")
                Return CType(Indent, Integer)
            End Get
            Set(ByVal Value As Integer)
                ViewState("IndentWidth") = Value
            End Set
        End Property


        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), DefaultValue(""), PersistenceMode(PersistenceMode.Attribute)> _
                Public Property CollapsedNodeImage() As String
            Get
                Dim _url As Object = ViewState("CollapsedNodeImage")
                Return CType(_url, String)
            End Get
            Set(ByVal Value As String)
                ViewState("CollapsedNodeImage") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), DefaultValue(""), PersistenceMode(PersistenceMode.Attribute)> _
                Public Property ExpandedNodeImage() As String
            Get
                Dim _url As Object = ViewState("ExpandedNodeImage")
                Return CType(_url, String)
            End Get
            Set(ByVal Value As String)
                ViewState("ExpandedNodeImage") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), DefaultValue(False), PersistenceMode(PersistenceMode.Attribute)> _
                Public Property CheckBoxes() As Boolean
            Get
                Dim _checkBoxes As Object = ViewState("CheckBoxes")
                Return CType(_checkBoxes, Boolean)
            End Get
            Set(ByVal Value As Boolean)
                ViewState("CheckBoxes") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), DefaultValue("")> _
                Public Property Target() As String
            Get
                Dim _target As String = CType(ViewState("Target"), String)
                Return (_target)
            End Get
            Set(ByVal Value As String)
                ViewState("Target") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Browsable(True), PersistenceMode(PersistenceMode.InnerProperty)> _
                Public ReadOnly Property ImageList() As NodeImageCollection
            Get
                If _images Is Nothing Then
                    _images = New NodeImageCollection
                    If IsTrackingViewState Then
                        CType(_images, IStateManager).TrackViewState()
                    End If
                End If
                Return _images
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), DefaultValue(""), PersistenceMode(PersistenceMode.Attribute)> _
                Public Property DefaultNodeCssClass() As String
            Get
                Dim _defaultNodeCssClass As String = CType(ViewState("DefaultNodeCssClass"), String)
                Return (_defaultNodeCssClass)
            End Get
            Set(ByVal Value As String)
                ViewState("DefaultNodeCssClass") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), DefaultValue(""), PersistenceMode(PersistenceMode.Attribute)> _
                Public Property DefaultNodeCssClassOver() As String
            Get
                Dim _defaultNodeCssClassOver As String = CType(ViewState("DefaultNodeCssClassOver"), String)
                Return (_defaultNodeCssClassOver)
            End Get
            Set(ByVal Value As String)
                ViewState("DefaultNodeCssClassOver") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private ReadOnly Property Root() As TreeNode
            Get
                If _root Is Nothing Then
                    _root = New TreeNode("TreeRoot")
                    _root.SetDNNTree(Me)
                    _root.SetNodeID(UniqueID)
                    _root.SetLevel(-1)
                    _root.ViewState("IsExpanded") = True
                End If
                Return _root
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private ReadOnly Property TreeWriter() As IDNNTreeWriter
            Get
                Return New DNNTreeWriter
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub New()
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="eventArgument"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overridable Sub RaisePostBackEvent(ByVal eventArgument As String) Implements IPostBackEventHandler.RaisePostBackEvent
            Dim Node As TreeNode = Root.FindNode(eventArgument)
            If Not (Node Is Nothing) Then
                If Node.IsExpanded Then
                    Node.Collapse()
                Else
                    Node.Expand()
                End If
            End If
            Return
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overridable Sub OnExpand(ByVal e As DNNTreeEventArgs)
            RaiseEvent Expand(Me, e)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overridable Sub OnCollapse(ByVal e As DNNTreeEventArgs)
            RaiseEvent Collapse(Me, e)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="writer"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Overloads Overrides Sub Render(ByVal writer As HtmlTextWriter)
            TreeWriter.RenderTree(writer, Me)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Overloads Overrides Sub OnInit(ByVal e As EventArgs)
            MyBase.OnInit(e)
            ConfigureParsedNodes(Root)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Overloads Overrides Function SaveViewState() As Object
            Dim _baseState As Object = MyBase.SaveViewState
            Dim _treeState As Object = CType(Root, IStateManager).SaveViewState
            Dim _imagesState As Object = CType(ImageList, IStateManager).SaveViewState
            Dim _newState(3 - 1) As Object
            _newState(0) = _baseState
            _newState(1) = _treeState
            _newState(2) = _imagesState
            Return _newState
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="state"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Overloads Overrides Sub LoadViewState(ByVal state As Object)
            If Not (state Is Nothing) Then
                Dim _newState As Object() = CType(state, Object())
                If Not (_newState(0) Is Nothing) Then
                    MyBase.LoadViewState(_newState(0))
                End If
                If Not (_newState(1) Is Nothing) Then
                    CType(Root, IStateManager).LoadViewState(_newState(1))
                End If
                If Not (_newState(2) Is Nothing) Then
                    CType(ImageList, IStateManager).LoadViewState(_newState(2))
                End If
            End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Overloads Overrides Sub TrackViewState()
            MyBase.TrackViewState()
            CType(Root, IStateManager).TrackViewState()
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="Node"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub ConfigureParsedNodes(ByVal Node As TreeNode)
            Dim TempNode As TreeNode
            For Each TempNode In Node.TreeNodes
                TempNode.SetParent(Node)
                TempNode.SetDNNTree(Me)
                TempNode.SetLevel(Node.Level + 1)
                TempNode.NodeType = eNodeType.designTimeNode
                ConfigureParsedNodes(TempNode)
            Next
        End Sub
    End Class
End Namespace
