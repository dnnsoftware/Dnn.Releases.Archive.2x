Imports System
Imports System.IO
Imports System.Web
Imports System.Reflection

Namespace DotNetNuke

    Public MustInherit Class HtmlEditorProvider
        Private Const [ProviderType] As String = "htmlEditor"

        'use to access rich text control
        Public HtmlEditorControl As System.Web.UI.Control

        Public Shared Function Instance() As HtmlEditorProvider
            Dim objConstructor As ConstructorInfo

            If objConstructor Is Nothing Then

                ' Get the name of the provider
                Dim objProviderConfiguration As ProviderConfiguration = ProviderConfiguration.GetProviderConfiguration([ProviderType])

                ' The assembly should be in \bin or GAC, so we simply need to get an instance of the type
                Try

                    ' Get the typename of the Core DataProvider from web.config
                    Dim strTypeName As String = CType(objProviderConfiguration.Providers(objProviderConfiguration.DefaultProvider), Provider).Type

                    ' Use reflection to store the constructor of the class that implements DataProvider
                    Dim t As Type = Type.GetType(strTypeName, True)
                    objConstructor = t.GetConstructor(System.Type.EmptyTypes)

                Catch e As Exception

                    ' Could not load the provider - this is likely due to binary compatibility issues 

                End Try
            End If

            Return CType(objConstructor.Invoke(Nothing), HtmlEditorProvider)
        End Function

        'These properties will work through the provider to access the properties of the actual 
        'rich text control
        Public MustOverride Property Text() As String
        Public MustOverride Property Width() As System.Web.UI.WebControls.Unit
        Public MustOverride Property Height() As System.Web.UI.WebControls.Unit

    End Class

End Namespace
