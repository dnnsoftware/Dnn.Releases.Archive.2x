'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Reflection


Namespace DotNetNuke.Scheduling


    '''''''''''''''''''''''''''''''''''''''''''''''''''
    'Set up our delegates so we can track
    'and react to events of the scheduler clients
    '''''''''''''''''''''''''''''''''''''''''''''''''''
    Public Delegate Sub WorkStarted(ByRef objSchedulerClient As SchedulerClient)
    Public Delegate Sub WorkProgressing(ByRef objSchedulerClient As SchedulerClient)
    Public Delegate Sub WorkCompleted(ByRef objSchedulerClient As SchedulerClient)
    Public Delegate Sub WorkErrored(ByRef objSchedulerClient As SchedulerClient, ByRef objException As Exception)


    Public MustInherit Class SchedulingProvider
        Private _providerConfiguration As ProviderConfiguration = ProviderConfiguration.GetProviderConfiguration(ProviderType)
        Private _providerPath As String
        Private Shared _Debug As Boolean
        Private Shared _MaxThreads As Integer
        Private Shared _Enabled As Boolean
        Public EventName As Scheduling.EventName

        Public ReadOnly Property ProviderPath() As String
            Get
                Return _providerPath
            End Get
        End Property

        Public Shared ReadOnly Property Debug() As Boolean
            Get
                Return _debug
            End Get
        End Property

        Public Shared ReadOnly Property MaxThreads() As Integer
            Get
                Return _MaxThreads
            End Get
        End Property
        Public Shared ReadOnly Property Enabled() As Boolean
            Get
                Return _Enabled
            End Get
        End Property

        Public Sub New()
            Dim objProvider As Provider = CType(_providerConfiguration.Providers(_providerConfiguration.DefaultProvider), Provider)

            _providerPath = objProvider.Attributes("providerPath")
            If Not objProvider.Attributes("enabled") Is Nothing Then
                _Enabled = Convert.ToBoolean(objProvider.Attributes("enabled"))
            End If
            If Not objProvider.Attributes("debug") Is Nothing Then
                _Debug = Convert.ToBoolean(objProvider.Attributes("debug"))
            End If
            If Not objProvider.Attributes("maxThreads") Is Nothing Then
                _MaxThreads = Convert.ToInt32(objProvider.Attributes("maxThreads"))
            Else
                _MaxThreads = 10
            End If

        End Sub
        '--------------------------------------------------------------
        ' provider constants - eliminates need for Reflection later
        '--------------------------------------------------------------
        Private Const [ProviderType] As String = "scheduling"



        Public Shared Function Instance() As SchedulingProvider

            Dim strCacheKey As String = [ProviderType] & "provider"

            '--------------------------------------------------------------
            ' Use the cache because the reflection used later is expensive
            '--------------------------------------------------------------
            Dim objConstructor As ConstructorInfo = CType(DataCache.GetCache(strCacheKey), ConstructorInfo)

            If objConstructor Is Nothing Then

                '--------------------------------------------------------------
                ' Get the name of the provider
                '--------------------------------------------------------------
                Dim objProviderConfiguration As ProviderConfiguration = ProviderConfiguration.GetProviderConfiguration([ProviderType])

                '--------------------------------------------------------------
                ' The assembly should be in \bin or GAC, so we simply need to
                ' get an instance of the type
                '--------------------------------------------------------------
                Try

                    '--------------------------------------------------------------
                    ' Get the typename of the LoggingProvider from web.config
                    '--------------------------------------------------------------
                    Dim strTypeName As String = CType(objProviderConfiguration.Providers(objProviderConfiguration.DefaultProvider), Provider).Type

                    '--------------------------------------------------------------
                    ' Use reflection to store the constructor of the class that implements LoggingProvider
                    '--------------------------------------------------------------
                    Dim t As Type = Type.GetType(strTypeName, True)
                    objConstructor = t.GetConstructor(System.Type.EmptyTypes)

                    '--------------------------------------------------------------
                    ' Insert the type into the cache
                    '--------------------------------------------------------------
                    DataCache.SetCache(strCacheKey, objConstructor)

                Catch e As Exception
                    '--------------------------------------------------------------
                    ' Could not load the provider - this is likely due to binary compatibility issues 
                    '--------------------------------------------------------------
                End Try
            End If

            Return CType(objConstructor.Invoke(Nothing), SchedulingProvider)

        End Function

        Public MustOverride Function GetProviderPath() As String

        Public MustOverride Sub Start()
        Public MustOverride Sub ReStart(ByVal SourceOfRestart As String)
        Public MustOverride Sub StartAndWaitForResponse()
        Public MustOverride Sub Halt(ByVal SourceOfHalt As String)
        Public MustOverride Sub PurgeScheduleHistory()
        Public MustOverride Sub RunEventSchedule(ByVal objEventName As Scheduling.EventName)
        Public MustOverride Function GetSchedule() As ArrayList
        Public MustOverride Function GetSchedule(ByVal ScheduleID As Integer) As ScheduleItem
        Public MustOverride Function GetScheduleHistory(ByVal ScheduleID As Integer) As ArrayList

        Public MustOverride Function GetScheduleQueue() As Collection
        Public MustOverride Function GetScheduleProcessing() As Collection

        Public MustOverride Function GetFreeThreadCount() As Integer
        Public MustOverride Function GetActiveThreadCount() As Integer
        Public MustOverride Function GetMaxThreadCount() As Integer


        Public MustOverride Function GetScheduleStatus() As ScheduleStatus

        Public MustOverride Function AddSchedule(ByVal objScheduleItem As ScheduleItem) As Integer
        Public MustOverride Sub UpdateSchedule(ByVal objScheduleItem As ScheduleItem)
        Public MustOverride Sub DeleteSchedule(ByVal objScheduleItem As ScheduleItem)


    End Class



End Namespace
