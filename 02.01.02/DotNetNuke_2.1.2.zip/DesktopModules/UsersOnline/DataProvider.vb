Imports System
Imports System.Collections
Imports System.Reflection
Imports System.Web.Caching

Namespace YourCompanyName.UsersOnline

    Public MustInherit Class DataProvider

        ' provider constants - eliminates need for Reflection later
        Private Const [ProviderType] As String = "data" ' maps to <sectionGroup> in web.config 
        Private Const [NameSpace] As String = "YourCompanyName.UsersOnline" ' project namespace
        Private Const [AssemblyName] As String = "YourCompanyName.UsersOnline" ' project assemblyname

        Public Shared Shadows Function Instance() As DataProvider

            Dim strCacheKey As String = [NameSpace] & "." & [ProviderType] & "provider"

            ' Use the cache because the reflection used later is expensive
            Dim objConstructor As ConstructorInfo = CType(DotNetNuke.DataCache.GetCache(strCacheKey), ConstructorInfo)

            If objConstructor Is Nothing Then
                ' Get the provider configuration based on the type
                Dim objProviderConfiguration As DotNetNuke.ProviderConfiguration = DotNetNuke.ProviderConfiguration.GetProviderConfiguration([ProviderType])

                ' The assembly should be in \bin or GAC, so we simply need to get an instance of the type
                Try

                    ' Override the typename if a ProviderName is specified ( this allows the application to load a different DataProvider assembly for custom modules )
                    Dim strTypeName As String = [NameSpace] & "." & objProviderConfiguration.DefaultProvider & ", " & [AssemblyName] & "." & objProviderConfiguration.DefaultProvider


                    ' Use reflection to store the constructor of the class that implements DataProvider
                    Dim t As Type = Type.GetType(strTypeName, True)
                    objConstructor = t.GetConstructor(System.Type.EmptyTypes)

                    ' Insert the type into the cache
                    DotNetNuke.DataCache.SetCache(strCacheKey, objConstructor)

                Catch e As Exception

                    ' Could not load the provider - this is likely due to binary compatibility issues 

                End Try
            End If

            Return CType(objConstructor.Invoke(Nothing), DataProvider)

        End Function

        ' all core methods defined below
        Public MustOverride Function GetStatistics(ByVal PortalId As Integer) As Hashtable
        Public MustOverride Function GetOnlineUsers(ByVal PortalId As Integer) As IDataReader

    End Class

End Namespace