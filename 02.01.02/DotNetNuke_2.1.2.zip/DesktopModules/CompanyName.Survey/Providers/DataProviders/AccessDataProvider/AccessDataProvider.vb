Imports System
Imports System.Data
Imports System.Data.OleDB
Imports OleDB.ApplicationBlocks.Data
Imports System.Web
Imports DotNetNuke

Namespace CompanyName.Survey

    Public Class AccessDataProvider

        Inherits DataProvider

        Private Const ProviderType As String = "data"

        Private _providerConfiguration As ProviderConfiguration = ProviderConfiguration.GetProviderConfiguration(ProviderType)
        Private _connectionString As String
        Private _providerPath As String
        Private _objectQualifier As String
        Private _databaseFilename As String

        Public Sub New()

            ' Read the configuration specific information for this provider
            Dim objProvider As Provider = CType(_providerConfiguration.Providers(_providerConfiguration.DefaultProvider), Provider)

            ' Read the attributes for this provider
            _connectionString = objProvider.Attributes("connectionString")

            _providerPath = objProvider.Attributes("provIderPath")

            _objectQualifier = objProvider.Attributes("objectQualifier")
            If _objectQualifier <> "" And _objectQualifier.EndsWith("_") = False Then
                _objectQualifier += "_"
            End If

            _databaseFilename = objProvider.Attributes("databaseFilename")

            If _connectionString.IndexOf("Data Source=") = -1 Then
                Dim objHttpContext As HttpContext = HttpContext.Current
                _connectionString += "Data Source=" & objHttpContext.Server.MapPath(_providerPath) & _databaseFilename
            End If

        End Sub

        Public ReadOnly Property ConnectionString() As String
            Get
                Return _connectionString
            End Get
        End Property

        Public ReadOnly Property ProviderPath() As String
            Get
                Return _providerPath
            End Get
        End Property

        Public ReadOnly Property ObjectQualifier() As String
            Get
                Return _objectQualifier
            End Get
        End Property

        Public ReadOnly Property DatabaseFilename() As String
            Get
                Return _databaseFilename
            End Get
        End Property

        ' general
        Private Function GetNull(ByVal Field As Object) As Object
            Return Null.GetNull(Field, DBNull.Value)
        End Function

        Public Overrides Function GetSurveys(ByVal ModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetSurveys", _
                New OleDbParameter("@ModuleId", ModuleId)), IDataReader)
        End Function
        Public Overrides Function GetSurvey(ByVal SurveyID As Integer, ByVal ModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetSurvey", _
                New OleDbParameter("@SurveyId", SurveyID), _
                New OleDbParameter("@ModuleId", ModuleId)), IDataReader)
        End Function
        Public Overrides Function AddSurvey(ByVal ModuleId As Integer, ByVal Question As String, ByVal ViewOrder As Integer, ByVal OptionType As String, ByVal UserName As String) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddSurvey", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@Question", Question), _
                New OleDbParameter("@ViewOrder", GetNull(ViewOrder)), _
                New OleDbParameter("@OptionType", OptionType), _
                New OleDbParameter("@UserName", UserName))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetSurveyIdentity", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@Question", Question)), Integer)
        End Function
        Public Overrides Sub UpdateSurvey(ByVal SurveyId As Integer, ByVal Question As String, ByVal ViewOrder As Integer, ByVal OptionType As String, ByVal UserName As String)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateSurvey", _
                New OleDbParameter("@SurveyId", SurveyId), _
                New OleDbParameter("@Question", Question), _
                New OleDbParameter("@ViewOrder", GetNull(ViewOrder)), _
                New OleDbParameter("@OptionType", OptionType), _
                New OleDbParameter("@UserName", UserName))
        End Sub
        Public Overrides Sub DeleteSurvey(ByVal SurveyID As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteSurvey", _
                New OleDbParameter("@SurveyId", SurveyID))
        End Sub
        Public Overrides Function GetSurveyOptions(ByVal SurveyId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetSurveyOptions", _
                New OleDbParameter("@SurveyId", SurveyId)), IDataReader)
        End Function
        Public Overrides Function AddSurveyOption(ByVal SurveyId As Integer, ByVal OptionName As String, ByVal ViewOrder As Integer) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddSurveyOption", _
                New OleDbParameter("@SurveyId", SurveyId), _
                New OleDbParameter("@OptionName", OptionName), _
                New OleDbParameter("@ViewOrder", GetNull(ViewOrder)))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetSurveyOptionIdentity", _
                New OleDbParameter("@SurveyId", SurveyId), _
                New OleDbParameter("@OptionName", OptionName)), Integer)
        End Function
        Public Overrides Sub UpdateSurveyOption(ByVal SurveyOptionId As Integer, ByVal OptionName As String, ByVal ViewOrder As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateSurveyOption", _
                New OleDbParameter("@SurveyOptionId", SurveyOptionId), _
                New OleDbParameter("@OptionName", OptionName), _
                New OleDbParameter("@ViewOrder", GetNull(ViewOrder)))
        End Sub
        Public Overrides Sub DeleteSurveyOption(ByVal SurveyOptionID As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteSurveyOption", _
                New OleDbParameter("@SurveyOptionId", SurveyOptionID))
        End Sub
        Public Overrides Sub AddSurveyResult(ByVal SurveyOptionId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddSurveyResult", _
                New OleDbParameter("@SurveyOptionId", SurveyOptionId))
        End Sub


    End Class

End Namespace