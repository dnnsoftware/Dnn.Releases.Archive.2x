'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public MustInherit Class Events
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents lstEvents As System.Web.UI.WebControls.DataList
        Protected WithEvents calEvents As System.Web.UI.WebControls.Calendar

        Dim arrEvents(31) As String
        Protected WithEvents pnlModuleContent As System.Web.UI.WebControls.Panel
        Dim intMonth As Integer

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()

            'declare module actions
            MyBase.Actions.Add(GetNextActionID, "View Options", "", URL:=EditURL(, , "ViewOptions"), secure:=SecurityAccessLevel.Edit, Visible:=True)
            MyBase.Actions.Add(GetNextActionID, "Add New Event", "", URL:=EditURL(), secure:=SecurityAccessLevel.Edit, Visible:=True)
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load event handler on this User Control is used to
        ' obtain a DataReader of event information from the Events
        ' table, and then databind the results to a templated DataList
        ' server control.  It uses the DotNetNuke.EventDB()
        ' data component to encapsulate all data functionality.
        '
        '*******************************************************'

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim EventView As String = CType(Settings("eventview"), String)
                If EventView Is Nothing Then
                    EventView = "C" ' calendar
                End If

                Dim objEvents As New EventController

                Select Case EventView
                    Case "L" ' list
                        lstEvents.Visible = True
                        calEvents.Visible = False

                        lstEvents.DataSource = objEvents.GetModuleEvents(ModuleId, Convert.ToDateTime(Null.SetNull(Date.Now)), Convert.ToDateTime(Null.SetNull(Date.Now)))
                        lstEvents.DataBind()
                    Case "C" ' calendar
                        lstEvents.Visible = False
                        calEvents.Visible = True

                        If Not Page.IsPostBack Then
                            If Not Request.Params("VisibleDate") Is Nothing Then
                                calEvents.VisibleDate = CType(Request.Params("VisibleDate"), Date)
                            Else
                                calEvents.VisibleDate = Now
                            End If

                            If CType(Settings("eventcalendarcellwidth"), String) <> "" Then
                                calEvents.Width = System.Web.UI.WebControls.Unit.Parse(CType(Settings("eventcalendarcellwidth"), String) & "px")
                            End If
                            If CType(Settings("eventcalendarcellheight"), String) <> "" Then
                                calEvents.Height = System.Web.UI.WebControls.Unit.Parse(CType(Settings("eventcalendarcellheight"), String) & "px")
                            End If
                        Else
                            If calEvents.VisibleDate = #12:00:00 AM# Then
                                calEvents.VisibleDate = Now
                            End If
                        End If

                        Dim StartDate As String = GetFirstDayofMonth(calEvents.VisibleDate) & " 00:00"
                        Dim EndDate As String = GetLastDayofMonth(calEvents.VisibleDate) & " 23:59"

                        GetCalendarEvents(StartDate, EndDate)

                End Select
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub calEvents_DayRender(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DayRenderEventArgs) Handles calEvents.DayRender
            Try
                If e.Day.Date.Month = intMonth Then
                    Dim ctlLabel As Label = New Label()
                    ctlLabel.Text = arrEvents(e.Day.Date.Day)
                    e.Cell.Controls.Add(ctlLabel)
                End If
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub calEvents_VisibleMonthChanged(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.MonthChangedEventArgs) Handles calEvents.VisibleMonthChanged
            Try
                Dim StartDate As String = GetFirstDayofMonth(e.NewDate.Date) & " 00:00"
                Dim EndDate As String = GetLastDayofMonth(e.NewDate.Date) & " 23:59"

                GetCalendarEvents(StartDate, EndDate)
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub GetCalendarEvents(ByVal StartDate As String, ByVal EndDate As String)
            Try
                Dim objEvents As New EventController
                Dim strDayText As String
                Dim datTargetDate As Date
                Dim datDate As Date
                Dim blnDisplay As Boolean

                Array.Clear(arrEvents, 0, 32)

                Dim Arr As ArrayList = objEvents.GetModuleEvents(ModuleId, Convert.ToDateTime(StartDate), Convert.ToDateTime(EndDate))
                Dim i As Integer
                For i = 0 To Arr.Count - 1

                    Dim objEvent As EventInfo = CType(Arr(i), EventInfo)
                    'While dr.Read()
                    If objEvent.Period.ToString = "" Then
                        strDayText = "<br>"
                        If FormatImage(objEvent.IconFile) <> "" Then
                            strDayText += "<img alt=""" & objEvent.AltText & """ src=""" & FormatImage(objEvent.IconFile) & """ border=""0""><br>"
                        End If
                        If IsEditable Then
                            strDayText += "<a href=""" & CType(Global.ApplicationPath, String) & "/Desktopdefault.aspx?tabid=" & TabId & "&mid=" & ModuleId & "&ctl=Edit" & "&ItemID=" & objEvent.ItemId & "&VisibleDate=" & calEvents.VisibleDate.ToShortDateString & """><img alt=""Edit"" src=""" & CType(Global.ApplicationPath, String) & "/images/edit.gif"" border=""0""></a>&nbsp;"
                        End If
                        strDayText += "<span class=""ItemTitle"">" & objEvent.Title & "</span>"
                        If objEvent.DateTime.ToString("HH:mm") <> "00:00" Then
                            strDayText += "<br><span class=""Normal"">" & objEvent.DateTime.ToShortTimeString & "</span>"
                        End If
                        strDayText += "<br><span class=""Normal"">" & objEvent.Description & "</span>"

                        arrEvents(CDate(objEvent.DateTime).Day) += strDayText
                    Else ' recurring event
                        datTargetDate = CType(objEvent.DateTime, Date)
                        datDate = Date.Parse(StartDate)
                        While datDate <= Date.Parse(EndDate)
                            blnDisplay = False
                            Select Case objEvent.Period
                                Case CType("D", Char) ' day
                                    If DateDiff(DateInterval.Day, datTargetDate, datDate) Mod objEvent.Every = 0 Then
                                        blnDisplay = True
                                    End If
                                Case CType("W", Char) ' week
                                    If DateAdd(DateInterval.WeekOfYear, DateDiff(DateInterval.WeekOfYear, datTargetDate.Date, datDate), datTargetDate.Date) = datDate Then
                                        If DateDiff(DateInterval.WeekOfYear, datTargetDate, datDate) Mod objEvent.Every = 0 Then
                                            blnDisplay = True
                                        End If
                                    End If
                                Case CType("M", Char) ' month
                                    If DateAdd(DateInterval.Month, DateDiff(DateInterval.Month, datTargetDate.Date, datDate), datTargetDate.Date) = datDate Then
                                        If DateDiff(DateInterval.Month, datTargetDate, datDate) Mod objEvent.Every = 0 Then
                                            blnDisplay = True
                                        End If
                                    End If
                                Case CType("Y", Char) ' year
                                    If DateAdd(DateInterval.Year, DateDiff(DateInterval.Year, datTargetDate.Date, datDate), datTargetDate.Date) = datDate Then
                                        If DateDiff(DateInterval.Year, datTargetDate, datDate) Mod objEvent.Every = 0 Then
                                            blnDisplay = True
                                        End If
                                    End If
                            End Select
                            If blnDisplay Then
                                If datDate < datTargetDate.Date Then
                                    blnDisplay = False
                                End If
                            End If
                            If blnDisplay Then
                                If Not Null.IsNull(objEvent.ExpireDate) Then
                                    If datDate > CType(objEvent.ExpireDate, Date) Then
                                        blnDisplay = False
                                    End If
                                End If
                            End If
                            If blnDisplay Then
                                strDayText = "<br>"
                                If FormatImage(objEvent.IconFile) <> "" Then
                                    strDayText += "<img alt=""" & objEvent.AltText & """ src=""" & FormatImage(objEvent.IconFile) & """ border=""0""><br>"
                                End If
                                If IsEditable Then
                                    strDayText += "<a href=""" & CType(Global.ApplicationPath, String) & "/Desktopdefault.aspx?tabid=" & TabId & "&mid=" & ModuleId & "&ctl=Edit" & "&ItemID=" & objEvent.ItemId & "&VisibleDate=" & calEvents.VisibleDate.ToShortDateString & """><img alt=""Edit"" src=""" & CType(Global.ApplicationPath, String) & "/images/edit.gif"" border=""0""></a>&nbsp;"
                                End If
                                strDayText += "<span class=""ItemTitle"">" & objEvent.Title & "</span>"
                                If objEvent.DateTime.ToString("HH:mm") <> "00:00" Then
                                    strDayText += "<br><span class=""Normal"">" & objEvent.DateTime.ToShortTimeString & "</span>"
                                End If
                                strDayText += "<br><span class=""Normal"">" & objEvent.Description & "</span>"

                                arrEvents(datDate.Day) += strDayText
                            End If
                            datDate = DateAdd(DateInterval.Day, 1, datDate)
                        End While
                    End If
                Next
                
                intMonth = CDate(StartDate).Month

                calEvents.DataBind()

            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Function FormatDateTime(ByVal DateTime As Date) As String
            Try
                FormatDateTime = DateTime.ToLongDateString
                If DatePart(DateInterval.Hour, DateTime) <> 0 Or DatePart(DateInterval.Minute, DateTime) <> 0 Or DatePart(DateInterval.Second, DateTime) <> 0 Then
                    FormatDateTime = FormatDateTime & " at " & DateTime.ToShortTimeString
                End If
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

        Function FormatImage(ByVal IconFile As String) As String
            Try
                If Not IconFile = "" Then
                    FormatImage = PortalSettings.UploadDirectory & IconFile.ToString
                End If
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

        End Function

        Function GetFirstDayofMonth(ByVal datDate As Date) As String
            Try
                Dim datFirstDayofMonth As Date = DateSerial(datDate.Year, datDate.Month, 1)
                Return GetMediumDate(datFirstDayofMonth.ToString)
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

        Function GetLastDayofMonth(ByVal datDate As Date) As String
            Try
                Dim intDaysInMonth As Integer = Date.DaysInMonth(datDate.Year, datDate.Month)
                Dim datLastDayofMonth As Date = DateSerial(datDate.Year, datDate.Month, intDaysInMonth)
                Return GetMediumDate(datLastDayofMonth.ToString)
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

    End Class

End Namespace
