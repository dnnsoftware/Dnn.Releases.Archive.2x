'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Scott McCulloch ( smcculloch@iinet.net.au ) ( http://www.smcculloch.net )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke

Namespace YourCompanyName.UsersOnline

    Public MustInherit Class UsersOnline

        Inherits PortalModuleControl
        Protected WithEvents pnlModuleContent As System.Web.UI.WebControls.Panel
        Protected WithEvents lblNewToday As System.Web.UI.WebControls.Label
        Protected WithEvents lblNewYesterday As System.Web.UI.WebControls.Label
        Protected WithEvents lblUserCount As System.Web.UI.WebControls.Label
        Protected WithEvents lblGuestCount As System.Web.UI.WebControls.Label
        Protected WithEvents lblMemberCount As System.Web.UI.WebControls.Label
        Protected WithEvents lblTotalCount As System.Web.UI.WebControls.Label
        Protected WithEvents lblLatestUserName As System.Web.UI.WebControls.Label
        Protected WithEvents pnlMembership As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlUsersOnline As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlOnlineNow As System.Web.UI.WebControls.Panel
        Protected WithEvents rptOnlineNow As System.Web.UI.WebControls.Repeater

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()

            ' PortalModuleControl base class settings for this module
            MyBase.HelpFile = "help.txt" ' a local document stored in the same folder as the user control
            MyBase.HelpURL = "http://www.dotnetnuke.com" ' a URL for support on the module
            ' action menu items
            MyBase.Actions.Add(GetNextActionID, "View Options", "", URL:=EditURL(, , "Options"), secure:=SecurityAccessLevel.Edit, Visible:=True)
       End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            Try
                Dim provider As DataProvider = DataProvider.Instance()
                Dim statistics As Hashtable = provider.GetStatistics(PortalSettings.PortalId)

                If Not (Settings("ShowMembership") Is Nothing) Then
                    pnlMembership.Visible = CType(Settings("ShowMembership"), Boolean)
                End If

                If Not (Settings("ShowPeopleOnline") Is Nothing) Then
                    pnlUsersOnline.Visible = (CType(Settings("ShowPeopleOnline"), Boolean))
                End If

                If Not (Settings("ShowUsersOnline") Is Nothing) Then
                    pnlOnlineNow.Visible = (CType(Settings("ShowUsersOnline"), Boolean))
                End If

                lblMemberCount.Text = CType(statistics("OnlineUserCount"), String)
                lblGuestCount.Text = CType(statistics("AnonymousUserCount"), String)
                lblTotalCount.Text = (Convert.ToInt32(lblMemberCount.Text) + Convert.ToInt32(lblGuestCount.Text)).ToString()

                lblNewToday.Text = CType(statistics("MembershipToday"), String)
                lblNewYesterday.Text = CType(statistics("MembershipYesterday"), String)
                lblUserCount.Text = CType(statistics("MembershipCount"), String)
                lblLatestUserName.Text = CType(statistics("LastUsername"), String)

                Dim reader As IDataReader = provider.GetOnlineUsers(PortalSettings.PortalId)

                rptOnlineNow.DataSource = reader
                rptOnlineNow.DataBind()

                reader.Close()

            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub

        Private Sub rptOnlineNow_ItemDataBound(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles rptOnlineNow.ItemDataBound
            Dim lblUserNumber As System.Web.UI.WebControls.Label = CType(e.Item.FindControl("lblUserNumber"), System.Web.UI.WebControls.Label)

            If Not (lblUserNumber Is Nothing) Then
                Dim userNumber As String = (e.Item.ItemIndex + 1).ToString()

                If (userNumber.Length = 1) Then
                    userNumber = "0" & userNumber
                End If

                lblUserNumber.Text = userNumber
            End If
        End Sub

    End Class

End Namespace