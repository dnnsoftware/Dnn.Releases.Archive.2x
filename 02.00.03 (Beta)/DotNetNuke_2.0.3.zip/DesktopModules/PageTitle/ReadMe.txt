Sample Skin Object:- PageTitle

* This is a sample skin object that displays the PageTitle in the Skin.
* Install this skin object as you would a normal module (File Manager -> Custom Module).
* You can then use [PAGETITLE] in your html skins
* You can also optionally specify CssClass in your skin.xml file of your skin

Scott McCulloch
http://www.smcculloch.net/