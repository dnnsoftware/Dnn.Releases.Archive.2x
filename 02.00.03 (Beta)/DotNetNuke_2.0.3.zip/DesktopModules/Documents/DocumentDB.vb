'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data

Namespace DotNetNuke
    Public Class DocumentInfo
        ' local property declarations
        Private _ItemId As Integer
        Private _ModuleId As Integer
        Private _CreatedByUser As String
        Private _CreatedDate As Date
        Private _Url As String
        Private _Title As String
        Private _Category As String
        Private _Syndicate As Boolean
        Private _Clicks As Integer
        Private _Size As Double

        ' initialization
        Public Sub New()
        End Sub

        ' public properties
        Public Property ItemId() As Integer
            Get
                Return _ItemId
            End Get
            Set(ByVal Value As Integer)
                _ItemId = Value
            End Set
        End Property

        Public Property ModuleId() As Integer
            Get
                Return _ModuleId
            End Get
            Set(ByVal Value As Integer)
                _ModuleId = Value
            End Set
        End Property
        Public Property CreatedByUser() As String
            Get
                Return _CreatedByUser
            End Get
            Set(ByVal Value As String)
                _CreatedByUser = Value
            End Set
        End Property

        Public Property CreatedDate() As Date
            Get
                Return _CreatedDate
            End Get
            Set(ByVal Value As Date)
                _CreatedDate = Value
            End Set
        End Property
        Public Property Url() As String
            Get
                Return _Url
            End Get
            Set(ByVal Value As String)
                _Url = Value
            End Set
        End Property
        Public Property Title() As String
            Get
                Return _Title
            End Get
            Set(ByVal Value As String)
                _Title = Value
            End Set
        End Property
        Public Property Category() As String
            Get
                Return _Category
            End Get
            Set(ByVal Value As String)
                _Category = Value
            End Set
        End Property
        Public Property Syndicate() As Boolean
            Get
                Return _Syndicate
            End Get
            Set(ByVal Value As Boolean)
                _Syndicate = Value
            End Set
        End Property

        Public Property Clicks() As Integer
            Get
                Return _Clicks
            End Get
            Set(ByVal Value As Integer)
                _Clicks = Value
            End Set
        End Property
        Public Property Size() As Double
            Get
                Return _Size
            End Get
            Set(ByVal Value As Double)
                _Size = Value
            End Set
        End Property
    End Class
    Public Class DocumentController

        Public Function GetDocuments(ByVal ModuleId As Integer, ByVal PortalId As Integer) As ArrayList

            Return CBO.FillCollection(DataProvider.Instance().GetDocuments(ModuleId, PortalId), GetType(DocumentInfo))

        End Function


        Public Function GetDocument(ByVal ItemId As Integer, ByVal ModuleId As Integer) As DocumentInfo
            Return CType(CBO.FillObject(DataProvider.Instance().GetDocument(ItemId, ModuleId), GetType(DocumentInfo)), DocumentInfo)

        End Function


        Public Sub DeleteDocument(ByVal ItemID As Integer)

            DataProvider.Instance().DeleteDocument(ItemID)

        End Sub


        Public Sub AddDocument(ByVal objDocument As DocumentInfo)

            DataProvider.Instance().AddDocument(objDocument.ModuleId, objDocument.Title, objDocument.Url, objDocument.CreatedByUser, objDocument.Category, objDocument.Syndicate)

        End Sub


        Public Sub UpdateDocument(ByVal objDocument As DocumentInfo)

            DataProvider.Instance().UpdateDocument(objDocument.ItemId, objDocument.Title, objDocument.URL, objDocument.CreatedByUser, objDocument.Category, objDocument.Syndicate)

        End Sub

    End Class

End Namespace
