Imports System
Imports System.Web.Caching
Imports System.Reflection

Namespace YourCompanyName.Survey

    Public MustInherit Class DataProvider

        ' provider constants - eliminates need for Reflection later
        Private Const [ProviderType] As String = "data" ' maps to <sectionGroup> in web.config 
        Private Const [NameSpace] As String = "YourCompanyName.Survey" ' project namespace
        Private Const [AssemblyName] As String = "YourCompanyName.Survey" ' project assemblyname

        Public Shared Shadows Function Instance() As DataProvider

            Dim strCacheKey As String = [NameSpace] & "." & [ProviderType] & "provider"

            ' Use the cache because the reflection used later is expensive
            Dim objConstructor As ConstructorInfo = CType(DotNetNuke.DataCache.GetCache(strCacheKey), ConstructorInfo)

            If objConstructor Is Nothing Then
                ' Get the provider configuration based on the type
                Dim objProviderConfiguration As DotNetNuke.ProviderConfiguration = DotNetNuke.ProviderConfiguration.GetProviderConfiguration([ProviderType])

                ' The assembly should be in \bin or GAC, so we simply need to get an instance of the type
                Try

                    ' Override the typename if a ProviderName is specified ( this allows the application to load a different DataProvider assembly for custom modules )
                    Dim strTypeName As String = [NameSpace] & "." & objProviderConfiguration.DefaultProvider & ", " & [AssemblyName] & "." & objProviderConfiguration.DefaultProvider

                    ' Use reflection to store the constructor of the class that implements DataProvider
                    Dim t As Type = Type.GetType(strTypeName, True)
                    objConstructor = t.GetConstructor(System.Type.EmptyTypes)

                    ' Insert the type into the cache
                    DotNetNuke.DataCache.SetCache(strCacheKey, objConstructor)

                Catch e As Exception

                    ' Could not load the provider - this is likely due to binary compatibility issues 

                End Try
            End If

            Return CType(objConstructor.Invoke(Nothing), DataProvider)

        End Function

        ' all core methods defined below

        Public MustOverride Function GetSurveys(ByVal ModuleId As Integer) As IDataReader
        Public MustOverride Function GetSurvey(ByVal SurveyID As Integer, ByVal ModuleId As Integer) As IDataReader
        Public MustOverride Function AddSurvey(ByVal ModuleId As Integer, ByVal Question As String, ByVal ViewOrder As Integer, ByVal OptionType As String, ByVal UserName As String) As Integer
        Public MustOverride Sub UpdateSurvey(ByVal SurveyId As Integer, ByVal Question As String, ByVal ViewOrder As Integer, ByVal OptionType As String, ByVal UserName As String)
        Public MustOverride Sub DeleteSurvey(ByVal SurveyID As Integer)
        Public MustOverride Function GetSurveyOptions(ByVal SurveyId As Integer) As IDataReader
        Public MustOverride Function AddSurveyOption(ByVal SurveyId As Integer, ByVal OptionName As String, ByVal ViewOrder As Integer) As Integer
        Public MustOverride Sub UpdateSurveyOption(ByVal SurveyOptionId As Integer, ByVal OptionName As String, ByVal ViewOrder As Integer)
        Public MustOverride Sub DeleteSurveyOption(ByVal SurveyOptionID As Integer)
        Public MustOverride Sub AddSurveyResult(ByVal SurveyOptionId As Integer)

    End Class

End Namespace