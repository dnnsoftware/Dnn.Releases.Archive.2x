'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Net
Imports System.IO
Imports System.Text

Namespace DotNetNuke

    Public MustInherit Class MapQuest
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents lblLocation As System.Web.UI.WebControls.Label
        Protected WithEvents lblAddress As System.Web.UI.WebControls.Label
        Protected WithEvents cboSize As System.Web.UI.WebControls.DropDownList
        Protected WithEvents colSize As System.Web.UI.HtmlControls.HtmlTableCell
        Protected WithEvents hypDirections As System.Web.UI.WebControls.HyperLink
        Protected WithEvents cboZoom As System.Web.UI.WebControls.DropDownList
        Protected WithEvents colZoom As System.Web.UI.HtmlControls.HtmlTableCell
        Protected WithEvents pnlModuleContent As System.Web.UI.WebControls.Panel
        Protected WithEvents hypMap As System.Web.UI.WebControls.HyperLink
        Protected WithEvents hypMapImage As System.Web.UI.WebControls.Image


#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
            MyBase.Actions.Add(GetNextActionID, "Edit Map Settings", "", URL:=EditURL(), secure:=SecurityAccessLevel.Edit, Visible:=True)
        End Sub

#End Region

        Private _size As String = "small"
        Private _zoom As String = "8"
        Private valid As Boolean

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If Not Page.IsPostBack Then
                    valid = True
                    Select Case Nothing
                        Case Settings("street")
                            valid = False
                        Case Settings("city")
                            valid = False
                        Case Settings("region")
                            valid = False
                        Case Settings("country")
                            valid = False
                        Case Settings("postalcode")
                            valid = False
                    End Select

                    If valid Then
                        If CType(Settings("location"), String) <> "" Then
                            lblLocation.Text = CType(Settings("location"), String)
                            If Request.IsAuthenticated Then
                                hypDirections.Text = "Get Directions"
                                hypDirections.NavigateUrl = BuildDirectionsURL()
                            End If
                            If CType(Settings("showaddress"), Boolean) Then
                                lblAddress.Text = FormatAddress(CType(Settings("unit"), String), CType(Settings("street"), String), CType(Settings("city"), String), CType(Settings("region"), String), CType(Settings("country"), String), CType(Settings("postalcode"), String))
                            End If
                        End If

                        If Not CType(Settings("defaultzoom"), String) = "" Then
                            _zoom = CType(Settings("defaultzoom"), String)
                        End If

                        If Not CType(Settings("defaultsize"), String) = "" Then
                            _size = CType(Settings("defaultsize"), String)
                        End If

                        If CType(Settings("customsize"), Boolean) Then
                            colZoom.Visible = True
                            colSize.Visible = True
                            If Not cboZoom.Items.FindByValue(_zoom) Is Nothing Then
                                cboZoom.ClearSelection()
                                cboZoom.Items.FindByValue(_zoom).Selected = True
                            End If
                            If Not cboSize.Items.FindByValue(_size) Is Nothing Then
                                cboSize.ClearSelection()
                                cboSize.Items.FindByValue(_size).Selected = True
                            End If
                        Else
                            colZoom.Visible = False
                            colSize.Visible = False
                        End If

                        BuildMapImage()
                    Else
                        hypMap.Visible = False
                        hypDirections.Visible = False
                        colSize.Visible = False
                        colZoom.Visible = False
                        hypMapImage.BorderWidth = Unit.Pixel(0)
                        hypMapImage.Visible = False
                        If PortalSecurity.IsInRoles(PortalSettings.ActiveTab.AdministratorRoles.ToString) Then
                            lblAddress.Text = "Address has not been entered."
                        End If

                    End If
                End If
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Function EncodeValue(ByVal strValue As String) As String
            Try
                EncodeValue = Replace(strValue, ControlChars.CrLf, "")
                EncodeValue = Replace(strValue, "%", "%%25")
                EncodeValue = Replace(strValue, "&", "%%26")
                EncodeValue = Replace(strValue, "+", "%%30")
                EncodeValue = Replace(strValue, " ", "+")
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

        Private Function BuildMapURL() As String
            Try
                Dim strURL As New StringBuilder
                strURL.Append("http://www.mapquest.com/maps/map.adp")
                strURL.Append("?address=" & EncodeValue(CType(Settings("street"), String)))
                strURL.Append("&city=" & EncodeValue(CType(Settings("city"), String)))
                strURL.Append("&state=" & EncodeValue(CType(Settings("region"), String)))
                strURL.Append("&country=" & EncodeValue(CType(Settings("country"), String)))
                strURL.Append("&zip=" & EncodeValue(CType(Settings("postalcode"), String)))
                strURL.Append("&size=" & EncodeValue(_size))
                strURL.Append("&zoom=" & EncodeValue(_zoom))

                Return strURL.ToString
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

        Private Function GetMapImageURL(ByVal strURL As String) As String
            Try
                Dim strMapQuestURL As String = DataCache.GetCache("MapQuestURL" & ModuleId.ToString).ToString

                If strMapQuestURL Is Nothing Then
                    Try

                        Dim objRequest As HttpWebRequest = GetExternalRequest(strURL)

                        Dim objResponse As HttpWebResponse = CType(objRequest.GetResponse(), HttpWebResponse)
                        Dim sr As StreamReader
                        sr = New StreamReader(objResponse.GetResponseStream())
                        Dim strResponse As String = sr.ReadToEnd()
                        sr.Close()

                        Dim intPos1 As Integer
                        Dim intPos2 As Integer

                        intPos1 = InStr(1, strResponse, "mqmapgend")
                        intPos1 = InStrRev(strResponse, "http://", intPos1)
                        intPos2 = InStr(intPos1, strResponse, """")

                        strMapQuestURL = Mid(strResponse, intPos1, intPos2 - intPos1)

                        DataCache.SetCache("MapQuestURL" & ModuleId.ToString, strMapQuestURL)

                    Catch ex As Exception
                        ' TODO: add exeption handler
                    End Try

                End If

                Return strMapQuestURL

            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

        Private Function BuildDirectionsURL() As String
            Try
                Dim objRegionalController As New RegionalController
                Dim strURL As New StringBuilder

                strURL.Append("http://www.mapquest.com/directions/main.adp?go=1")
                strURL.Append("&2a=" & EncodeValue(CType(Settings("street"), String)))
                strURL.Append("&2c=" & EncodeValue(CType(Settings("city"), String)))
                If Not Settings("country") Is Nothing Then
                    Select Case CType(Settings("country"), String).ToLower
                        Case "united states", "canada"
                            Dim w As String = objRegionalController.GetRegionByDescription(CType(Settings("region"), String)).Code
                            strURL.Append("&2s=" & EncodeValue(objRegionalController.GetRegionByDescription(CType(Settings("region"), String)).Code))
                        Case Else
                            strURL.Append("&2s=" & EncodeValue(CType(Settings("region"), String)))
                    End Select
                    hypDirections.Visible = False
                End If
                strURL.Append("&2y=" & EncodeValue(CType(Settings("country"), String)))
                strURL.Append("&2z=" & EncodeValue(CType(Settings("postalcode"), String)))

                Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

                Dim objUsers As New UserController
                Dim objUser As UserInfo = objUsers.GetUser(PortalId, Int32.Parse(context.User.Identity.Name))

                If Not objUser Is Nothing Then
                    strURL.Append("&1a=" & EncodeValue(objUser.Street))
                    strURL.Append("&1c=" & EncodeValue(objUser.City))
                    strURL.Append("&1s=" & EncodeValue(objUser.Region))
                    strURL.Append("&1y=" & EncodeValue(objUser.Country))
                    strURL.Append("&1z=" & EncodeValue(objUser.PostalCode))
                End If

                Return strURL.ToString
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

        Private Sub BuildMapImage()

            Dim blnDisplayMap As Boolean = False
            If CType(Settings("displaymap"), String) <> "" Then
                blnDisplayMap = CType(Settings("displaymap"), Boolean)
            End If
            hypMap.NavigateUrl = BuildMapURL()
            If blnDisplayMap Then
                hypMapImage.ImageUrl = GetMapImageURL(hypMap.NavigateUrl)
                hypMapImage.Visible = True
            Else
                hypMap.Text = "Show Map"
            End If
            If hypMapImage.ImageUrl = "" Then
                colSize.Visible = False
                colZoom.Visible = False
                hypMapImage.BorderWidth = Unit.Pixel(0)
                hypMapImage.Visible = False
            Else
                'colSize.Visible = True
                'colZoom.Visible = True
                hypMapImage.BorderWidth = Unit.Pixel(1)
                hypMapImage.AlternateText = FormatAddress(CType(Settings("unit"), String), CType(Settings("street"), String), CType(Settings("city"), String), CType(Settings("region"), String), CType(Settings("country"), String), CType(Settings("postalcode"), String))
                hypMapImage.Visible = True
            End If

        End Sub

        Private Sub cboSize_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboSize.SelectedIndexChanged
            Try
                _size = cboSize.SelectedItem.Value
                _zoom = cboZoom.SelectedItem.Value
                BuildMapImage()
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cboZoom_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboZoom.SelectedIndexChanged
            Try
                _size = cboSize.SelectedItem.Value
                _zoom = cboZoom.SelectedItem.Value
                BuildMapImage()
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

    End Class

End Namespace
