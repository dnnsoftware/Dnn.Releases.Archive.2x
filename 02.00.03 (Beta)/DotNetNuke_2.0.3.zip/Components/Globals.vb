'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System
Imports System.Configuration
Imports System.IO
Imports System.Web.Mail
Imports System.Text
Imports System.Net

Namespace DotNetNuke

    '*********************************************************************
    '
    ' Globals Module
    ' This module contains global utility functions, constants, and enumerations.
    '
    '*********************************************************************

    Public Module Globals

        Public Const glbRoleAllUsers As String = "-1"
        Public Const glbRoleSuperUser As String = "-2"
        Public Const glbRoleUnauthUser As String = "-3"

        Public Const glbDefaultPage As String = "Default.aspx"
        Public Const glbDefaultPane As String = "ContentPane"
        Public Const glbImageFileTypes As String = "jpg,jpeg,jpe,gif,bmp,png"

        ' returns the absolute server path to the root ( ie. D:\Inetpub\wwwroot\directory\ )
        Public Function GetAbsoluteServerPath(ByVal Request As HttpRequest) As String
            Dim strServerPath As String

            strServerPath = Request.MapPath(Request.ApplicationPath)
            If Not strServerPath.EndsWith("\") Then
                strServerPath += "\"
            End If

            GetAbsoluteServerPath = strServerPath
        End Function

        ' returns the domain name of the current request ( ie. www.domain.com or 207.132.12.123 or www.domain.com/directory if subhost )
        Public Function GetDomainName(ByVal Request As HttpRequest) As String
            Dim DomainName As StringBuilder = New StringBuilder
            Dim URL() As String
            Dim intURL As Integer

            URL = Split(Request.Url.ToString(), "/")
            For intURL = 2 To URL.GetUpperBound(0)
                Select Case URL(intURL).ToLower
                    Case "admin", "controls", "desktopmodules", "mobilemodules", "premiummodules"
                        Exit For
                    Case Else
                        ' check if filename
                        If InStr(1, URL(intURL), ".aspx") = 0 And InStr(1, URL(intURL), ".axd") = 0 Then
                            DomainName.Append(IIf(DomainName.ToString <> "", "/", "").ToString & URL(intURL))
                        Else
                            Exit For
                        End If
                End Select
            Next intURL

            Return DomainName.ToString
        End Function

        ' stub included for legacy purposes
        Public Function SendNotification(ByVal strFrom As String, ByVal strTo As String, ByVal strBcc As String, ByVal strSubject As String, ByVal strBody As String, Optional ByVal strAttachment As String = "", Optional ByVal strBodyType As String = "", Optional ByVal strSMTPServer As String = "") As String

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' SMTP server
            If _portalSettings.HostSettings("SMTPServer").ToString <> "" Then
                strSMTPServer = _portalSettings.HostSettings("SMTPServer").ToString
            End If
            Dim strSMTPUsername As String = ""
            If Convert.ToString(_portalSettings.HostSettings("SMTPUsername")) <> "" Then
                strSMTPUsername = Convert.ToString(_portalSettings.HostSettings("SMTPUsername"))
            End If
            Dim strSMTPPassword As String = ""
            If Convert.ToString(_portalSettings.HostSettings("SMTPPassword")) <> "" Then
                strSMTPPassword = Convert.ToString(_portalSettings.HostSettings("SMTPPassword"))
            End If

            ' here we check if we want to format the email as html or plain text.
            Dim objBodyFormat As MailFormat
            If strBodyType <> "" Then
                Select Case LCase(strBodyType)
                    Case "html"
                        objBodyFormat = MailFormat.Html
                    Case "text"
                        objBodyFormat = MailFormat.Text
                End Select
            End If

            Return SendMail(strFrom, strTo, "", strBcc, MailPriority.Normal, strSubject, objBodyFormat, System.Text.Encoding.Default, strBody, strAttachment, strSMTPServer, strSMTPUsername, strSMTPPassword)

        End Function

        ' sends a simple email
        Public Function SendMail(ByVal [From] As String, ByVal [To] As String, ByVal [Cc] As String, ByVal [Bcc] As String, ByVal [Priority] As MailPriority, ByVal [Subject] As String, ByVal [BodyFormat] As MailFormat, ByVal [BodyEncoding] As System.Text.Encoding, ByVal [Body] As String, ByVal [Attachment] As String, ByVal [SMTPServer] As String, ByVal [SMTPUsername] As String, ByVal [SMTPPassword] As String) As String

            Dim objMail As New MailMessage

            ' recipients
            objMail.From = [From]
            objMail.To = [To]
            If [Cc] <> "" Then
                objMail.Cc = [Cc]
            End If
            If [Bcc] <> "" Then
                objMail.Bcc = [Bcc]
            End If

            ' message
            objMail.Priority = [Priority]
            objMail.Subject = [Subject]
            objMail.BodyFormat = [BodyFormat]
            objMail.BodyEncoding = [BodyEncoding]
            objMail.Body = [Body]

            ' attachment
            If [Attachment] <> "" Then
                objMail.Attachments.Add(New MailAttachment([Attachment]))
            End If

            ' SMTP server
            If [SMTPServer] <> "" Then
                SmtpMail.SmtpServer = [SMTPServer]
            End If

            ' external SMTP server
            If [SMTPServer] <> "" Then
                SmtpMail.SmtpServer = [SMTPServer]
                ' with authentication
                If [SMTPUsername] <> "" And [SMTPPassword] <> "" Then
                    objMail.Fields("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate") = 1
                    objMail.Fields("http://schemas.microsoft.com/cdo/configuration/sendusername") = [SMTPUsername]
                    objMail.Fields("http://schemas.microsoft.com/cdo/configuration/sendpassword") = [SMTPPassword]
                End If
            End If

            Try
                SmtpMail.Send(objMail)
            Catch objException As Exception
                ' mail configuration problem
                SendMail = objException.Message
            End Try

        End Function

        ' encodes a URL for posting to an external site
        Public Function HTTPPOSTEncode(ByVal strPost As String) As String
            strPost = Replace(strPost, "\", "")
            strPost = System.Web.HttpUtility.UrlEncode(strPost)
            strPost = Replace(strPost, "%2f", "/")
            HTTPPOSTEncode = strPost
        End Function

        ' retrieves the domain name of the portal ( ie. http://www.domain.com " )
        Public Function GetPortalDomainName(ByVal strPortalAlias As String, Optional ByVal Request As HttpRequest = Nothing, Optional ByVal blnAddHTTP As Boolean = True) As String

            Dim strDomainName As String

            Dim strURL As String = ""
            Dim arrPortalAlias() As String
            Dim intAlias As Integer

            If Not Request Is Nothing Then
                strURL = GetDomainName(Request)
            End If

            arrPortalAlias = Split(strPortalAlias, ",")
            For intAlias = 0 To arrPortalAlias.Length - 1
                If arrPortalAlias(intAlias) = strURL Then
                    strDomainName = arrPortalAlias(intAlias)
                End If
            Next
            If strDomainName = "" Then
                strDomainName = arrPortalAlias(0)
            End If

            If blnAddHTTP Then
                strDomainName = AddHTTP(strDomainName)
            End If

            GetPortalDomainName = strDomainName

        End Function

        ' adds HTTP to URL if no other protocol specified
        Public Function AddHTTP(ByVal strURL As String) As String
            If strURL <> "" Then
                If InStr(1, strURL, "://") = 0 And InStr(1, strURL, "~") = 0 And InStr(1, strURL, "\\") = 0 Then
                    If HttpContext.Current.Request.IsSecureConnection Then
                        strURL = "https://" & strURL
                    Else
                        strURL = "http://" & strURL
                    End If
                End If
            End If
            Return strURL
        End Function

        ' convert datareader to dataset
        Public Function ConvertDataReaderToDataSet(ByVal reader As IDataReader) As DataSet

            ' add datatable to dataset
            Dim objDataSet As New DataSet
            objDataSet.Tables.Add(ConvertDataReaderToDataTable(reader))

            Return objDataSet

        End Function

        ' convert datareader to dataset
        Public Function ConvertDataReaderToDataTable(ByVal reader As IDataReader) As DataTable

            ' create datatable from datareader
            Dim objDataTable As New DataTable
            Dim intFieldCount As Integer = reader.FieldCount
            Dim intCounter As Integer
            For intCounter = 0 To intFieldCount - 1
                objDataTable.Columns.Add(reader.GetName(intCounter), reader.GetFieldType(intCounter))
            Next intCounter

            ' populate datatable
            objDataTable.BeginLoadData()
            Dim objValues(intFieldCount - 1) As Object
            While reader.Read()
                reader.GetValues(objValues)
                objDataTable.LoadDataRow(objValues, True)
            End While
            reader.Close()
            objDataTable.EndLoadData()

            Return objDataTable

        End Function

        ' convert datareader to crosstab dataset
        Public Function BuildCrossTabDataSet(ByVal DataSetName As String, ByVal result As IDataReader, ByVal FixedColumns As String, ByVal VariableColumns As String, ByVal KeyColumn As String, ByVal FieldColumn As String, ByVal FieldTypeColumn As String, ByVal StringValueColumn As String, ByVal NumericValueColumn As String) As DataSet

            Dim arrFixedColumns As String()
            Dim arrVariableColumns As String()
            Dim arrField As String()
            Dim FieldName As String
            Dim FieldType As String
            Dim intColumn As Integer
            Dim intKeyColumn As Integer

            ' create dataset
            Dim crosstab As New DataSet(DataSetName)
            crosstab.Namespace = "NetFrameWork"

            ' create table
            Dim tab As New DataTable(DataSetName)

            ' split fixed columns
            arrFixedColumns = FixedColumns.Split(",".ToCharArray())

            ' add fixed columns to table
            For intColumn = LBound(arrFixedColumns) To UBound(arrFixedColumns)
                arrField = arrFixedColumns(intColumn).Split("|".ToCharArray())
                Dim col As New DataColumn(arrField(0), System.Type.GetType("System." & arrField(1)))
                tab.Columns.Add(col)
            Next intColumn

            ' split variable columns
            If VariableColumns <> "" Then
                arrVariableColumns = VariableColumns.Split(",".ToCharArray())

                ' add varible columns to table
                For intColumn = LBound(arrVariableColumns) To UBound(arrVariableColumns)
                    arrField = arrVariableColumns(intColumn).Split("|".ToCharArray())
                    Dim col As New DataColumn(arrField(0), System.Type.GetType("System." & arrField(1)))
                    col.AllowDBNull = True
                    tab.Columns.Add(col)
                Next intColumn
            End If

            ' add table to dataset
            crosstab.Tables.Add(tab)

            ' add rows to table
            intKeyColumn = -1
            Dim row As DataRow
            While result.Read()
                ' loop using KeyColumn as control break
                If Convert.ToInt32(result(KeyColumn)) <> intKeyColumn Then
                    ' add row
                    If intKeyColumn <> -1 Then
                        tab.Rows.Add(row)
                    End If

                    ' create new row
                    row = tab.NewRow()

                    ' assign fixed column values
                    For intColumn = LBound(arrFixedColumns) To UBound(arrFixedColumns)
                        arrField = arrFixedColumns(intColumn).Split("|".ToCharArray())
                        row(arrField(0)) = result(arrField(0))
                    Next intColumn

                    ' initialize variable column values
                    If VariableColumns <> "" Then
                        For intColumn = LBound(arrVariableColumns) To UBound(arrVariableColumns)
                            arrField = arrVariableColumns(intColumn).Split("|".ToCharArray())
                            Select Case arrField(1)
                                Case "Decimal"
                                    row(arrField(0)) = 0
                                Case "String"
                                    row(arrField(0)) = ""
                            End Select
                        Next intColumn
                    End If

                    intKeyColumn = Convert.ToInt32(result(KeyColumn))
                End If

                ' assign pivot column value
                If FieldTypeColumn <> "" Then
                    FieldType = result(FieldTypeColumn).ToString
                Else
                    FieldType = "String"
                End If
                Select Case FieldType
                    Case "Decimal" ' decimal
                        row(Convert.ToInt32(result(FieldColumn))) = result(NumericValueColumn)
                    Case "String" ' string
                        row(result(FieldColumn).ToString) = result(StringValueColumn)
                End Select
            End While

            result.Close()

            ' add row
            If intKeyColumn <> -1 Then
                tab.Rows.Add(row)
            End If

            ' finalize dataset
            crosstab.AcceptChanges()

            ' return the dataset
            Return crosstab

        End Function

        Public Class FileItem
            Private _Value As String
            Private _Text As String

            Public Sub New(ByVal Value As String, ByVal Text As String)
                _Value = Value
                _Text = Text
            End Sub

            Public ReadOnly Property Value() As String
                Get
                    Return _Value
                End Get
            End Property

            Public ReadOnly Property Text() As String
                Get
                    Return _Text
                End Get
            End Property

        End Class

        ' get list of files from folder matching criteria
        Public Function GetFileList(Optional ByVal PortalId As Integer = -1, Optional ByVal strExtensions As String = "", Optional ByVal NoneSpecified As Boolean = True) As ArrayList
            Dim arrFileList As New ArrayList

            If NoneSpecified Then
                arrFileList.Add(New FileItem("", "<None Specified>"))
            End If

            Dim objFiles As New FileController

            Dim dr As IDataReader = objFiles.GetFiles(PortalId)
            While dr.Read()
                If InStr(1, strExtensions.ToUpper, dr("Extension").ToString.ToUpper) <> 0 Or strExtensions = "" Then
                    arrFileList.Add(New FileItem(dr("FileName").ToString, dr("FileName").ToString))
                End If

            End While
            dr.Close()

            GetFileList = arrFileList
        End Function

        ' format an address on a single line ( ie. Unit, Street, City, Region, Country, PostalCode )
        Public Function FormatAddress(ByVal Unit As Object, ByVal Street As Object, ByVal City As Object, ByVal Region As Object, ByVal Country As Object, ByVal PostalCode As Object) As String

            Dim strAddress As String = ""

            If Not Unit Is Nothing Then
                If Trim(Unit.ToString()) <> "" Then
                    strAddress += ", " & Unit.ToString
                End If
            End If
            If Not Street Is Nothing Then
                If Trim(Street.ToString()) <> "" Then
                    strAddress += ", " & Street.ToString
                End If
            End If
            If Not City Is Nothing Then
                If Trim(City.ToString()) <> "" Then
                    strAddress += ", " & City.ToString
                End If
            End If
            If Not Region Is Nothing Then
                If Trim(Region.ToString()) <> "" Then
                    strAddress += ", " & Region.ToString
                End If
            End If
            If Not Country Is Nothing Then
                If Trim(Country.ToString()) <> "" Then
                    strAddress += ", " & Country.ToString
                End If
            End If
            If Not PostalCode Is Nothing Then
                If Trim(PostalCode.ToString()) <> "" Then
                    strAddress += ", " & PostalCode.ToString
                End If
            End If
            If Trim(strAddress) <> "" Then
                strAddress = Mid(strAddress, 3)
            End If

            FormatAddress = strAddress

        End Function

        ' format an email address including link
        Public Function FormatEmail(ByVal Email As Object) As String

            If Not IsDBNull(Email) Then
                If Trim(Email.ToString()) <> "" Then
                    If Email.ToString.IndexOf("@") <> -1 Then
                        FormatEmail = "<a href=""mailto:" & Email.ToString() & """>" & Email.ToString() & "</a>"
                    Else
                        FormatEmail = Email.ToString()
                    End If
                End If
            End If

            Return CloakText(FormatEmail)

        End Function

        ' format a domain name including link
        Public Function FormatWebsite(ByVal Website As Object) As String

            If Not IsDBNull(Website) Then
                If Trim(Website.ToString()) <> "" Then
                    If Convert.ToBoolean(InStr(1, Website.ToString(), ".")) Then
                        FormatWebsite = "<a href=""" & IIf(Convert.ToBoolean(InStr(1, Website.ToString(), "://")), "", "http://").ToString & Website.ToString() & """>" & Website.ToString() & "</a>"
                    Else
                        FormatWebsite = Website.ToString()
                    End If
                End If
            End If

        End Function

        ' obfuscate sensitive data to prevent collection by robots and spiders and crawlers
        Public Function CloakText(ByVal PersonalInfo As String) As String
            Dim sb As New StringBuilder

            ' convert to ASCII character codes
            sb.Remove(0, sb.Length)
            Dim StringLength As Integer = PersonalInfo.Length - 1
            For i As Integer = 0 To StringLength
                sb.Append(Asc(PersonalInfo.Substring(i, 1)).ToString)
                If i < StringLength Then
                    sb.Append(",")
                End If
            Next

            ' build script block
            Dim sbScript As New StringBuilder

            sbScript.Append(vbCrLf & "<script language=""javascript"">" & vbCrLf)
            sbScript.Append("<!-- " & vbCrLf)
            sbScript.Append("   document.write(String.fromCharCode(" & sb.ToString & "))" & vbCrLf)
            sbScript.Append("// -->" & vbCrLf)
            sbScript.Append("</script>" & vbCrLf)

            Return sbScript.ToString

        End Function

        ' returns an arraylist of tabitems for a portal
        Public Function GetPortalTabs(ByVal objDesktopTabs As ArrayList, Optional ByVal blnNoneSpecified As Boolean = False, Optional ByVal blnHidden As Boolean = False, Optional ByVal blnDeleted As Boolean = False) As ArrayList

            Dim arrPortalTabs As ArrayList = New ArrayList
            Dim objPortalTab As TabItem
            Dim objTab As TabStripDetails

            If blnNoneSpecified Then
                objPortalTab = New TabItem
                objPortalTab.TabId = -1
                objPortalTab.TabName = "<None Specified>"
                objPortalTab.TabOrder = 0
                objPortalTab.ParentId = -2
                arrPortalTabs.Add(objPortalTab)
            End If

            Dim intCounter As Integer
            Dim strIndent As String

            For Each objTab In objDesktopTabs
                If IsAdminTab(objTab.TabId, objTab.ParentId) = False And (objTab.IsVisible = True Or blnHidden = True) And (objTab.IsDeleted = False Or blnDeleted = True) Then
                    strIndent = ""
                    For intCounter = 1 To objTab.Level
                        strIndent += "..."
                    Next

                    objPortalTab = New TabItem
                    objPortalTab.TabId = objTab.TabId
                    objPortalTab.TabName = strIndent & objTab.TabName
                    objPortalTab.TabOrder = objTab.TabOrder
                    objPortalTab.ParentId = objTab.ParentId
                    arrPortalTabs.Add(objPortalTab)
                End If
            Next

            Return arrPortalTabs

        End Function

        ' returns a SQL Server compatible date
        Public Function GetMediumDate(ByVal strDate As String) As String

            If strDate <> "" Then
                Dim datDate As Date = Convert.ToDateTime(strDate)

                Dim strYear As String = Year(datDate).ToString
                Dim strMonth As String = MonthName(Month(datDate), True)
                Dim strDay As String = Day(datDate).ToString

                strDate = strDay & "-" & strMonth & "-" & strYear
            End If

            Return strDate

        End Function

        ' returns a SQL Server compatible date
        Public Function GetShortDate(ByVal strDate As String) As String

            If strDate <> "" Then
                Dim datDate As Date = Convert.ToDateTime(strDate)

                Dim strYear As String = Year(datDate).ToString
                Dim strMonth As String = Month(datDate).ToString
                Dim strDay As String = Day(datDate).ToString

                strDate = strMonth & "/" & strDay & "/" & strYear
            End If

            Return strDate

        End Function

        ' returns a boolean value whether the tab is an admin tab
        Public Function IsAdminTab(ByVal intTabId As Integer, ByVal intParentId As Integer) As Boolean

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Return (intTabId = _portalSettings.AdminTabId) Or _
                    (intParentId = _portalSettings.AdminTabId) Or _
                    (intTabId = _portalSettings.SuperTabId) Or _
                    (intParentId = _portalSettings.SuperTabId)

        End Function

        ' returns a boolean value whether the control is an admin control
        Public Function IsAdminControl() As Boolean

            Return (IsNothing(HttpContext.Current.Request.QueryString("mid")) = False) Or _
                (IsNothing(HttpContext.Current.Request.QueryString("def")) = False) Or _
                (IsNothing(HttpContext.Current.Request.QueryString("ctl")) = False)

        End Function

        ' Deprecated PreventSQLInjection Function to consolidate Security Filter functions in the PortalSecurity class.
        Public Function PreventSQLInjection(ByVal strSQL As String) As String
            Return (New PortalSecurity).InputFilter(strSQL, PortalSecurity.FilterFlag.NoSQL)
        End Function

        ' creates RRS files
        Public Sub CreateRSS(ByVal dr As IDataReader, ByVal TitleField As String, ByVal URLField As String, ByVal CreatedDateField As String, ByVal SyndicateField As String, ByVal DomainName As String, ByVal FileName As String)

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' create RSS file
            Dim strRSS As String = ""

            Dim strRelativePath As String = DomainName & Replace(Mid(FileName, InStr(1, FileName, "\Portals")), "\", "/")
            strRelativePath = Left(strRelativePath, InStrRev(strRelativePath, "/"))

            While dr.Read()
                If Convert.ToBoolean(dr(SyndicateField)) Then
                    strRSS += "      <item>" & ControlChars.CrLf
                    strRSS += "         <title>" & dr(TitleField).ToString & "</title>" & ControlChars.CrLf
                    If InStr(1, dr("URL").ToString, "://") = 0 Then
                        If IsNumeric(dr("URL").ToString) Then
                            strRSS += "         <link>" & DomainName & "/DesktopDefault.aspx?tabid=" & dr(URLField).ToString & "</link>" & ControlChars.CrLf
                        Else
                            strRSS += "         <link>" & strRelativePath & dr(URLField).ToString & "</link>" & ControlChars.CrLf
                        End If
                    Else
                        strRSS += "         <link>" & dr(URLField).ToString & "</link>" & ControlChars.CrLf
                    End If
                    strRSS += "         <description>" & _portalSettings.PortalName & " " & GetMediumDate(dr(CreatedDateField).ToString) & "</description>" & ControlChars.CrLf
                    strRSS += "     </item>" & ControlChars.CrLf
                End If
            End While
            dr.Close()

            If strRSS <> "" Then
                strRSS = "<?xml version=""1.0"" encoding=""iso-8859-1""?>" & ControlChars.CrLf & _
                    "<rss version=""0.91"">" & ControlChars.CrLf & _
                    "  <channel>" & ControlChars.CrLf & _
                    "     <title>" & _portalSettings.PortalName & "</title>" & ControlChars.CrLf & _
                    "     <link>" & DomainName & "</link>" & ControlChars.CrLf & _
                    "     <description>" & _portalSettings.PortalName & "</description>" & ControlChars.CrLf & _
                    "     <language>en-us</language>" & ControlChars.CrLf & _
                    "     <copyright>" & _portalSettings.FooterText & "</copyright>" & ControlChars.CrLf & _
                    "     <webMaster>" & _portalSettings.Email & "</webMaster>" & ControlChars.CrLf & _
                    strRSS & _
                    "   </channel>" & ControlChars.CrLf & _
                    "</rss>"

                Dim objStream As StreamWriter
                objStream = File.CreateText(FileName)
                objStream.WriteLine(strRSS)
                objStream.Close()
            Else
                If File.Exists(FileName) Then
                    File.Delete(FileName)
                End If
            End If

        End Sub

        ' injects the upload directory into raw HTML for src and background tags
        Public Function ManageUploadDirectory(ByVal strHTML As String, ByVal strUploadDirectory As String) As String

            Dim P As Integer

            ManageUploadDirectory = ""

            If strHTML <> "" Then
                P = InStr(1, strHTML.ToLower, "src=""")
                While P <> 0
                    ManageUploadDirectory = ManageUploadDirectory & Left(strHTML, P + 4)

                    strHTML = Mid(strHTML, P + 5)

                    ' add uploaddirectory if we are linking internally
                    If InStr(1, strHTML, "://") = 0 Then
                        strHTML = strUploadDirectory & strHTML
                    End If

                    P = InStr(1, strHTML.ToLower, "src=""")
                End While
                ManageUploadDirectory = ManageUploadDirectory & strHTML

                strHTML = ManageUploadDirectory
                ManageUploadDirectory = ""

                P = InStr(1, strHTML.ToLower, "background=""")
                While P <> 0
                    ManageUploadDirectory = ManageUploadDirectory & Left(strHTML, P + 11)

                    strHTML = Mid(strHTML, P + 12)

                    ' add uploaddirectory if we are linking internally
                    If InStr(1, strHTML, "://") = 0 Then
                        strHTML = strUploadDirectory & strHTML
                    End If

                    P = InStr(1, strHTML.ToLower, "background=""")
                End While
            End If

            ManageUploadDirectory = ManageUploadDirectory & strHTML

        End Function

        ' returns the database connection string
        Public Function GetDBConnectionString() As String
            Return ConfigurationSettings.AppSettings("connectionString")
        End Function

        ' uses recursion to search the control hierarchy for a specific control based on controlname
        Public Function FindControlRecursive(ByVal objControl As Control, ByVal strControlName As String) As Control
            If objControl.Parent Is Nothing Then
                Return Nothing
            Else
                If Not objControl.Parent.FindControl(strControlName) Is Nothing Then
                    Return objControl.Parent.FindControl(strControlName)
                Else
                    Return FindControlRecursive(objControl.Parent, strControlName)
                End If
            End If
        End Function

        'set focus to any control
        Public Sub SetFormFocus(ByVal control As Control)
            If Not control.Page Is Nothing And control.Visible Then
                If control.Page.Request.Browser.JavaScript = True Then

                    ' Create JavaScript 
                    Dim sb As New System.Text.StringBuilder
                    sb.Append("<SCRIPT LANGUAGE='JavaScript'>")
                    sb.Append("<!--")
                    sb.Append(ControlChars.Lf)
                    sb.Append("function SetInitialFocus() {")
                    sb.Append(ControlChars.Lf)
                    sb.Append(" document.")

                    ' Find the Form 
                    Dim objParent As control = control.Parent
                    While Not TypeOf objParent Is System.Web.UI.HtmlControls.HtmlForm
                        objParent = objParent.Parent
                    End While
                    sb.Append(objParent.ClientID)
                    sb.Append("['")
                    sb.Append(control.UniqueID)
                    sb.Append("'].focus(); }")
                    sb.Append("window.onload = SetInitialFocus;")
                    sb.Append(ControlChars.Lf)
                    sb.Append("// -->")
                    sb.Append(ControlChars.Lf)
                    sb.Append("</SCRIPT>")

                    ' Register Client Script 
                    control.Page.RegisterClientScriptBlock("InitialFocus", sb.ToString())
                End If
            End If
        End Sub

        Public Function GetExternalRequest(ByVal Address As String) As HttpWebRequest
            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Create the request object
            Dim objRequest As HttpWebRequest = CType(WebRequest.Create(Address), HttpWebRequest)

            ' Set a time out to the request ... 10 seconds
            If Not _portalSettings.HostSettings("WebRequestTimeout") Is Nothing Then
                objRequest.Timeout = Integer.Parse(CType(_portalSettings.HostSettings("WebRequestTimeout"), String))
            Else
                objRequest.Timeout = 10000
            End If

            ' Attach a User Agent to the request
            objRequest.UserAgent = "DotNetNuke"

            ' If there is Proxy info, apply it to the Request
            If CType(_portalSettings.HostSettings("ProxyServer"), String) <> "" Then

                ' Create a new Proxy
                Dim Proxy As WebProxy

                ' Create a new Network Credentials item
                Dim ProxyCredentials As NetworkCredential

                ' Fill Proxy info from host settings
                Proxy = New WebProxy(CType(_portalSettings.HostSettings("ProxyServer"), String), Convert.ToInt32(_portalSettings.HostSettings("ProxyPort")))

                If Not CType(_portalSettings.HostSettings("ProxyUsername"), String) = "" Then
                    ' Fill the credential info from host settings
                    ProxyCredentials = New NetworkCredential(CType(_portalSettings.HostSettings("ProxyUsername"), String), CType(_portalSettings.HostSettings("ProxyPassword"), String))

                    'Apply credentials to proxy
                    Proxy.Credentials = ProxyCredentials
                End If

                ' Apply Proxy to Request
                objRequest.Proxy = Proxy

            End If
            Return objRequest
        End Function

        Public Function GetExternalRequest(ByVal Address As String, ByVal Credentials As NetworkCredential) As HttpWebRequest

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Create the request object
            Dim objRequest As HttpWebRequest = CType(WebRequest.Create(Address), HttpWebRequest)

            ' Set a time out to the request ... 10 seconds
            If Not _portalSettings.HostSettings("WebRequestTimeout") Is Nothing Then
                objRequest.Timeout = Integer.Parse(CType(_portalSettings.HostSettings("WebRequestTimeout"), String))
            Else
                objRequest.Timeout = 10000
            End If

            ' Attach a User Agent to the request
            objRequest.UserAgent = "DotNetNuke"

            ' Attach supplied credentials
            If Not Credentials.UserName Is Nothing Then
                objRequest.Credentials = Credentials
            End If

            ' If there is Proxy info, apply it to the Request
            If CType(_portalSettings.HostSettings("ProxyServer"), String) <> "" Then

                ' Create a new Proxy
                Dim Proxy As WebProxy

                ' Create a new Network Credentials item
                Dim ProxyCredentials As NetworkCredential

                ' Fill Proxy info from host settings
                Proxy = New WebProxy(CType(_portalSettings.HostSettings("ProxyServer"), String), Convert.ToInt32(_portalSettings.HostSettings("ProxyPort")))

                If Not CType(_portalSettings.HostSettings("ProxyUsername"), String) = "" Then
                    ' Fill the credential info from host settings
                    ProxyCredentials = New NetworkCredential(CType(_portalSettings.HostSettings("ProxyUsername"), String), CType(_portalSettings.HostSettings("ProxyPassword"), String))

                    'Apply credentials to proxy
                    Proxy.Credentials = ProxyCredentials
                End If

                ' Apply Proxy to Request
                objRequest.Proxy = Proxy

            End If
            Return objRequest
        End Function

        Public Sub DeleteFolderRecursive(ByVal strRoot As String)
            If strRoot <> "" Then
                Dim strFolder As String
                If Directory.Exists(strRoot) Then
                    For Each strFolder In Directory.GetDirectories(strRoot)
                        DeleteFolderRecursive(strFolder)
                    Next
                    Dim strFile As String
                    For Each strFile In Directory.GetFiles(strRoot)
                        File.SetAttributes(strFile, FileAttributes.Normal)
                        File.Delete(strFile)
                    Next
                    Directory.Delete(strRoot)
                End If
            End If
        End Sub

        Public Function CreateValidID(ByVal strID As String) As String

            Dim strBadCharacters As String = " ./-\"

            Dim intIndex As Integer
            For intIndex = 0 To strBadCharacters.Length - 1
                strID = strID.Replace(strBadCharacters.Substring(intIndex, 1), "_")
            Next

            Return strID

        End Function

        Public Function ApplicationURL() As String

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Return ("~/" & glbDefaultPage & "?tabid=" & _portalSettings.ActiveTab.TabId.ToString)

        End Function

    End Module

End Namespace
