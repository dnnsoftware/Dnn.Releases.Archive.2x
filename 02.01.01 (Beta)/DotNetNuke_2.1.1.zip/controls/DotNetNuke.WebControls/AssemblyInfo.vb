Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Web.UI

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("DotNetNuke")> 
<Assembly: AssemblyDescription("ASP.NET Open Source Web Controls")> 
<Assembly: AssemblyCompany("Perpetual Motion Interactive Systems Inc.")> 
<Assembly: AssemblyProduct("http://www.dotnetnuke.com")> 
<Assembly: AssemblyCopyright("DotNetNuke Web Control source code is copyright &copy; 2002-YYYY by DotNetNuke. All Rights Reserved")> 
<Assembly: AssemblyTrademark("DotNetNuke")> 
<Assembly: TagPrefix("DotNetNuke.Web.UI.WebControls", "DNN")> 
<Assembly: CLSCompliant(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("1CDFE09D-9111-4ABE-8CF4-02D1FDC157A7")> 


<Assembly: AssemblyVersion("1.0.*")> 
