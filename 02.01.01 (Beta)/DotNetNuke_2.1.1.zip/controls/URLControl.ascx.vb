'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System.IO

Namespace DotNetNuke

    Public Class URLControl

        Inherits System.Web.UI.UserControl

        Protected WithEvents optURL As System.Web.UI.WebControls.RadioButtonList
        Protected WithEvents cboURL As System.Web.UI.WebControls.DropDownList
        Protected WithEvents txtURL As System.Web.UI.WebControls.TextBox
        Protected WithEvents cmdURL As System.Web.UI.WebControls.LinkButton
        Protected WithEvents chkLog As System.Web.UI.WebControls.CheckBox

        Private _Width As String = ""
        Private _ShowUrls As Boolean = True
        Private _ShowTabs As Boolean = True
        Private _ShowFiles As Boolean = True
        Private _URL As String = "NEW"

        ' public properties
        Public Property Width() As String
            Get
                Width = Convert.ToString(ViewState("SkinControlWidth"))
            End Get
            Set(ByVal Value As String)
                _Width = Value
            End Set
        End Property

        Public WriteOnly Property ShowUrls() As Boolean
            Set(ByVal Value As Boolean)
                _ShowUrls = Value
            End Set
        End Property

        Public WriteOnly Property ShowTabs() As Boolean
            Set(ByVal Value As Boolean)
                _ShowTabs = Value
            End Set
        End Property

        Public WriteOnly Property ShowFiles() As Boolean
            Set(ByVal Value As Boolean)
                _ShowFiles = Value
            End Set
        End Property

        Public Property URL() As String
            Get
                ' Obtain PortalSettings from Current Context
                Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

                URL = ""

                Select Case optURL.SelectedItem.Value
                    Case "U"
                        If cboURL.Visible Then
                            If Not cboURL.SelectedItem Is Nothing Then
                                URL = cboURL.SelectedItem.Value
                            End If
                        Else
                            URL = AddHTTP(txtURL.Text)
                        End If
                    Case "T"
                        If Not cboURL.SelectedItem Is Nothing Then
                            URL = cboURL.SelectedItem.Value
                        End If
                    Case "F"
                        If Not cboURL.SelectedItem Is Nothing Then
                            URL = cboURL.SelectedItem.Value
                        End If
                End Select
            End Get
            Set(ByVal Value As String)
                _URL = Value
            End Set
        End Property

        Public ReadOnly Property UrlType() As String
            Get
                UrlType = optURL.SelectedItem.Value
            End Get
        End Property

        Public ReadOnly Property Log() As Boolean
            Get
                Log = chkLog.Checked
            End Get
        End Property

#Region " Web Form Designer Generated Code "


        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this page is used
        ' to populate the role information for the page
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                If Not Page.IsPostBack Then

                    ' set width of control
                    If _Width <> "" Then
                        cboURL.Width = System.Web.UI.WebControls.Unit.Parse(_Width)
                        txtURL.Width = System.Web.UI.WebControls.Unit.Parse(_Width)
                    End If

                    If _ShowUrls Then
                        optURL.Items.Add(New ListItem("URL", "U"))
                    End If
                    If _ShowTabs Then
                        optURL.Items.Add(New ListItem("Tab", "T"))
                    End If
                    If _ShowFiles Then
                        optURL.Items.Add(New ListItem("File", "F"))
                    End If

                    ShowControls()

                    ' save persistent values
                    ViewState("SkinControlWidth") = _Width

                End If

            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub optURL_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles optURL.SelectedIndexChanged
            ShowControls()
        End Sub

        Private Sub cmdURL_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdURL.Click

            Select Case cmdURL.Text
                Case "Add"
                    cboURL.Visible = False
                    txtURL.Visible = True
                    cmdURL.Text = "Select"
                Case "Select"
                    cboURL.Visible = True
                    txtURL.Visible = False
                    cmdURL.Text = "Add"
                Case "Upload"
                    Response.Redirect(ApplicationURL() & "&ctl=File Manager", True)
            End Select

        End Sub

        Private Sub ShowControls()

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim objUrls As New UrlController

            If optURL.SelectedItem Is Nothing Then
                If _URL <> "" And _URL <> "NEW" Then
                    Dim objUrlTracking As UrlTrackingInfo = objUrls.GetUrlTracking(_portalSettings.PortalId, _URL)
                    If Not objUrlTracking Is Nothing Then
                        optURL.Items.FindByValue(objUrlTracking.UrlType).Selected = True
                        chkLog.Checked = objUrlTracking.LogActivity
                    Else
                        optURL.Items.FindByValue("U").Selected = True
                        chkLog.Checked = False
                        txtURL.Text = _URL
                    End If
                Else
                    optURL.Items(0).Selected = True
                    chkLog.Checked = False
                End If
            End If

            cboURL.Items.Clear()

            Select Case optURL.SelectedItem.Value
                Case "U" ' url
                    Select Case _URL
                        Case "NEW" ' adding a url for a new item
                            cboURL.Visible = True
                            txtURL.Visible = False
                            cmdURL.Text = "Add"
                            cmdURL.Visible = True
                        Case "" ' existing item with url not set
                            cboURL.Visible = False
                            txtURL.Visible = True
                            cmdURL.Text = "Select"
                            cmdURL.Visible = True
                        Case Else ' existing item with url set
                            If txtURL.Text = "" Then
                                cboURL.Visible = True
                                txtURL.Visible = False
                                cmdURL.Text = "Add"
                                cmdURL.Visible = True
                            Else ' url specified does not exist in urltracking table
                                cboURL.Visible = False
                                txtURL.Visible = True
                                cmdURL.Text = "Select"
                                cmdURL.Visible = True
                            End If
                    End Select
                    cboURL.DataSource = objUrls.GetUrls(_portalSettings.PortalId)
                    cboURL.DataValueField = "URL"
                    cboURL.DataTextField = "URL"
                Case "T" ' tab
                    cboURL.Visible = True
                    txtURL.Visible = False
                    cmdURL.Visible = False
                    cboURL.DataSource = GetPortalTabs(_portalSettings.DesktopTabs, False, True)
                    cboURL.DataValueField = "TabId"
                    cboURL.DataTextField = "TabName"
                Case "F" ' file
                    cboURL.Visible = True
                    txtURL.Visible = False
                    cmdURL.Text = "Upload"
                    cmdURL.Visible = True
                    cboURL.DataSource = GetFileList(_portalSettings.PortalId, "", False)
                    cboURL.DataValueField = "Value"
                    cboURL.DataTextField = "Text"
            End Select

            cboURL.DataBind()

            If Not cboURL.Items.FindByValue(_URL) Is Nothing Then
                cboURL.Items.FindByValue(_URL).Selected = True
            End If

        End Sub

    End Class

End Namespace
