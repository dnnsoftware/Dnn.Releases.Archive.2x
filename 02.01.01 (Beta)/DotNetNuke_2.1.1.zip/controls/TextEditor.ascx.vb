
Namespace DotNetNuke

    Public Class TextEditor
        Inherits System.Web.UI.UserControl

        Protected WithEvents optView As System.Web.UI.WebControls.RadioButtonList
        Protected WithEvents txtDesktopHTML As System.Web.UI.WebControls.TextBox
        Protected WithEvents optRender As System.Web.UI.WebControls.RadioButtonList
        Protected WithEvents pnlBasicTextBox As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlBasicRender As System.Web.UI.WebControls.Panel
        Protected WithEvents plcEditor As System.Web.UI.WebControls.PlaceHolder
        Protected WithEvents pnlRichTextBox As System.Web.UI.WebControls.Panel


        Protected WithEvents pnlOption As System.Web.UI.WebControls.Panel

        Private _ChooseMode As Boolean = True
        Private _ChooseRender As Boolean = True
        Private _HtmlEncode As Boolean = True
        Public Width As System.Web.UI.WebControls.Unit
        Public Height As System.Web.UI.WebControls.Unit

        Private RichText As HtmlEditorProvider


        Public Property HtmlEncode() As Boolean
            Get
                HtmlEncode = _HtmlEncode
            End Get
            Set(ByVal Value As Boolean)
                _HtmlEncode = Value
            End Set
        End Property

        Public Property ChooseMode() As Boolean
            Get
                ChooseMode = _ChooseMode
            End Get
            Set(ByVal Value As Boolean)
                _ChooseMode = Value
            End Set
        End Property


        'Determines wether or not the Text/Html button is rendered for Basic mode
        'Default is True
        Public Property ChooseRender() As Boolean
            Get
                ChooseRender = _ChooseRender
            End Get
            Set(ByVal Value As Boolean)
                _ChooseRender = Value
            End Set
        End Property

        Public Property DefaultMode() As String
            Get
                If CType(Me.ViewState.Item("DefaultMode"), String) = "" Then
                    DefaultMode = "B"  ' default to basic
                Else
                    DefaultMode = CType(Me.ViewState.Item("DefaultMode"), String)
                End If
            End Get
            Set(ByVal Value As String)
                If Value.ToUpper <> "BASIC" Then
                    Me.ViewState.Item("DefaultMode") = "R"
                Else
                    Me.ViewState.Item("DefaultMode") = "B"
                End If
            End Set
        End Property

        Public Property Mode() As String
            Get
                If Request.Cookies("desktopview") Is Nothing Then
                    Mode = Nothing
                Else
                    Mode = Request.Cookies("desktopview").Value()
                End If
            End Get
            Set(ByVal Value As String)
                Response.Cookies("desktopview").Value() = Value
                If Not Context.User.Identity.Name Is Nothing Then
                    Personalization.SetProfile("DotNetNuke.TextEditor", "PreferredTextEditor", Value)
                End If
            End Set
        End Property

        Public Property Text() As String
            Get
                If optView.SelectedItem.Value = "B" Then
                    If optRender.SelectedItem.Value = "T" Then
                        Text = FormatHtml(txtDesktopHTML.Text)
                    Else
                        Text = txtDesktopHTML.Text
                    End If
                Else
                    Text = Encode(RichText.Text)
                End If
            End Get
            Set(ByVal Value As String)
                If Value <> "" Then
                    txtDesktopHTML.Text = FormatText(Value)
                    RichText.Text = Decode(Value)
                Else
                    RichText.Text = "Add Content..."
                    txtDesktopHTML.Text = "Add Content..."
                End If
            End Set
        End Property



#Region " Web Form Designer Generated Code "


        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            RichText = RichText.Instance
            InitializeComponent()
        End Sub

#End Region


        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try


                RichText.Width = Width
                RichText.Height = Height
                txtDesktopHTML.Height = Height
                txtDesktopHTML.Width = Width

                plcEditor.Controls.Add(RichText.HtmlEditorControl)


                If Not ChooseMode Or Context.User.Identity.Name = "" Then
                    Mode = DefaultMode
                Else
                    If Not Personalization.GetProfile("DotNetNuke.TextEditor", "PreferredTextEditor") Is Nothing Then
                        Mode = CType(Personalization.GetProfile("DotNetNuke.TextEditor", "PreferredTextEditor"), String)
                    Else
                        If Mode Is Nothing Then
                            Mode = DefaultMode
                        End If
                    End If
                End If

                Dim DesktopView As String = Mode
                Dim LastDesktopView As String = DesktopView

                If Not ChooseMode Then
                    pnlOption.Visible = False
                End If

                If Not ChooseRender Then
                    pnlBasicRender.Visible = False
                End If

                If optView.SelectedIndex <> -1 Then
                    DesktopView = optView.SelectedItem.Value
                    Dim objModules As New ModuleController
                    Mode = DesktopView
                End If

                If DesktopView <> "" Then
                    optView.Items.FindByValue(DesktopView).Selected = True
                Else
                    optView.SelectedIndex = 0
                End If

                Dim TextRender As String = CType(Me.ViewState.Item("textrender"), String)

                If optRender.SelectedIndex <> -1 Then
                    TextRender = optRender.SelectedItem.Value
                    Dim objModules As New ModuleController
                    Me.ViewState.Item("textrender") = TextRender
                End If

                If TextRender <> "" Then
                    optRender.Items.FindByValue(TextRender).Selected = True
                Else
                    optRender.SelectedIndex = 0
                End If

                If optView.SelectedItem.Value = "B" Then
                    pnlBasicTextBox.Visible = True
                    pnlRichTextBox.Visible = False
                Else
                    pnlBasicTextBox.Visible = False
                    pnlRichTextBox.Visible = True
                End If

            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        Private Function FormatText(ByVal strHtml As String) As String
            Try
                Dim strText As String = strHtml

                If strText <> "" Then
                    strText = Replace(strText, "<br>", ControlChars.Lf)
                    strText = Replace(strText, "<BR>", ControlChars.Lf)
                    strText = Decode(strText)
                End If

                Return strText

            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

        Private Function FormatHtml(ByVal strText As String) As String
            Try

                Dim strHtml As String = strText

                If strHtml <> "" Then
                    strHtml = Replace(strHtml, Chr(13), "")
                    strHtml = Replace(strHtml, ControlChars.Lf, "<br>")
                End If

                Return strHtml

            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

        End Function

        Private Sub optView_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optView.SelectedIndexChanged
            If optView.SelectedItem.Value = "B" Then
                If optRender.SelectedItem.Value = "T" Then
                    txtDesktopHTML.Text = FormatText(RichText.Text)
                Else
                    txtDesktopHTML.Text = RichText.Text
                End If
            Else
                If optRender.SelectedItem.Value = "T" Then
                    RichText.Text = FormatHtml(txtDesktopHTML.Text)
                Else
                    RichText.Text = txtDesktopHTML.Text
                End If
            End If
        End Sub

        Private Sub optRender_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optRender.SelectedIndexChanged
            If optView.SelectedItem.Value = "B" Then
                If optRender.SelectedItem.Value = "T" Then
                    txtDesktopHTML.Text = FormatText(txtDesktopHTML.Text)
                Else
                    txtDesktopHTML.Text = FormatHtml(txtDesktopHTML.Text)
                End If
            End If
        End Sub

        Private Function Encode(ByVal strHtml As String) As String
            If Me.HtmlEncode Then
                Encode = Server.HtmlEncode(strHtml)
            Else
                Encode = strHtml
            End If
        End Function

        Private Function Decode(ByVal strHtml As String) As String
            If Me.HtmlEncode Then
                Decode = Server.HtmlDecode(strHtml)
            Else
                Decode = strHtml
            End If
        End Function

    End Class


End Namespace
