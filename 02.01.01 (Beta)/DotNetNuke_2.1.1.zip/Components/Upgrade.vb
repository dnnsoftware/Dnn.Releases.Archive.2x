'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System
Imports System.IO
Imports System.Xml

Namespace DotNetNuke

    Public Class Upgrade

        Public Shared Sub AutoUpgrade()

            Dim strUpgrade As String = VerifyFolderPermissions()

            If strUpgrade = "" Then
                ' Get the name of the data provider
                Dim objProviderConfiguration As ProviderConfiguration = ProviderConfiguration.GetProviderConfiguration("data")

                ' get path to script files
                Dim strProviderPath As String = PortalSettings.GetProviderPath()
                If Not strProviderPath.StartsWith("ERROR:") Then
                    Dim strAssemblyVersion As String
                    Dim strDatabaseVersion As String

                    ' get current assembly version
                    Dim intAssemblyMajor As Integer = System.Diagnostics.FileVersionInfo.GetVersionInfo(Global.AssemblyPath).ProductMajorPart()
                    Dim intAssemblyMinor As Integer = System.Diagnostics.FileVersionInfo.GetVersionInfo(Global.AssemblyPath).ProductMinorPart()
                    Dim intAssemblyBuild As Integer = System.Diagnostics.FileVersionInfo.GetVersionInfo(Global.AssemblyPath).ProductBuildPart()
                    strAssemblyVersion = Format(intAssemblyMajor, "00") & Format(intAssemblyMinor, "00") & Format(intAssemblyBuild, "00")

                    ' get current database version
                    Dim dr As IDataReader = PortalSettings.GetDatabaseVersion
                    If dr.Read Then
                        strDatabaseVersion = Format(dr("Major"), "00") & Format(dr("Minor"), "00") & Format(dr("Build"), "00")
                    End If
                    dr.Close()

                    ' get list of script files
                    Dim strScriptVersion As String
                    Dim arrScriptFiles As New ArrayList
                    Dim strFile As String
                    Dim arrFiles As String() = Directory.GetFiles(strProviderPath, "*." & objProviderConfiguration.DefaultProvider)
                    For Each strFile In arrFiles
                        ' script file name must conform to ##.##.##.DefaultProviderName
                        If Len(Path.GetFileName(strFile)) = 9 + Len(objProviderConfiguration.DefaultProvider) Then
                            strScriptVersion = Path.GetFileNameWithoutExtension(strFile)
                            ' check if script file is relevant for upgrade
                            If strScriptVersion.Replace(".", "") > strDatabaseVersion And strScriptVersion.Replace(".", "") <= strAssemblyVersion Then
                                arrScriptFiles.Add(strFile)
                            End If
                        End If
                    Next
                    arrScriptFiles.Sort()

                    Dim strScriptFile As String
                    For Each strScriptFile In arrScriptFiles
                        strScriptVersion = Path.GetFileNameWithoutExtension(strScriptFile)

                        Dim arrVersion As Array = strScriptVersion.Split(CType(".", Char))
                        Dim intMajor As Integer = CType(arrVersion.GetValue((0)), Integer)
                        Dim intMinor As Integer = CType(arrVersion.GetValue((1)), Integer)
                        Dim intBuild As Integer = CType(arrVersion.GetValue((2)), Integer)

                        ' verify script has not already been run
                        If Not PortalSettings.FindDatabaseVersion(intMajor, intMinor, intBuild) Then
                            ' upgrade database schema
                            PortalSettings.UpgradeDatabaseSchema(intMajor, intMinor, intBuild)

                            ' read script file for version
                            Dim objStreamReader As StreamReader
                            objStreamReader = File.OpenText(strScriptFile)
                            Dim strScript As String = objStreamReader.ReadToEnd
                            objStreamReader.Close()

                            ' execute SQL installation script
                            Dim strExceptions As String = PortalSettings.ExecuteScript(strScript)

                            ' perform file system upgrades
                            strExceptions += UpgradeApplication(strScriptVersion)

                            ' log the results
                            Try
                                Dim objStream As StreamWriter
                                objStream = File.CreateText(strScriptFile.Replace("." & objProviderConfiguration.DefaultProvider, "") & ".log")
                                objStream.WriteLine(strExceptions)
                                objStream.Close()
                            Catch
                                ' does not have permission to create the log file
                            End Try

                            PortalSettings.UpdateDatabaseVersion(intMajor, intMinor, intBuild)
                            Dim objEventLog As New Logging.EventLogController
                            Dim objEventLogInfo As New Logging.EventLogInfo
                            objEventLogInfo.AddProperty("Upgraded DotNetNuke", "Version: " + intMajor.ToString + "." + intMinor.ToString + "." + intBuild.ToString)
                            If strExceptions.Length > 0 Then
                                objEventLogInfo.AddProperty("Warnings", strExceptions)
                            Else
                                objEventLogInfo.AddProperty("No Warnings", "")
                            End If
                            objEventLogInfo.LogTypeKey = Logging.EventLogInfo.EventLogType.HOST_ALERT.ToString
                            objEventLogInfo.BypassBuffering = True
                            objEventLog.AddLog(objEventLogInfo)
                        End If
                    Next
                Else
                    ' upgrade error
                    Dim objStreamReader As StreamReader
                    objStreamReader = File.OpenText(HttpContext.Current.Server.MapPath("~/500.htm"))
                    Dim strHTML As String = objStreamReader.ReadToEnd
                    objStreamReader.Close()
                    strHTML = Replace(strHTML, "[MESSAGE]", strProviderPath)
                    If Not HttpContext.Current Is Nothing Then
                        HttpContext.Current.Response.Write(strHTML)
                        HttpContext.Current.Response.End()
                    End If
                End If
            Else
                ' folder permissions not correct
                Dim objStreamReader As StreamReader
                objStreamReader = File.OpenText(HttpContext.Current.Server.MapPath("~/403-3.htm"))
                Dim strHTML As String = objStreamReader.ReadToEnd
                objStreamReader.Close()
                strHTML = Replace(strHTML, "[MESSAGE]", strUpgrade)
                HttpContext.Current.Response.Write(strHTML)
                HttpContext.Current.Response.End()
            End If

        End Sub

        Private Shared Function UpgradeApplication(ByVal Version As String) As String

            Dim strExceptions As String = ""

            Select Case Version
                Case "02.00.00"
                    Dim dr As IDataReader
                    Try
                        ' change portal upload directory from GUID to ID - this only executes for version 2.0.0
                        Dim strServerPath As String = HttpContext.Current.Request.MapPath(Global.ApplicationPath)
                        dr = DataProvider.Instance().GetPortals()
                        While dr.Read
                            ' if GUID folder exists
                            If Directory.Exists(strServerPath & "\Portals\" & dr("GUID").ToString) = True Then
                                ' if ID folder exists ( this may happen because the 2.x release contains a default ID=0 folder )
                                If Directory.Exists(strServerPath & "\Portals\" & dr("PortalID").ToString) = True Then
                                    ' rename the ID folder
                                    Try
                                        Directory.Move(strServerPath & "\Portals\" & dr("PortalID").ToString, strServerPath & "\Portals\" & dr("PortalID").ToString & "_old")
                                    Catch ex As Exception
                                        ' error moving the directory - security issue?
                                        strExceptions += "Could Not Move Folder " & strServerPath & "\Portals\" & dr("GUID").ToString & " To " & strServerPath & "\Portals\" & dr("PortalID").ToString & ". Error: " & ex.Message & vbCrLf
                                    End Try
                                End If

                                ' move GUID folder to ID folder
                                Try
                                    Directory.Move(strServerPath & "\Portals\" & dr("GUID").ToString, strServerPath & "\Portals\" & dr("PortalID").ToString)
                                Catch ex As Exception
                                    ' error moving the directory - security issue?
                                    strExceptions += "Could Not Move Folder " & strServerPath & "\Portals\" & dr("GUID").ToString & " To " & strServerPath & "\Portals\" & dr("PortalID").ToString & ". Error: " & ex.Message & vbCrLf
                                End Try
                            End If
                        End While
                    Catch ex As Exception
                        Try
                            LogException(ex)
                        Catch
                        End Try
                    Finally
                        dr.Close()
                    End Try
                Case "02.01.01"
                    Try
                        Dim ModuleDefID As Integer

                        ' add the system message module to the admin tab
                        ModuleDefID = AddCoreModule("System Messages", "Allows you to define system message templates at the Host and Portal levels.", "System Messages", "", "", "Admin/Portal/SystemMessages.ascx", "", SecurityAccessLevel.Admin, 0)
                        AddAdminTab("Admin", "Site Settings", "", ModuleDefID, "")

                        ' add the system messages to the database
                        Dim xmlDoc As New XmlDocument
                        Dim xmlNode As xmlNode
                        xmlDoc.Load(HttpContext.Current.Server.MapPath(Global.HostPath & "systemmessages.xml"))
                        Dim objSystemMessages As New SystemMessageController
                        For Each xmlNode In xmlDoc.SelectNodes("//messages/message")
                            objSystemMessages.SetSystemMessage(Null.NullInteger, xmlNode.Item("name").InnerText, xmlNode.Item("value").InnerText)
                        Next

                        ' add the log viewer module to the admin tab
                        ModuleDefID = AddCoreModule("Log Viewer", "Allows you to view log entries for portal events.", "Log Viewer", "", "", "Admin/Logging/LogViewer.ascx", "", SecurityAccessLevel.Admin, 0)
                        AddAdminTab("Admin", "Log Viewer", "icon_viewstats_16px.gif", ModuleDefID, "icon_viewstats_36px.gif")
                        ModuleDefID = AddCoreModule("Log Viewer", "Allows you to edit the logging configuration.", "Log Viewer", "Edit", "Edit Log Settings", "Admin/Logging/EditLogTypes.ascx", "", SecurityAccessLevel.Host, 0)

                        ' add the schedule module to the host tab
                        ModuleDefID = AddCoreModule("Schedule", "Allows you to schedule tasks to be run at specified intervals.", "Schedule", "", "", "Admin/Scheduling/ViewSchedule.ascx", "", SecurityAccessLevel.Admin, 0)
                        AddAdminTab("Host", "Schedule", "icon_scheduler_16px.gif", ModuleDefID, "icon_scheduler_39px.gif")
                        ModuleDefID = AddCoreModule("Schedule", "Allows you to edit schedule tasks.", "Schedule", "Edit", "Edit Schedule", "Admin/Scheduling/EditSchedule.ascx", "", SecurityAccessLevel.Host, 0)
                        ModuleDefID = AddCoreModule("Schedule", "Allows you to edit schedule tasks.", "Schedule", "History", "Schedule History", "Admin/Scheduling/ViewScheduleHistory.ascx", "", SecurityAccessLevel.Host, 0)
                        ModuleDefID = AddCoreModule("Schedule", "Allows you to edit schedule tasks.", "Schedule", "Status", "Schedule Status", "Admin/Scheduling/ViewScheduleStatus.ascx", "", SecurityAccessLevel.Host, 0)

                        ' migrate Url data
                        Dim objPortals As New PortalController
                        Dim objPortal As PortalInfo
                        Dim objTabs As New TabController
                        Dim objTab As TabInfo
                        Dim objModules As New ModuleController
                        Dim objModule As ModuleInfo
                        Dim objUrls As New UrlController
                        Dim dr1 As IDataReader
                        Dim dr2 As IDataReader
                        Dim strUrl As String
                        Dim strUrlType As String

                        Dim arrPortals As ArrayList = objPortals.GetPortals
                        Dim intPortal As Integer
                        For intPortal = 0 To arrPortals.Count - 1
                            objPortal = CType(arrPortals(intPortal), PortalInfo)
                            Dim arrTabs As ArrayList = objTabs.GetTabs(objPortal.PortalID)
                            Dim intTab As Integer
                            For intTab = 0 To arrTabs.Count - 1
                                objTab = CType(arrTabs(intTab), TabInfo)
                                Dim arrModules As ArrayList = objModules.GetPortalTabModules(objTab.PortalID, objTab.TabID)
                                Dim intModule As Integer
                                For intModule = 0 To arrModules.Count - 1
                                    objModule = CType(arrModules(intModule), ModuleInfo)
                                    Select Case objModule.ModuleDefID
                                        Case 1 ' announcements
                                            dr1 = DataProvider.Instance().GetAnnouncements(objModule.ModuleID)
                                            While dr1.Read
                                                dr2 = DataProvider.Instance().GetAnnouncement(Convert.ToInt32(dr1("ItemId")), objModule.ModuleID)
                                                If dr2.Read Then
                                                    strUrl = dr2("Url").ToString
                                                    If strUrl.IndexOf("://") <> -1 Then
                                                        strUrlType = "U"
                                                    Else
                                                        If IsNumeric(strUrl) Then
                                                            strUrlType = "T"
                                                        Else
                                                            strUrlType = "F"
                                                        End If
                                                    End If
                                                    objUrls.UpdateUrl(objPortal.PortalID, strUrl, strUrlType, Convert.ToInt32(dr2("Clicks")), Null.NullDate, Convert.ToDateTime(dr2("CreatedDate")), True)
                                                End If
                                                dr2.Close()
                                            End While
                                            dr1.Close()
                                        Case 7 ' links
                                            dr1 = DataProvider.Instance().GetLinks(objModule.ModuleID)
                                            While dr1.Read
                                                dr2 = DataProvider.Instance().GetLink(Convert.ToInt32(dr1("ItemId")), objModule.ModuleID)
                                                If dr2.Read Then
                                                    strUrl = dr2("Url").ToString
                                                    If strUrl.IndexOf("://") <> -1 Then
                                                        strUrlType = "U"
                                                    Else
                                                        If IsNumeric(strUrl) Then
                                                            strUrlType = "T"
                                                        Else
                                                            strUrlType = "F"
                                                        End If
                                                    End If
                                                    objUrls.UpdateUrl(objPortal.PortalID, strUrl, strUrlType, Convert.ToInt32(dr2("Clicks")), Null.NullDate, Convert.ToDateTime(dr2("CreatedDate")), True)
                                                End If
                                                dr2.Close()
                                            End While
                                            dr1.Close()
                                        Case 10 ' documents
                                            dr1 = DataProvider.Instance().GetDocuments(objModule.ModuleID, objPortal.PortalID)
                                            While dr1.Read
                                                dr2 = DataProvider.Instance().GetDocument(Convert.ToInt32(dr1("ItemId")), objModule.ModuleID)
                                                If dr2.Read Then
                                                    strUrl = dr2("Url").ToString
                                                    If strUrl.IndexOf("://") <> -1 Then
                                                        strUrlType = "U"
                                                    Else
                                                        If IsNumeric(strUrl) Then
                                                            strUrlType = "T"
                                                        Else
                                                            strUrlType = "F"
                                                        End If
                                                    End If
                                                    objUrls.UpdateUrl(objPortal.PortalID, strUrl, strUrlType, Convert.ToInt32(dr2("Clicks")), Null.NullDate, Convert.ToDateTime(dr2("CreatedDate")), True)
                                                End If
                                                dr2.Close()
                                            End While
                                            dr1.Close()
                                    End Select
                                Next intModule
                            Next intTab
                        Next intPortal

                    Catch ex As Exception
                        strExceptions += "Error: " & ex.Message & vbCrLf
                        Try
                            LogException(ex)
                        Catch
                        End Try
                    End Try
            End Select

            Return strExceptions

        End Function


        Private Shared Function VerifyFolderPermissions() As String
            Try
                Dim strFolder As String = HttpContext.Current.Server.MapPath(Global.ApplicationPath)

                If Directory.Exists(strFolder & "\verify") Then
                    Directory.Delete(strFolder & "\verify", True)
                End If

                ' test folder write permission
                Directory.CreateDirectory(strFolder & "\verify")

                ' test folder delete permission
                Directory.Delete(strFolder & "\verify", True)

                If File.Exists(strFolder & "\verify.txt") Then
                    File.Delete(strFolder & "\verify.txt")
                End If

                ' test file write permission
                Dim objStream As StreamWriter
                objStream = File.CreateText(strFolder & "\verify.txt")
                objStream.WriteLine("")
                objStream.Close()

                ' test file delete permission
                File.Delete(strFolder & "\verify.txt")

                Return ""
            Catch ex As Exception ' security error
                Return ex.Message
            End Try

        End Function

        Private Shared Function AddCoreModule(ByVal DesktopModuleName As String, ByVal Description As String, ByVal ModuleDefinitionName As String, ByVal ControlKey As String, ByVal ControlTitle As String, ByVal ControlSrc As String, ByVal IconFile As String, ByVal ControlType As SecurityAccessLevel, ByVal ViewOrder As Integer) As Integer

            Dim objDesktopModules As New DesktopModuleController

            ' check if desktop module exists
            Dim objDesktopModule As DesktopModuleInfo = objDesktopModules.GetDesktopModuleByName(DesktopModuleName)
            If objDesktopModule Is Nothing Then
                objDesktopModule = New DesktopModuleInfo
                objDesktopModule.DesktopModuleID = Convert.ToInt32(Null.SetNull(objDesktopModule.DesktopModuleID))
            End If

            objDesktopModule.FriendlyName = DesktopModuleName
            objDesktopModule.Description = Description
            objDesktopModule.Version = Null.NullString
            objDesktopModule.IsPremium = False
            objDesktopModule.IsAdmin = True

            If Null.IsNull(objDesktopModule.DesktopModuleID) Then
                ' new desktop module
                objDesktopModule.DesktopModuleID = objDesktopModules.AddDesktopModule(objDesktopModule)
            Else
                ' existing desktop module
                objDesktopModules.UpdateDesktopModule(objDesktopModule)
            End If

            Dim objModuleDefinitions As New ModuleDefinitionController

            ' check if module definition exists
            Dim objModuleDefinition As ModuleDefinitionInfo = objModuleDefinitions.GetModuleDefinitionByName(objDesktopModule.DesktopModuleID, ModuleDefinitionName)
            If objModuleDefinition Is Nothing Then
                objModuleDefinition = New ModuleDefinitionInfo

                objModuleDefinition.ModuleDefID = Convert.ToInt32(Null.SetNull(objModuleDefinition.ModuleDefID))
                objModuleDefinition.DesktopModuleID = objDesktopModule.DesktopModuleID
                objModuleDefinition.FriendlyName = ModuleDefinitionName

                objModuleDefinition.ModuleDefID = objModuleDefinitions.AddModuleDefinition(objModuleDefinition)
            End If

            Dim objModuleControls As New ModuleControlController

            ' check if module control exists
            Dim objModuleControl As ModuleControlInfo = objModuleControls.GetModuleControlByKeyAndSrc(objModuleDefinition.ModuleDefID, ControlKey, ControlSrc)
            If objModuleControl Is Nothing Then
                objModuleControl = New ModuleControlInfo
                objModuleControl.ModuleControlID = Convert.ToInt32(Null.SetNull(objModuleControl.ModuleControlID))
            End If

            objModuleControl.ModuleDefID = objModuleDefinition.ModuleDefID
            objModuleControl.ControlKey = ControlKey
            objModuleControl.ControlTitle = ControlTitle
            objModuleControl.ControlSrc = ControlSrc
            objModuleControl.ControlType = ControlType
            objModuleControl.ViewOrder = ViewOrder
            objModuleControl.IconFile = IconFile

            If Null.IsNull(objModuleControl.ModuleControlID) Then
                ' new module control
                objModuleControls.AddModuleControl(objModuleControl)
            Else
                ' existing modul control
                objModuleControls.UpdateModuleControl(objModuleControl)
            End If

            Return objModuleDefinition.ModuleDefID

        End Function

        Private Shared Sub AddAdminTab(ByVal ParentTabName As String, ByVal AdminTabName As String, ByVal TabIconFile As String, ByVal ModuleDefID As Integer, ByVal ModuleIconFile As String)

            Dim objModuleDefinitions As New ModuleDefinitionController
            Dim objModuleDefinition As ModuleDefinitionInfo = objModuleDefinitions.GetModuleDefinition(ModuleDefID)

            If Not objModuleDefinition Is Nothing Then
                Dim objTabs As New TabController
                Dim objTab As TabInfo
                Dim objModules As New ModuleController
                Dim objModule As New ModuleInfo

                Dim ParentId As Integer

                Select Case ParentTabName
                    Case "Host"
                        ParentId = -1

                        objTab = objTabs.GetTabByName(ParentTabName)
                        If Not objTab Is Nothing Then
                            ParentId = objTab.TabID
                        End If

                        objTab = objTabs.GetTabByName(AdminTabName)
                        If objTab Is Nothing Then
                            objTab = New TabInfo

                            objTab.TabID = Null.NullInteger
                            objTab.PortalID = Null.NullInteger
                            objTab.TabName = AdminTabName
                            objTab.Title = ""
                            objTab.Description = ""
                            objTab.KeyWords = ""
                            objTab.AuthorizedRoles = glbRoleSuperUser.ToString & ";"
                            objTab.IsVisible = True
                            objTab.DisableLink = False
                            objTab.ParentId = ParentId
                            objTab.IconFile = TabIconFile
                            objTab.AdministratorRoles = Null.NullString
                            objTab.IsDeleted = False

                            objTab.TabID = objTabs.AddTab(objTab)
                        End If

                        Try
                            objModule = New ModuleInfo

                            objModule.ModuleID = Null.NullInteger
                            objModule.TabID = objTab.TabID
                            objModule.ModuleOrder = -1
                            objModule.ModuleTitle = objModuleDefinition.FriendlyName
                            objModule.PaneName = glbDefaultPane
                            objModule.ModuleDefID = ModuleDefID
                            objModule.CacheTime = 0
                            objModule.AuthorizedEditRoles = glbRoleSuperUser.ToString & ";"
                            objModule.AuthorizedViewRoles = ""
                            objModule.Alignment = ""
                            objModule.IconFile = ModuleIconFile
                            objModule.AllTabs = False
                            objModule.ShowTitle = True
                            objModule.Personalize = 0

                            objModules.AddModule(objModule)
                        Catch
                            ' module already exists
                        End Try
                    Case "Admin"
                        Dim objPortals As New PortalController
                        Dim objPortal As PortalInfo

                        Dim arrPortals As ArrayList = objPortals.GetPortals
                        Dim intPortal As Integer

                        For intPortal = 0 To arrPortals.Count - 1
                            objPortal = CType(arrPortals(intPortal), PortalInfo)

                            ParentId = -1

                            objTab = objTabs.GetTabByName(ParentTabName, objPortal.PortalID)
                            If Not objTab Is Nothing Then
                                ParentId = objTab.TabID
                            End If

                            objTab = objTabs.GetTabByName(AdminTabName, objPortal.PortalID)
                            If objTab Is Nothing Then
                                objTab = New TabInfo

                                objTab.TabID = Null.NullInteger
                                objTab.PortalID = objPortal.PortalID
                                objTab.TabName = AdminTabName
                                objTab.Title = ""
                                objTab.Description = ""
                                objTab.KeyWords = ""
                                objTab.AuthorizedRoles = objPortal.AdministratorRoleId.ToString & ";"
                                objTab.IsVisible = True
                                objTab.DisableLink = False
                                objTab.ParentId = ParentId
                                objTab.IconFile = TabIconFile
                                objTab.AdministratorRoles = Null.NullString
                                objTab.IsDeleted = False

                                objTab.TabID = objTabs.AddTab(objTab)
                            End If

                            Try
                                objModule = New ModuleInfo

                                objModule.ModuleID = Null.NullInteger
                                objModule.TabID = objTab.TabID
                                objModule.ModuleOrder = -1
                                objModule.ModuleTitle = objModuleDefinition.FriendlyName
                                objModule.PaneName = glbDefaultPane
                                objModule.ModuleDefID = ModuleDefID
                                objModule.CacheTime = 0
                                objModule.AuthorizedEditRoles = objPortal.AdministratorRoleId.ToString & ";"
                                objModule.AuthorizedViewRoles = ""
                                objModule.Alignment = ""
                                objModule.IconFile = ModuleIconFile
                                objModule.AllTabs = False
                                objModule.ShowTitle = True
                                objModule.Personalize = 0

                                objModules.AddModule(objModule)
                            Catch
                                ' module already exists
                            End Try

                        Next intPortal
                End Select
            End If

        End Sub

    End Class

End Namespace