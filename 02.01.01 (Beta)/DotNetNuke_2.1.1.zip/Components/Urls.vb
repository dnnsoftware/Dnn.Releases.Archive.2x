'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data

Namespace DotNetNuke

    Public Class UrlInfo

        ' local property declarations
        Private _UrlID As Integer
        Private _PortalID As Integer
        Private _Url As String

        ' initialization
        Public Sub New()
        End Sub

        ' public properties
        Public Property UrlID() As Integer
            Get
                Return _UrlID
            End Get
            Set(ByVal Value As Integer)
                _UrlID = Value
            End Set
        End Property

        Public Property PortalID() As Integer
            Get
                Return _PortalID
            End Get
            Set(ByVal Value As Integer)
                _PortalID = Value
            End Set
        End Property

        Public Property Url() As String
            Get
                Return _Url
            End Get
            Set(ByVal Value As String)
                _Url = Value
            End Set
        End Property

    End Class

    Public Class UrlTrackingInfo

        ' local property declarations
        Private _UrlTrackingID As Integer
        Private _PortalID As Integer
        Private _Url As String
        Private _UrlType As String
        Private _Clicks As Integer
        Private _LastClick As Date
        Private _CreatedDate As Date
        Private _LogActivity As Boolean

        ' initialization
        Public Sub New()
        End Sub

        ' public properties
        Public Property UrlTrackingID() As Integer
            Get
                Return _UrlTrackingID
            End Get
            Set(ByVal Value As Integer)
                _UrlTrackingID = Value
            End Set
        End Property

        Public Property PortalID() As Integer
            Get
                Return _PortalID
            End Get
            Set(ByVal Value As Integer)
                _PortalID = Value
            End Set
        End Property

        Public Property Url() As String
            Get
                Return _Url
            End Get
            Set(ByVal Value As String)
                _Url = Value
            End Set
        End Property

        Public Property UrlType() As String
            Get
                Return _UrlType
            End Get
            Set(ByVal Value As String)
                _UrlType = Value
            End Set
        End Property

        Public Property Clicks() As Integer
            Get
                Return _Clicks
            End Get
            Set(ByVal Value As Integer)
                _Clicks = Value
            End Set
        End Property

        Public Property LastClick() As Date
            Get
                Return _LastClick
            End Get
            Set(ByVal Value As Date)
                _LastClick = Value
            End Set
        End Property

        Public Property CreatedDate() As Date
            Get
                Return _CreatedDate
            End Get
            Set(ByVal Value As Date)
                _CreatedDate = Value
            End Set
        End Property

        Public Property LogActivity() As Boolean
            Get
                Return _LogActivity
            End Get
            Set(ByVal Value As Boolean)
                _LogActivity = Value
            End Set
        End Property

    End Class

    Public Class UrlLogInfo

        ' local property declarations
        Private _UrlLogID As Integer
        Private _UrlTrackingID As Integer
        Private _ClickDate As Date
        Private _UserID As Integer
        Private _ModuleID As Integer
        Private _FullName As String
        Private _ModuleTitle As String

        ' initialization
        Public Sub New()
        End Sub

        ' public properties
        Public Property UrlLogID() As Integer
            Get
                Return _UrlLogID
            End Get
            Set(ByVal Value As Integer)
                _UrlLogID = Value
            End Set
        End Property

        Public Property UrlTrackingID() As Integer
            Get
                Return _UrlTrackingID
            End Get
            Set(ByVal Value As Integer)
                _UrlTrackingID = Value
            End Set
        End Property

        Public Property ClickDate() As Date
            Get
                Return _ClickDate
            End Get
            Set(ByVal Value As Date)
                _ClickDate = Value
            End Set
        End Property

        Public Property UserID() As Integer
            Get
                Return _UserID
            End Get
            Set(ByVal Value As Integer)
                _UserID = Value
            End Set
        End Property

        Public Property ModuleID() As Integer
            Get
                Return _ModuleID
            End Get
            Set(ByVal Value As Integer)
                _ModuleID = Value
            End Set
        End Property

        Public Property FullName() As String
            Get
                Return _FullName
            End Get
            Set(ByVal Value As String)
                _FullName = Value
            End Set
        End Property

        Public Property ModuleTitle() As String
            Get
                Return _ModuleTitle
            End Get
            Set(ByVal Value As String)
                _ModuleTitle = Value
            End Set
        End Property

    End Class

    Public Class UrlController

        Public Function GetUrls(ByVal PortalID As Integer) As ArrayList

            Return CBO.FillCollection(DataProvider.Instance().GetUrls(PortalID), GetType(UrlInfo))

        End Function

        Public Function GetUrl(ByVal PortalID As Integer, ByVal Url As String) As UrlInfo

            Return CType(CBO.FillObject(DataProvider.Instance().GetUrl(PortalID, Url), GetType(UrlInfo)), UrlInfo)

        End Function

        Public Function GetUrlTracking(ByVal PortalID As Integer, ByVal Url As String) As UrlTrackingInfo

            Return CType(CBO.FillObject(DataProvider.Instance().GetUrlTracking(PortalID, Url), GetType(UrlTrackingInfo)), UrlTrackingInfo)

        End Function

        Public Sub UpdateUrl(ByVal PortalID As Integer, ByVal Url As String, ByVal UrlType As String, ByVal LogActivity As Boolean)
            UpdateUrl(PortalID, Url, UrlType, 0, Null.NullDate, Now(), LogActivity)
        End Sub

        Public Sub UpdateUrl(ByVal PortalID As Integer, ByVal Url As String, ByVal UrlType As String, ByVal Clicks As Integer, ByVal LastClick As Date, ByVal CreatedDate As Date, ByVal LogActivity As Boolean)

            If Url <> "" Then
                If UrlType = "U" Then
                    If GetUrl(PortalID, Url) Is Nothing Then
                        DataProvider.Instance().AddUrl(PortalID, Url)
                    End If
                End If

                Dim objURLTracking As UrlTrackingInfo = GetUrlTracking(PortalID, Url)
                If objURLTracking Is Nothing Then
                    DataProvider.Instance().AddUrlTracking(PortalID, Url, UrlType, Clicks, LastClick, CreatedDate, LogActivity)
                Else
                    DataProvider.Instance().UpdateUrlTracking(PortalID, Url, objURLTracking.UrlType, objURLTracking.Clicks, objURLTracking.LastClick, objURLTracking.CreatedDate, LogActivity)
                End If
            End If

        End Sub

        Public Sub DeleteUrl(ByVal PortalID As Integer, ByVal Url As String)

            DataProvider.Instance().DeleteUrl(PortalID, Url)

        End Sub

        Public Sub UpdateUrlTracking(ByVal PortalID As Integer, ByVal Url As String, ByVal ModuleID As Integer, ByVal UserID As Integer)

            Dim objUrlTracking As UrlTrackingInfo = GetUrlTracking(PortalID, Url)
            If Not objUrlTracking Is Nothing Then
                DataProvider.Instance().UpdateUrlTracking(PortalID, Url, objUrlTracking.UrlType, objUrlTracking.Clicks + 1, Now, objUrlTracking.CreatedDate, objUrlTracking.LogActivity)
                If objUrlTracking.LogActivity Then
                    DataProvider.Instance().AddUrlLog(objUrlTracking.UrlTrackingID, ModuleID, UserID)
                End If
            End If

        End Sub

        Public Function GetUrlLog(ByVal PortalID As Integer, ByVal Url As String, ByVal ModuleID As Integer, ByVal StartDate As Date, ByVal EndDate As Date) As ArrayList

            Dim arrUrlLog As ArrayList

            Dim objUrlTracking As UrlTrackingInfo = GetUrlTracking(PortalID, Url)
            If Not objUrlTracking Is Nothing Then
                arrUrlLog = CBO.FillCollection(DataProvider.Instance().GetUrlLog(objUrlTracking.UrlTrackingID, ModuleID, StartDate, EndDate), GetType(UrlLogInfo))
            End If

            Return arrUrlLog

        End Function

    End Class

End Namespace