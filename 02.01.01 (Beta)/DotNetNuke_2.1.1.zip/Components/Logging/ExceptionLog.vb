'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO Exception SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'


Namespace DotNetNuke.Logging


    Public Class ExceptionLogController
        Inherits LogController

        Public Enum ExceptionLogType
            GENERAL_EXCEPTION
            MODULE_LOAD_EXCEPTION
            PAGE_LOAD_EXCEPTION
            SCHEDULER_EXCEPTION
        End Enum

        Public Overloads Sub AddLog(ByVal objException As Exception)
            Dim objLogController As New LogController
            objLogController.AddLog(objException, ExceptionLogType.GENERAL_EXCEPTION.ToString, -1, "", -1, "", False)
        End Sub

        Public Overloads Sub AddLog(ByVal objException As Exception, ByVal LogType As ExceptionLogType)
            Dim objLogController As New LogController
            objLogController.AddLog(objException, LogType.ToString, -1, "", -1, "", False)
        End Sub

        Public Overloads Sub AddLog(ByVal objBasePortalException As BasePortalException)
            Dim objExceptionLogType As ExceptionLogType
            If objBasePortalException.GetType.Name = "ModuleLoadException" Then
                objExceptionLogType = ExceptionLogType.MODULE_LOAD_EXCEPTION
            ElseIf objBasePortalException.GetType.Name = "PageLoadException" Then
                objExceptionLogType = ExceptionLogType.PAGE_LOAD_EXCEPTION
            Else
                objExceptionLogType = ExceptionLogType.GENERAL_EXCEPTION
            End If
            Dim objLogController As New LogController
            objLogController.AddLog(objBasePortalException, objExceptionLogType.ToString, objBasePortalException.PortalID, objBasePortalException.PortalName, objBasePortalException.UserID, objBasePortalException.UserName, False)
        End Sub



    End Class

    Public Class ExceptionLogInfo
        Inherits LogInfo

    End Class

    





End Namespace





