'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO  SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'



Namespace DotNetNuke.Logging

    Public Class LogInfoArray
        Implements IEnumerable

        Private arrLogs As New ArrayList

        Public ReadOnly Property Count() As Integer
            Get
                Return arrLogs.Count
            End Get
        End Property

        Public Function GetItem(ByVal Index As Integer) As LogInfo
            Return CType(arrLogs(Index), LogInfo)
        End Function


        Public Function GetEnumerator() As System.Collections.IEnumerator Implements System.Collections.IEnumerable.GetEnumerator
            Return arrLogs.GetEnumerator
        End Function

        Public Sub Add(ByVal objLogInfo As LogInfo)
            arrLogs.Add(objLogInfo)
        End Sub

        Public Sub Remove(ByVal objLogInfo As LogInfo)
            arrLogs.Remove(objLogInfo)
        End Sub

        Public Function GetEnumerator(ByVal index As Integer, ByVal count As Integer) As System.Collections.IEnumerator
            Return arrLogs.GetEnumerator(index, count)
        End Function

    End Class

    Public Class LogProperties
        Inherits ArrayList
        Public ReadOnly Property Summary() As String
            Get
                Return Left(Me.ToString, 75)
            End Get
        End Property
        Public Overrides Function ToString() As String
            Dim t As New System.Text.StringBuilder
            Dim i As Integer
            For i = 0 To Me.Count - 1
                Dim ldi As LogDetailInfo = CType(Me(i), LogDetailInfo)
                t.Append(ldi.ToString())
            Next
            Return t.ToString
        End Function
    End Class

    Public Class LogDetailInfo
        Private _PropertyName As String
        Private _PropertyValue As String
        Public Property PropertyName() As String
            Get
                Return _PropertyName
            End Get
            Set(ByVal Value As String)
                _PropertyName = Value
            End Set
        End Property
        Public Property PropertyValue() As String
            Get
                Return _PropertyValue
            End Get
            Set(ByVal Value As String)
                _PropertyValue = Value
            End Set
        End Property

        Public Overrides Function ToString() As String
            Return "<b>" + PropertyName + "</b>: " + PropertyValue + ";&nbsp;"
        End Function
    End Class

    Public Class LogInfo
        Private _LogGUID As String
        Private _LogFileID As String
        Private _LogTypeKey As String
        Private _LogUserID As Integer
        Private _LogUserName As String
        Private _LogPortalID As Integer
        Private _LogPortalName As String
        Private _LogCreateDate As Date
        Private _LogCreateDateNum As Long
        Private _BypassBuffering As Boolean
        Private _LogProperties As LogProperties

        Public Sub New()
            _LogGUID = Guid.NewGuid.ToString
            _BypassBuffering = False
            LogProperties = New LogProperties
            _LogPortalID = -1
            _LogPortalName = ""
            _LogUserID = -1
            _LogUserName = ""
        End Sub

        Public Property LogGUID() As String
            Get
                Return _LogGUID
            End Get
            Set(ByVal Value As String)
                _LogGUID = Value
            End Set
        End Property
        Public Property LogFileID() As String
            Get
                Return _LogFileID
            End Get
            Set(ByVal Value As String)
                _LogFileID = Value
            End Set
        End Property
        Public Property LogTypeKey() As String
            Get
                Return _LogTypeKey
            End Get
            Set(ByVal Value As String)
                _LogTypeKey = Value
            End Set
        End Property
        Public Property LogUserID() As Integer
            Get
                Return _LogUserID
            End Get
            Set(ByVal Value As Integer)
                _LogUserID = Value
            End Set
        End Property
        Public Property LogUserName() As String
            Get
                Return _LogUserName
            End Get
            Set(ByVal Value As String)
                _LogUserName = Value
            End Set
        End Property
        Public Property LogPortalID() As Integer
            Get
                Return _LogPortalID
            End Get
            Set(ByVal Value As Integer)
                _LogPortalID = Value
            End Set
        End Property
        Public Property LogPortalName() As String
            Get
                Return _LogPortalName
            End Get
            Set(ByVal Value As String)
                _LogPortalName = Value
            End Set
        End Property
        Public Property LogCreateDate() As Date
            Get
                Return _LogCreateDate
            End Get
            Set(ByVal Value As Date)
                _LogCreateDate = Value
            End Set
        End Property
        Public Property LogCreateDateNum() As Long
            Get
                Return _LogCreateDateNum
            End Get
            Set(ByVal Value As Long)
                _LogCreateDateNum = Value
            End Set
        End Property
        Public Property LogProperties() As LogProperties
            Get
                Return _LogProperties
            End Get
            Set(ByVal Value As LogProperties)
                _LogProperties = Value
            End Set
        End Property
        Public Property BypassBuffering() As Boolean
            Get
                Return _BypassBuffering
            End Get
            Set(ByVal Value As Boolean)
                _BypassBuffering = Value
            End Set
        End Property

        Public Sub AddProperty(ByVal PropertyName As String, ByVal PropertyValue As String)
            Try
                If PropertyName.Length > 50 Then
                    PropertyName = Left(PropertyName, 50)
                End If
                If PropertyValue.Length > 500 Then
                    PropertyValue = "(TRUNCATED TO 500 CHARS): " + Left(PropertyValue, 500)
                End If
                Dim objLogDetailInfo As New LogDetailInfo
                objLogDetailInfo.PropertyName = PropertyName
                objLogDetailInfo.PropertyValue = PropertyValue
                _LogProperties.Add(objLogDetailInfo)
            Catch exc As Exception
                ProcessPageLoadException(exc)
            End Try
        End Sub

        Public Shared Function IsSystemType(ByVal PropName As String) As Boolean
            Select Case PropName
                Case "LogGUID", "LogFileID", "LogTypeKey", "LogCreateDate", "LogCreateDateNum", "LogPortalID", "LogPortalName", "LogUserID", "LogUserName", "BypassBuffering"
                    Return True
            End Select

            Return False
        End Function

        Public Overrides Function ToString() As String
            Dim str As New System.Text.StringBuilder
            str.Append("<b>LogGUID:</b> " + LogGUID + "<br>")
            str.Append("<b>LogType:</b> " + LogTypeKey + "<br>")
            str.Append("<b>UserID:</b> " + LogUserID.ToString + "<br>")
            str.Append("<b>Username:</b> " + LogUserName + "<br>")
            str.Append("<b>PortalID:</b> " + LogPortalID.ToString + "<br>")
            str.Append("<b>PortalName:</b> " + LogPortalName + "<br>")
            str.Append("<b>CreateDate:</b> " + LogCreateDate.ToString + "<br>")
            str.Append(LogProperties.ToString)
            Return str.ToString
        End Function
    End Class


    Public Class LogTypeInfo
        Private _LogTypeKey As String
        Private _LogTypeFriendlyName As String
        Private _LogTypeDescription As String
        Private _LogTypeOwner As String
        Private _LogTypeCSSClass As String

        Public Property LogTypeKey() As String
            Get
                Return _LogTypeKey
            End Get
            Set(ByVal Value As String)
                _LogTypeKey = Value
            End Set
        End Property
        Public Property LogTypeFriendlyName() As String
            Get
                Return _LogTypeFriendlyName
            End Get
            Set(ByVal Value As String)
                _LogTypeFriendlyName = Value
            End Set
        End Property
        Public Property LogTypeDescription() As String
            Get
                Return _LogTypeDescription
            End Get
            Set(ByVal Value As String)
                _LogTypeDescription = Value
            End Set
        End Property
        Public Property LogTypeOwner() As String
            Get
                Return _LogTypeOwner
            End Get
            Set(ByVal Value As String)
                _LogTypeOwner = Value
            End Set
        End Property
        Public Property LogTypeCSSClass() As String
            Get
                Return _LogTypeCSSClass
            End Get
            Set(ByVal Value As String)
                _LogTypeCSSClass = Value
            End Set
        End Property
    End Class

    Public Class LogTypeConfigInfo
        Inherits LogTypeInfo

        Private _ID As String
        Private _LoggingIsActive As Boolean
        Private _LogFileName As String
        Private _LogFileNameWithPath As String
        Private _LogTypePortalID As String
        Private _KeepMostRecent As String
        Public Enum NotificationThresholdTimeTypes
            None = 0
            Seconds = 1
            Minutes = 2
            Hours = 3
            Days = 4
        End Enum

        Private _EmailNotificationIsActive As Boolean
        Private _MailFromAddress As String
        Private _MailToAddress As String
        Private _NotificationThreshold As Integer
        Private _NotificationThresholdTime As Integer
        Private _NotificationThresholdTimeType As NotificationThresholdTimeTypes

        Public ReadOnly Property StartDateTime() As Date
            Get
                Select Case Me.NotificationThresholdTimeType
                    Case Me.NotificationThresholdTimeTypes.Seconds
                        Return Date.Now.AddSeconds(NotificationThresholdTime * -1)
                    Case Me.NotificationThresholdTimeTypes.Minutes
                        Return Date.Now.AddMinutes(NotificationThresholdTime * -1)
                    Case Me.NotificationThresholdTimeTypes.Hours
                        Return Date.Now.AddHours(NotificationThresholdTime * -1)
                    Case Me.NotificationThresholdTimeTypes.Days
                        Return Date.Now.AddDays(NotificationThresholdTime * -1)
                    Case Me.NotificationThresholdTimeTypes.None
                        Return Null.NullDate
                End Select
            End Get
        End Property

        Public Property EmailNotificationIsActive() As Boolean
            Get
                Return _EmailNotificationIsActive
            End Get
            Set(ByVal Value As Boolean)
                _EmailNotificationIsActive = Value
            End Set
        End Property
        Public Property MailFromAddress() As String
            Get
                Return _MailFromAddress
            End Get
            Set(ByVal Value As String)
                _MailFromAddress = Value
            End Set
        End Property
        Public Property MailToAddress() As String
            Get
                Return _MailToAddress
            End Get
            Set(ByVal Value As String)
                _MailToAddress = Value
            End Set
        End Property

        Public Property NotificationThreshold() As Integer
            Get
                Return _NotificationThreshold
            End Get
            Set(ByVal Value As Integer)
                _NotificationThreshold = Value
            End Set
        End Property

        Public Property NotificationThresholdTime() As Integer
            Get
                Return _NotificationThresholdTime
            End Get
            Set(ByVal Value As Integer)
                _NotificationThresholdTime = Value
            End Set
        End Property

        Public Property NotificationThresholdTimeType() As NotificationThresholdTimeTypes
            Get
                Return _NotificationThresholdTimeType
            End Get
            Set(ByVal Value As NotificationThresholdTimeTypes)
                _NotificationThresholdTimeType = Value
            End Set
        End Property

        Public Property ID() As String
            Get
                Return _ID
            End Get
            Set(ByVal Value As String)
                _ID = Value
            End Set
        End Property
        Public Property LoggingIsActive() As Boolean
            Get
                Return _LoggingIsActive
            End Get
            Set(ByVal Value As Boolean)
                _LoggingIsActive = Value
            End Set
        End Property
        Public Property LogFileName() As String
            Get
                Return _LogFileName
            End Get
            Set(ByVal Value As String)
                _LogFileName = Value
            End Set
        End Property

        Public Property LogFileNameWithPath() As String
            Get
                Return _LogFileNameWithPath
            End Get
            Set(ByVal Value As String)
                _LogFileNameWithPath = Value
            End Set
        End Property
        Public Property LogTypePortalID() As String
            Get
                Return _LogTypePortalID
            End Get
            Set(ByVal Value As String)
                _LogTypePortalID = Value
            End Set
        End Property
        Public Property KeepMostRecent() As String
            Get
                Return _KeepMostRecent
            End Get
            Set(ByVal Value As String)
                _KeepMostRecent = Value
            End Set
        End Property


    End Class

    Public Class LogController

        Public Sub AddLog(ByVal objLogInfo As Object, ByVal LogType As String, ByVal PortalID As Integer, ByVal PortalName As String, ByVal UserID As Integer, ByVal UserName As String, ByVal BypassBuffering As Boolean)
            Dim LogGUID As String = Guid.NewGuid.ToString
            Dim CreateDate As Date = Now

            LoggingProvider.Instance.AddLog(objLogInfo, LogType, LogGUID, CreateDate, PortalID, PortalName, UserID, UserName, BypassBuffering)
        End Sub

        Public Function LoggingIsEnabled(ByVal LogType As String, ByVal PortalID As Integer) As Boolean
            Return LoggingProvider.Instance.LoggingIsEnabled(LogType, PortalID)
        End Function

        Public Sub DeleteLog(ByVal objLogInfo As LogInfo)
            LoggingProvider.Instance.DeleteLog(objLogInfo)
        End Sub

        Public Sub ClearLog()
            LoggingProvider.Instance.ClearLog()
        End Sub

        Public Overridable Function GetLog() As LogInfoArray
            Return LoggingProvider.Instance.GetLog()
        End Function

        Public Overridable Function GetSingleLog(ByVal objLogInfo As LogInfo, ByVal objReturnType As LoggingProvider.ReturnType) As Object
            Return LoggingProvider.Instance.GetSingleLog(objLogInfo, objReturnType)
        End Function

        Public Sub PurgeLogBuffer()
            LoggingProvider.Instance.PurgeLogBuffer()
        End Sub

        Public Overridable Function GetLog(ByVal PortalID As Integer) As LogInfoArray
            Return LoggingProvider.Instance.GetLog(PortalID)
        End Function

        Public Overridable Function GetLog(ByVal PortalID As Integer, ByVal LogType As String) As LogInfoArray
            Return LoggingProvider.Instance.GetLog(PortalID, LogType)
        End Function

        Public Overridable Function GetLog(ByVal LogType As String) As LogInfoArray
            Return LoggingProvider.Instance.GetLog(LogType)
        End Function

        Public Overridable Function GetLogTypeConfigInfo() As ArrayList
            Return CType(LoggingProvider.Instance.GetLogTypeConfigInfo(), ArrayList)
        End Function

        Public Overridable Function GetLogTypeConfigInfoByID(ByVal ID As String) As LogTypeConfigInfo
            Return LoggingProvider.Instance.GetLogTypeConfigInfoByID(ID)
        End Function

        Public Overridable Function GetLogTypeInfo() As ArrayList
            Return CType(LoggingProvider.Instance.GetLogTypeInfo(), ArrayList)
        End Function

        Public Overridable Function SupportsEmailNotification() As Boolean
            LoggingProvider.Instance.SupportsEmailNotification()
        End Function

        Public Overridable Function SupportsInternalViewer() As Boolean
            LoggingProvider.Instance.SupportsInternalViewer()
        End Function

        Public Overridable Sub AddLogTypeConfigInfo(ByVal objLogTypeConfigInfo As LogTypeConfigInfo)
            LoggingProvider.Instance.AddLogTypeConfigInfo(objLogTypeConfigInfo.ID, objLogTypeConfigInfo.LoggingIsActive, objLogTypeConfigInfo.LogTypeKey, objLogTypeConfigInfo.LogTypePortalID, objLogTypeConfigInfo.KeepMostRecent, objLogTypeConfigInfo.LogFileName, objLogTypeConfigInfo.EmailNotificationIsActive, Convert.ToString(objLogTypeConfigInfo.NotificationThreshold), Convert.ToString(objLogTypeConfigInfo.NotificationThresholdTime), Convert.ToString(objLogTypeConfigInfo.NotificationThresholdTimeType), objLogTypeConfigInfo.MailFromAddress, objLogTypeConfigInfo.MailToAddress)
        End Sub

        Public Overridable Sub UpdateLogTypeConfigInfo(ByVal objLogTypeConfigInfo As LogTypeConfigInfo)
            LoggingProvider.Instance.UpdateLogTypeConfigInfo(objLogTypeConfigInfo.ID, objLogTypeConfigInfo.LoggingIsActive, objLogTypeConfigInfo.LogTypeKey, objLogTypeConfigInfo.LogTypePortalID, objLogTypeConfigInfo.KeepMostRecent, objLogTypeConfigInfo.LogFileName, objLogTypeConfigInfo.EmailNotificationIsActive, Convert.ToString(objLogTypeConfigInfo.NotificationThreshold), Convert.ToString(objLogTypeConfigInfo.NotificationThresholdTime), Convert.ToString(objLogTypeConfigInfo.NotificationThresholdTimeType), objLogTypeConfigInfo.MailFromAddress, objLogTypeConfigInfo.MailToAddress)
        End Sub

        Public Overridable Sub DeleteLogTypeConfigInfo(ByVal objLogTypeConfigInfo As LogTypeConfigInfo)
            LoggingProvider.Instance.DeleteLogTypeConfigInfo(objLogTypeConfigInfo.ID)
        End Sub

    End Class

End Namespace




