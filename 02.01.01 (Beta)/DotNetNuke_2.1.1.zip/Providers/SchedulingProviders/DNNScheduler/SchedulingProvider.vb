'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System
Imports System.IO
Imports System.Web
Imports System.Xml
Imports System.Reflection
Imports System.Threading
Imports DotNetNuke.Scheduling


Namespace DotNetNuke.Scheduling

    Public Class DNNScheduler
        Inherits Scheduling.SchedulingProvider
        Private Shared p As New Process

        Private Const ProviderType As String = "schedulingprovider"

        Public Overrides Function GetProviderPath() As String
            Return ProviderPath
        End Function

        Public Overrides Sub Start()
            If Enabled Then
                Dim s As New DotNetNuke.Scheduling.CoreScheduler(Debug, MaxThreads)
                s.KeepRunning = True
                s.Start()
            End If
        End Sub

        Public Overrides Sub ReStart(ByVal SourceOfRestart As String)
            Halt(SourceOfRestart)
            StartAndWaitForResponse()
        End Sub

        Public Overrides Sub StartAndWaitForResponse()
            If Enabled Then
                Dim s As New DotNetNuke.Scheduling.CoreScheduler(Debug, MaxThreads)
                s.KeepRunning = True
                s.StartAndWaitForResponse()
            End If
        End Sub

        Public Overrides Sub Halt(ByVal SourceOfHalt As String)
            Dim s As New DotNetNuke.Scheduling.CoreScheduler(Debug, MaxThreads)
            s.KeepRunning = False
            s.Halt(SourceOfHalt)
            DotNetNuke.Scheduling.CoreScheduler.KeepRunning = False
        End Sub

        Public Overrides Sub PurgeScheduleHistory()
            Dim s As New DotNetNuke.Scheduling.CoreScheduler(MaxThreads)
            s.PurgeScheduleHistory()
        End Sub

        Public Overrides Sub RunEventSchedule(ByVal objEventName As Scheduling.EventName)
            If Enabled Then
                Dim s As New DotNetNuke.Scheduling.CoreScheduler(Debug, MaxThreads)
                s.RunEventSchedule(objEventName)
            End If
        End Sub

        Public Overloads Overrides Function GetSchedule() As ArrayList
            Dim s As New DotNetNuke.Scheduling.SchedulingController
            Return s.GetSchedule
        End Function

        Public Overloads Overrides Function GetSchedule(ByVal ScheduleID As Integer) As ScheduleItem
            Dim s As New DotNetNuke.Scheduling.SchedulingController
            Return s.GetSchedule(ScheduleID)
        End Function
        Public Overrides Function GetScheduleHistory(ByVal ScheduleID As Integer) As ArrayList
            Dim s As New DotNetNuke.Scheduling.SchedulingController
            Return s.GetScheduleHistory(ScheduleID)
        End Function

        Public Overrides Function GetScheduleQueue() As Collection
            Dim s As New DotNetNuke.Scheduling.SchedulingController
            Return s.GetScheduleQueue()
        End Function

        Public Overrides Function GetScheduleProcessing() As Collection
            Dim s As New DotNetNuke.Scheduling.SchedulingController
            Return s.GetScheduleProcessing()
        End Function

        Public Overrides Function GetScheduleStatus() As ScheduleStatus
            Dim s As New DotNetNuke.Scheduling.SchedulingController
            Return s.GetScheduleStatus
        End Function

        Public Overrides Function AddSchedule(ByVal objScheduleItem As ScheduleItem) As Integer
            Dim s As New DotNetNuke.Scheduling.SchedulingController
            Return s.AddSchedule(objScheduleItem.TypeFullName, objScheduleItem.TimeLapse, objScheduleItem.TimeLapseMeasurement, objScheduleItem.RetryTimeLapse, objScheduleItem.RetryTimeLapseMeasurement, objScheduleItem.RetainHistoryNum, objScheduleItem.AttachToEvent, objScheduleItem.CatchUpEnabled, objScheduleItem.Enabled, objScheduleItem.ObjectDependencies)
        End Function

        Public Overrides Sub UpdateSchedule(ByVal objScheduleItem As ScheduleItem)
            Dim s As New DotNetNuke.Scheduling.SchedulingController
            s.UpdateSchedule(objScheduleItem.ScheduleID, objScheduleItem.TypeFullName, objScheduleItem.TimeLapse, objScheduleItem.TimeLapseMeasurement, objScheduleItem.RetryTimeLapse, objScheduleItem.RetryTimeLapseMeasurement, objScheduleItem.RetainHistoryNum, objScheduleItem.AttachToEvent, objScheduleItem.CatchUpEnabled, objScheduleItem.Enabled, objScheduleItem.ObjectDependencies)
        End Sub

        Public Overrides Sub DeleteSchedule(ByVal objScheduleItem As ScheduleItem)
            Dim s As New DotNetNuke.Scheduling.SchedulingController
            s.DeleteSchedule(objScheduleItem.ScheduleID)
        End Sub

        Public Overrides Function GetFreeThreadCount() As Integer
            Dim s As New DotNetNuke.Scheduling.SchedulingController
            Return s.GetFreeThreadCount
        End Function
        Public Overrides Function GetActiveThreadCount() As Integer
            Dim s As New DotNetNuke.Scheduling.SchedulingController
            Return s.GetActiveThreadCount
        End Function
        Public Overrides Function GetMaxThreadCount() As Integer
            Dim s As New DotNetNuke.Scheduling.SchedulingController
            Return s.GetMaxThreadCount
        End Function




    End Class


End Namespace
