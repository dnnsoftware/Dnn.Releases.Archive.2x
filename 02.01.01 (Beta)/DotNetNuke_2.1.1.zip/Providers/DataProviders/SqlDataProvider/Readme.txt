SqlDataProvider

To be used with SQL Server 2000 or MSDE 2000.

Static Attributes:

name = "SqlDataProvider" 
type = "DotNetNuke.Data.SqlDataProvider, DotNetNuke.SqlDataProvider" 

Dynamic Attributes:

connectionString = "Server=localhost;Database=DotNetNuke;uid=;pwd=;" 

- the connection string which will be used to access the database for all portal operations. For the optimal security, the account identified should only grant execute rights for stored procedures ( the Auto Upgrade logic requires a more priveleged user and should use the upgradeConnectionString attribute for this purpose ).

providerPath = "~\Providers\DataProviders\SqlDataProvider\" 

- the path which identifies the location of the SQL script files.

objectQualifier = "" 

- the unique qualifier for database objects ( tables, stored procedures, etc... )

databaseOwner = "dbo" 

- the owner for database objects ( tables, stored procedures, etc... )

upgradeConnectionString = ""

- a connection string identifying an account with "dbo" priveleges which is used solely for executing upgrade scripts. If it is not specified, the system will use the connectionString attribute for this purpose.

