Imports System.IO
Imports System.Web
Imports DotNetNuke
Imports FreeTextBoxControls

Namespace DotNetNuke.HtmlEditor
    Public Class FtbHtmlEditorProvider
        Inherits HtmlEditorProvider

        Dim cntlFtb As New FreeTextBoxControls.FreeTextBox

        Private Const ProviderType As String = "htmlEditor"

        Private _providerConfiguration As ProviderConfiguration = ProviderConfiguration.GetProviderConfiguration(ProviderType)
        Private _providerPath As String


        Public Sub New()

            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Read the configuration specific information for this provider
            Dim objProvider As Provider = CType(_providerConfiguration.Providers(_providerConfiguration.DefaultProvider), Provider)

            _providerPath = objProvider.Attributes("providerPath")

            'initialize the control
            cntlFtb.ImageGalleryPath = _portalSettings.UploadDirectory.Substring(_portalSettings.UploadDirectory.IndexOf("/Portals/"))
            cntlFtb.HelperFilesPath = "Providers/HtmlEditorProviders/FtbHtmlEditorProvider/Ftb/"

            cntlFtb.HelperFilesParameters = "tabid=" & _portalSettings.ActiveTab.TabId.ToString
            cntlFtb.ButtonPath = "Providers/HtmlEditorProviders/FtbHtmlEditorProvider/Ftb/images/"
            cntlFtb.ID = "FtbCntrl"

            'assign the initialized control as the HtmlEditorControl
            Me.HtmlEditorControl = cntlFtb
        End Sub


        Public ReadOnly Property ProviderPath() As String
            Get
                Return _providerPath
            End Get
        End Property


        'The Text, Width, and Height properties are retrieved and set by 
        'typing the HtmlEditorControl Web.UI.Control to FreeTextBoxControls.FreeTextBox
        'and accessing the FreeTextBox properties Text, Width, and Height
        Public Overrides Property Text() As String
            Get
                Text = CType(Me.HtmlEditorControl, FreeTextBoxControls.FreeTextBox).Text
            End Get
            Set(ByVal Value As String)
                CType(Me.HtmlEditorControl, FreeTextBoxControls.FreeTextBox).Text = Value
            End Set
        End Property

        Public Overrides Property Width() As System.Web.UI.WebControls.Unit
            Get
                Width = CType(Me.HtmlEditorControl, FreeTextBoxControls.FreeTextBox).Width
            End Get
            Set(ByVal Value As System.Web.UI.WebControls.Unit)
                CType(Me.HtmlEditorControl, FreeTextBoxControls.FreeTextBox).Width = Value
            End Set
        End Property

        Public Overrides Property Height() As System.Web.UI.WebControls.Unit
            Get
                Width = CType(Me.HtmlEditorControl, FreeTextBoxControls.FreeTextBox).Height
            End Get
            Set(ByVal Value As System.Web.UI.WebControls.Unit)
                CType(Me.HtmlEditorControl, FreeTextBoxControls.FreeTextBox).Height = Value
            End Set
        End Property

    End Class
End Namespace


