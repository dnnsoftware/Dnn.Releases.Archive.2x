'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke.Skins

    Public Class SolPartMenu

        Inherits SkinObject

        ' public attributes
        Public [separatecss] As String
        Public [menubarcssclass] As String
        Public [menucontainercssclass] As String
        Public [menuitemcssclass] As String
        Public [menuiconcssclass] As String
        Public [submenucssclass] As String
        Public [menuitemselcssclass] As String
        Public [menubreakcssclass] As String
        Public [menuarrowcssclass] As String
        Public [menurootarrowcssclass] As String
        Public [backcolor] As String
        Public [forecolor] As String
        Public [highlightcolor] As String
        Public [iconbackgroundcolor] As String
        Public [selectedbordercolor] As String
        Public [selectedcolor] As String
        Public [selectedforecolor] As String
        Public [display] As String
        Public [menubarheight] As String
        Public [menuborderwidth] As String
        Public [menuitemheight] As String
        Public [forcedownlevel] As String
        Public [moveable] As String
        Public [iconwidth] As String
        Public [menueffectsshadowcolor] As String
        Public [menueffectsmouseouthidedelay] As String
        Public [mouseouthidedelay] As String
        Public [menueffectsmouseoverdisplay] As String
        Public [menueffectsmouseoverexpand] As String
        Public [menueffectsstyle] As String
        Public [fontnames] As String
        Public [fontsize] As String
        Public [fontbold] As String
        Public [menueffectsshadowstrength] As String
        Public [menueffectsmenutransition] As String
        Public [menueffectsmenutransitionlength] As String
        Public [menueffectsshadowdirection] As String
        Public [forcefullmenulist] As String
        Public [useskinpatharrowimages] As String
        Public [userootbreadcrumbarrow] As String
        Public [usesubmenubreadcrumbarrow] As String
        Public [rootmenuitembreadcrumbcssclass] As String
        Public [submenuitembreadcrumbcssclass] As String
        Public [rootmenuitemcssclass] As String
        Public [rootbreadcrumbarrow] As String
        Public [submenubreadcrumbarrow] As String
        Public [usearrows] As String
        Public [downarrow] As String
        Public [rightarrow] As String
        Public [level] As String
        Public [rootonly] As String
        Public [rootmenuitemactivecssclass] As String
        Public [submenuitemactivecssclass] As String
        Public [rootmenuitemselectedcssclass] As String
        Public [submenuitemselectedcssclass] As String
        Public [separator] As String
        Public [separatorcssclass] As String
        Public [rootmenuitemlefthtml] As String
        Public [rootmenuitemrighthtml] As String
        Public [submenuitemlefthtml] As String
        Public [submenuitemrighthtml] As String
        Public [tooltip] As String
        Public [leftseparator] As String
        Public [rightseparator] As String
        Public [leftseparatoractive] As String
        Public [rightseparatoractive] As String
        Public [leftseparatorbreadcrumb] As String
        Public [rightseparatorbreadcrumb] As String
        Public [leftseparatorcssclass] As String
        Public [rightseparatorcssclass] As String
        Public [leftseparatoractivecssclass] As String
        Public [rightseparatoractivecssclass] As String
        Public [leftseparatorbreadcrumbcssclass] As String
        Public [rightseparatorbreadcrumbcssclass] As String
	Public [menualignment] As String

        Private PreviousRootBreadcrumbFlag As Boolean
        Private PreviousRootActiveFlag As Boolean
        Private NextRootBreadcrumbFlag As Boolean
        Private NextRootActiveFlag As Boolean

        ' protected controls
        Protected WithEvents ctlMenu As SolpartWebControls.SolpartMenu

#Region " Web Form Designer Generated Code "


        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this page is used
        ' to populate the role information for the page
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                SetAttributes()

                ' Obtain PortalSettings from Current Context
                Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

                Dim _UseSkinPathArrowImages As Boolean
                Dim _UseRootBreadcrumbArrow As Boolean
                Dim _UseSubMenuBreadcrumbArrow As Boolean
                Dim _RootBreadcrumbArrow As String
                Dim _SubMenuBreadcrumbArrow As String
                Dim _UseArrows As Boolean
                Dim _RightArrow As String
                Dim _DownArrow As String
                Dim intRootParent As Integer
                Dim _RootOnly As Boolean

                'This setting allows for skin independant images 
                'without breaking legacy skins
                If [useskinpatharrowimages] <> "" Then
                    _UseSkinPathArrowImages = Boolean.Parse([useskinpatharrowimages])
                Else
                    _UseSkinPathArrowImages = False
                End If
                'This setting determines if the DNN root menu will use 
                'an arrow to indicate it is the active root level tab
                If [userootbreadcrumbarrow] <> "" Then
                    _UseRootBreadcrumbArrow = Boolean.Parse([userootbreadcrumbarrow])
                Else
                    _UseRootBreadcrumbArrow = True
                End If
                'This setting determines if the DNN sub-menus will use an 
                'arrow to indicate it is a member of the Breadcrumb tabs
                If [usesubmenubreadcrumbarrow] <> "" Then
                    _UseSubMenuBreadcrumbArrow = Boolean.Parse([usesubmenubreadcrumbarrow])
                    If _UseSubMenuBreadcrumbArrow Then _SubMenuBreadcrumbArrow = Global.ApplicationPath & "/images/breadcrumb.gif"
                Else
                    _UseSubMenuBreadcrumbArrow = False
                End If
                'image for root menu breadcrumb marking
                If [rootbreadcrumbarrow] <> "" Then
                    _RootBreadcrumbArrow = _portalSettings.ActiveTab.SkinPath & [rootbreadcrumbarrow]
                Else
                    _RootBreadcrumbArrow = Global.ApplicationPath & "/images/breadcrumb.gif"
                End If
                'image for submenu breadcrumb marking
                If [submenubreadcrumbarrow] <> "" Then
                    _SubMenuBreadcrumbArrow = _portalSettings.ActiveTab.SkinPath & [submenubreadcrumbarrow]
                End If
                'This setting determines if the submenu arrows will be used
                If [usearrows] <> "" Then
                    _UseArrows = Boolean.Parse([usearrows])
                Else
                    _UseArrows = True
                End If
                'image for right facing arrow
                If [rightarrow] <> "" Then
                    _RightArrow = [rightarrow]
                Else
                    _RightArrow = "breadcrumb.gif"
                End If
                'image for down facing arrow
                If [downarrow] <> "" Then
                    _DownArrow = [downarrow]
                Else
                    _DownArrow = "menu_down.gif"
                End If
                'This setting indicates the root level for the menu
                Select Case LCase([level])
                    Case "child"
                        intRootParent = _portalSettings.ActiveTab.TabId
                    Case "same"
                        intRootParent = _portalSettings.ActiveTab.ParentId
                    Case Else 'root
                        intRootParent = -1
                End Select
                'This setting determines if the submenu will be shown
                If [rootonly] <> "" Then
                    _RootOnly = Boolean.Parse([rootonly])
                    If _RootOnly Then _UseArrows = False
                Else
                    _RootOnly = False
                End If
                'Set correct image path for all separator images
                If [separator] <> "" Then
                    If [separator].IndexOf("src=") <> -1 Then
                        [separator] = Replace([separator], "src=""", "src=""" & _portalSettings.ActiveTab.SkinPath)
                    End If
                End If

                If [leftseparator] <> "" Then
                    If [leftseparator].IndexOf("src=") <> -1 Then
                        [leftseparator] = Replace([leftseparator], "src=""", "src=""" & _portalSettings.ActiveTab.SkinPath)
                    End If
                End If
                If [rightseparator] <> "" Then
                    If [rightseparator].IndexOf("src=") <> -1 Then
                        [rightseparator] = Replace([rightseparator], "src=""", "src=""" & _portalSettings.ActiveTab.SkinPath)
                    End If
                End If
                If [leftseparatorbreadcrumb] <> "" Then
                    If [leftseparatorbreadcrumb].IndexOf("src=") <> -1 Then
                        [leftseparatorbreadcrumb] = Replace([leftseparatorbreadcrumb], "src=""", "src=""" & _portalSettings.ActiveTab.SkinPath)
                    End If
                End If
                If [rightseparatorbreadcrumb] <> "" Then
                    If [rightseparatorbreadcrumb].IndexOf("src=") <> -1 Then
                        [rightseparatorbreadcrumb] = Replace([rightseparatorbreadcrumb], "src=""", "src=""" & _portalSettings.ActiveTab.SkinPath)
                    End If
                End If
                If [leftseparatoractive] <> "" Then
                    If [leftseparatoractive].IndexOf("src=") <> -1 Then
                        [leftseparatoractive] = Replace([leftseparatoractive], "src=""", "src=""" & _portalSettings.ActiveTab.SkinPath)
                    End If
                End If
                If [rightseparatoractive] <> "" Then
                    If [rightseparatoractive].IndexOf("src=") <> -1 Then
                        [rightseparatoractive] = Replace([rightseparatoractive], "src=""", "src=""" & _portalSettings.ActiveTab.SkinPath)
                    End If
                End If

                ' Build list of tabs to be shown to user
                Dim authorizedTabs As New ArrayList
                Dim addedTabs As Integer = 0

                Dim i As Integer
                For i = 0 To _portalSettings.DesktopTabs.Count - 1

                    Dim tab As TabStripDetails = CType(_portalSettings.DesktopTabs(i), TabStripDetails)
                    If tab.IsVisible = True And tab.IsDeleted = False Then
                        If PortalSecurity.IsInRoles(tab.AuthorizedRoles) = True Then
                            authorizedTabs.Add(tab)
                            addedTabs += 1
                        End If
                    End If

                Next i

                ' generate dynamic menu
                If _UseSkinPathArrowImages = True Then
                    ctlMenu.SystemImagesPath = _portalSettings.ActiveTab.SkinPath
                Else
                    ctlMenu.SystemImagesPath = Global.ApplicationPath & "/images/"
                End If
                ctlMenu.IconImagesPath = _portalSettings.UploadDirectory
                If _UseArrows Then
                    ctlMenu.ArrowImage = _RightArrow
                    ctlMenu.RootArrow = True
                    If ctlMenu.Display = "Vertical" Then
                        ctlMenu.RootArrowImage = _RightArrow
                    Else
                        ctlMenu.RootArrowImage = _DownArrow
                    End If
                Else
                    ctlMenu.SystemImagesPath = Global.ApplicationPath & "/images/"
                    ctlMenu.ArrowImage = "spacer.gif"
                End If
                ctlMenu.SystemScriptPath = Global.ApplicationPath & "/controls/SolpartMenu/"

                Dim objTab As TabStripDetails
                Dim objAttribute As System.Xml.XmlAttribute
                Dim objMenuItem As Solpart.WebControls.SPMenuItemNode
                Dim RootFlag As Boolean

                For Each objTab In authorizedTabs
                    If objTab.ParentId = intRootParent Then ' root menu
                        For i = 0 To (_portalSettings.BreadCrumbs.Count - 1)
                            If objTab.TabId = CType(_portalSettings.BreadCrumbs(i), TabStripDetails).TabId Then
                                If [rootmenuitembreadcrumbcssclass] <> "" Then
                                    NextRootBreadcrumbFlag = True
                                End If
                                If [rootmenuitemactivecssclass] <> "" And objTab.TabId = _portalSettings.ActiveTab.TabId Then
                                    NextRootActiveFlag = True
                                End If
                            End If
                        Next i
                        If RootFlag = True Then 'first root item has already been entered
                            AddSeparator("All")
                        Else
                            If [leftseparator] <> "" Or [leftseparatorbreadcrumb] <> "" Or [leftseparatoractive] <> "" Then
                                AddSeparator("Left")
                            End If
                            RootFlag = True
                        End If
                        PreviousRootBreadcrumbFlag = False
                        PreviousRootActiveFlag = False
                        NextRootBreadcrumbFlag = False
                        NextRootActiveFlag = False

                        If objTab.DisableLink Then
                            objMenuItem = New Solpart.WebControls.SPMenuItemNode(ctlMenu.AddMenuItem(objTab.TabId.ToString, objTab.TabName, ""))
                        Else
                            objMenuItem = New Solpart.WebControls.SPMenuItemNode(ctlMenu.AddMenuItem(objTab.TabId.ToString, objTab.TabName, objTab.URL))
                        End If
                        If [rootmenuitemcssclass] <> "" Then
                            objMenuItem.ItemCss = [rootmenuitemcssclass]
                        End If
                        If [rootmenuitemselectedcssclass] <> "" Then
                            objMenuItem.ItemSelectedCss = [rootmenuitemselectedcssclass]
                        End If

                        If [rootmenuitemlefthtml] <> "" Then
                            objMenuItem.LeftHTML = [rootmenuitemlefthtml]
                        End If
                        'add image next to root breadcrumb item and set css class if any
                        For i = 0 To (_portalSettings.BreadCrumbs.Count - 1)
                            If objTab.TabId = CType(_portalSettings.BreadCrumbs(i), TabStripDetails).TabId Then
                                If _UseRootBreadcrumbArrow = True Then
                                    objMenuItem.LeftHTML += "<img alt=""*"" BORDER=""0"" src=""" & _RootBreadcrumbArrow & """>"
                                End If
                                If [rootmenuitembreadcrumbcssclass] <> "" Then
                                    objMenuItem.ItemCss = [rootmenuitembreadcrumbcssclass]
                                    PreviousRootBreadcrumbFlag = True
                                End If
                                If [rootmenuitemactivecssclass] <> "" And objTab.TabId = _portalSettings.ActiveTab.TabId Then
                                    objMenuItem.ItemCss = [rootmenuitemactivecssclass]
                                    PreviousRootActiveFlag = True
                                End If
                            End If
                        Next i
                        If [rootmenuitemrighthtml] <> "" Then
                            objMenuItem.RightHTML = [rootmenuitemrighthtml]
                        End If

                    ElseIf Not _RootOnly Then
                        Try
                            If objTab.DisableLink Then
                                objMenuItem = New Solpart.WebControls.SPMenuItemNode(ctlMenu.AddMenuItem(objTab.ParentId.ToString, objTab.TabId.ToString, "&nbsp;" & objTab.TabName, ""))
                            Else
                                objMenuItem = New Solpart.WebControls.SPMenuItemNode(ctlMenu.AddMenuItem(objTab.ParentId.ToString, objTab.TabId.ToString, "&nbsp;" & objTab.TabName, objTab.URL))
                            End If

                            If [submenuitemselectedcssclass] <> "" Then
                                objMenuItem.ItemSelectedCss = [submenuitemselectedcssclass]
                            End If
                            If [submenuitemlefthtml] <> "" Then
                                objMenuItem.LeftHTML = [submenuitemlefthtml]
                            End If

                            'add image next to submenu breadcrumb item and set css class if any
                            For i = 0 To (_portalSettings.BreadCrumbs.Count - 1)
                                If objTab.TabId = CType(_portalSettings.BreadCrumbs(i), TabStripDetails).TabId Then
                                    If _UseSubMenuBreadcrumbArrow = True Then
                                        objMenuItem.LeftHTML += "<img alt=""*"" BORDER=""0"" src=""" & _SubMenuBreadcrumbArrow & """>"
                                    End If
                                    If [submenuitembreadcrumbcssclass] <> "" Then
                                        objMenuItem.ItemCss = [submenuitembreadcrumbcssclass]
                                    End If
                                    If [submenuitemactivecssclass] <> "" And objTab.TabId = _portalSettings.ActiveTab.TabId Then
                                        objMenuItem.ItemCss = [submenuitemactivecssclass]
                                    End If
                                End If
                            Next i

                            If [submenuitemrighthtml] <> "" Then
                                objMenuItem.RightHTML = [submenuitemrighthtml]
                            End If
                        Catch
                            ' throws exception if the parent tab has not been loaded ( may be related to user role security not allowing access to a parent tab )
                            objMenuItem = Nothing
                        End Try
                    Else
                        objMenuItem = Nothing
                    End If

                    ' menu icon
                    If Not objMenuItem Is Nothing Then
                        If IsAdminTab(objTab.TabId, objTab.ParentId) Then
                            If objTab.IconFile <> "" Then
                                objMenuItem.Image = objTab.IconFile
                                objMenuItem.ImagePath = Global.ApplicationPath & "/images/"
                            End If
                        Else
                            If objTab.IconFile <> "" Then
                                objMenuItem.Image = objTab.IconFile
                            End If
                        End If
                    End If
                    Select Case LCase([tooltip])
                        Case "name"
                            objMenuItem.ToolTip = objTab.TabName
                        Case "title"
                            objMenuItem.ToolTip = objTab.Title
                        Case "description"
                            objMenuItem.ToolTip = objTab.Description
                        Case Else

                    End Select

                Next
                If [rightseparator] <> "" Or [rightseparatorbreadcrumb] <> "" Or [rightseparatoractive] <> "" Then
                    AddSeparator("Right")
                End If
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub
        Private Sub AddSeparator(ByVal strType As String)
            If [separator] <> "" Or _
            [leftseparator] <> "" Or _
            [rightseparator] <> "" Or _
            [leftseparatorbreadcrumb] <> "" Or _
            [rightseparatorbreadcrumb] <> "" Or _
            [leftseparatoractive] <> "" Or _
            [rightseparatoractive] <> "" Or _
            [rightseparatoractive] <> "" Then
                Dim objBreak As System.Xml.XmlNode
                Dim strParent As String = ""
                Dim strSeparator As String = ""
                Dim _Separator As String = ""
                Dim _LeftSeparator As String = ""
                Dim _RightSeparator As String = ""
                Dim _SeparatorClass As String = ""
                Dim _LeftSeparatorClass As String = ""
                Dim _RightSeparatorClass As String = ""

                If [leftseparator] <> "" Or [leftseparatorbreadcrumb] <> "" Or [leftseparatoractive] <> "" Then
                    If [leftseparatorcssclass] <> "" Then
                        _LeftSeparatorClass = [leftseparatorcssclass]
                    End If
                    If [leftseparatorbreadcrumbcssclass] <> "" And NextRootBreadcrumbFlag Then
                        _LeftSeparatorClass = [leftseparatorbreadcrumbcssclass]
                    End If
                    If [leftseparatoractivecssclass] <> "" And NextRootActiveFlag Then
                        _LeftSeparatorClass = [leftseparatoractivecssclass]
                    End If
                    If [leftseparator] <> "" Then
                        _LeftSeparator = [leftseparator]
                    End If
                    If [leftseparatorbreadcrumb] <> "" And NextRootBreadcrumbFlag Then
                        _LeftSeparator = [leftseparatorbreadcrumb]
                    End If
                    If [leftseparatoractive] <> "" And NextRootActiveFlag Then
                        _LeftSeparator = [leftseparatoractive]
                    End If
                End If
                If [separator] <> "" Then
                    If [separatorcssclass] <> "" Then
                        _SeparatorClass = [separatorcssclass]
                    End If
                    _Separator = [separator]
                End If
                If [rightseparator] <> "" Or [rightseparatorbreadcrumb] <> "" Or [rightseparatoractive] <> "" Then
                    If [rightseparatorcssclass] <> "" Then
                        _RightSeparatorClass = [rightseparatorcssclass]
                    End If
                    If [rightseparatorbreadcrumbcssclass] <> "" And PreviousRootBreadcrumbFlag Then
                        _RightSeparatorClass = [rightseparatorbreadcrumbcssclass]
                    End If
                    If [rightseparatoractivecssclass] <> "" And PreviousRootActiveFlag Then
                        _RightSeparatorClass = [rightseparatoractivecssclass]
                    End If
                    If [rightseparator] <> "" Then
                        _RightSeparator = [rightseparator]
                    End If
                    If [rightseparatorbreadcrumb] <> "" And PreviousRootBreadcrumbFlag Then
                        _RightSeparator = [rightseparatorbreadcrumb]
                    End If
                    If [rightseparatoractive] <> "" And PreviousRootActiveFlag Then
                        _RightSeparator = [rightseparatoractive]
                    End If

                End If
                strSeparator = "<table summary=""Table for menu separator design"" border=""0"" cellpadding=""0"" cellspacing=""0""><tr>"
                If _RightSeparator <> "" And strType <> "Left" Then
                    If _RightSeparatorClass <> "" Then
                        strSeparator += "<td class = """ & _RightSeparatorClass & """>"
                    Else
                        strSeparator += "<td>"
                    End If
                    strSeparator += _RightSeparator & "</td>"
                End If
                If _Separator <> "" And strType <> "Left" And strType <> "Right" Then
                    If _SeparatorClass <> "" Then
                        strSeparator += "<td class = """ & _SeparatorClass & """>"
                    Else
                        strSeparator += "<td>"
                    End If
                    strSeparator += _Separator & "</td>"
                End If
                If _LeftSeparator <> "" And strType <> "Right" Then
                    If _LeftSeparatorClass <> "" Then
                        strSeparator += "<td class = """ & _LeftSeparatorClass & """>"
                    Else
                        strSeparator += "<td>"
                    End If
                    strSeparator += _LeftSeparator & "</td>"
                End If
                strSeparator += "</tr></table>"
                objBreak = ctlMenu.AddBreak(strParent, strSeparator)
            End If
        End Sub
        Private Sub SetAttributes()
            ctlMenu.SeparateCSS = True
            ctlMenu.SelectedBorderColor = Nothing

            If [separatecss] <> "" Then
                ctlMenu.SeparateCSS = Convert.ToBoolean([separatecss])
            End If
            If [backcolor] <> "" Then
                ctlMenu.BackColor = Color.FromName([backcolor])
            End If
            If [forecolor] <> "" Then
                ctlMenu.ForeColor = Color.FromName([forecolor])
            End If
            If [highlightcolor] <> "" Then
                ctlMenu.HighlightColor = Color.FromName([highlightcolor])
            End If
            If [iconbackgroundcolor] <> "" Then
                ctlMenu.IconBackgroundColor = Color.FromName([iconbackgroundcolor])
            End If
            If [selectedbordercolor] <> "" Then
                ctlMenu.SelectedBorderColor = Color.FromName([selectedbordercolor])
            End If
            If [selectedcolor] <> "" Then
                ctlMenu.SelectedColor = Color.FromName([selectedcolor])
            End If
            If [selectedforecolor] <> "" Then
                ctlMenu.SelectedForeColor = Color.FromName([selectedforecolor])
            End If
            If [display] <> "" Then
                ctlMenu.Display = [display]
            End If
            If [menubarheight] <> "" Then
                ctlMenu.MenuBarHeight = Convert.ToInt64([menubarheight])
            End If
            If [menuborderwidth] <> "" Then
                ctlMenu.MenuBorderWidth = Convert.ToInt32([menuborderwidth])
            End If
            If [menuitemheight] <> "" Then
                ctlMenu.MenuItemHeight = Convert.ToInt64([menuitemheight])
            End If
            If [forcedownlevel] <> "" Then
                ctlMenu.ForceDownlevel = Convert.ToBoolean([forcedownlevel])
            End If
            If [moveable] <> "" Then
                ctlMenu.Moveable = Convert.ToBoolean([moveable])
            End If
            If [iconwidth] <> "" Then
                ctlMenu.IconWidth = Convert.ToInt64([iconwidth])
            End If
            If [menueffectsshadowcolor] <> "" Then
                ctlMenu.MenuEffects.ShadowColor = Color.FromName([menueffectsshadowcolor])
            End If
            If [menueffectsmouseouthidedelay] <> "" Then
                ctlMenu.MenuEffects.MouseOutHideDelay = Convert.ToInt32([menueffectsmouseouthidedelay])
            End If
            If [mouseouthidedelay] <> "" Then
                ctlMenu.MenuEffects.MouseOutHideDelay = Convert.ToInt32([mouseouthidedelay])
            End If
            If [menueffectsmouseoverdisplay] <> "" Then
                Select Case LCase([menueffectsmouseoverdisplay])
                    Case "highlight"
                        ctlMenu.MenuEffects.MouseOverDisplay = Solpart.WebControls.MenuEffectsMouseOverDisplay.Highlight
                    Case "none"
                        ctlMenu.MenuEffects.MouseOverDisplay = Solpart.WebControls.MenuEffectsMouseOverDisplay.None
                    Case "outset"
                        ctlMenu.MenuEffects.MouseOverDisplay = Solpart.WebControls.MenuEffectsMouseOverDisplay.Outset
                End Select
            End If
            If [menueffectsmouseoverexpand] <> "" Then
                ctlMenu.MenuEffects.MouseOverExpand = Convert.ToBoolean([menueffectsmouseoverexpand])
            End If
            If [menueffectsstyle] <> "" Then
                ctlMenu.MenuEffects.Style.Concat(ctlMenu.MenuEffects.Style.ToString, [menueffectsstyle])
            End If
            If [fontnames] <> "" Then
                ctlMenu.Font.Names = [fontnames].Split(Convert.ToChar(";"))
            End If
            If [fontsize] <> "" Then
                ctlMenu.Font.Size = FontUnit.Parse([fontsize])
            End If
            If [fontbold] <> "" Then
                ctlMenu.Font.Bold = Convert.ToBoolean([fontbold])
            End If
            If [menueffectsshadowstrength] <> "" Then
                ctlMenu.MenuEffects.ShadowStrength = Convert.ToInt32([menueffectsshadowstrength])
            End If
            If [menueffectsmenutransition] <> "" Then
                ctlMenu.MenuEffects.MenuTransition = [menueffectsmenutransition]
            End If
            If [menueffectsmenutransitionlength] <> "" Then
                ctlMenu.MenuEffects.MenuTransitionLength = Convert.ToDouble([menueffectsmenutransitionlength])
            End If
            If [menueffectsshadowdirection] <> "" Then
                ctlMenu.MenuEffects.ShadowDirection = [menueffectsshadowdirection]
            End If
            If [forcefullmenulist] <> "" Then
                ctlMenu.ForceFullMenuList = Convert.ToBoolean([forcefullmenulist])
            End If
            If ctlMenu.SeparateCSS = True Then
                If [menubarcssclass] <> "" Then
                    ctlMenu.MenuCSS.MenuBar = [menubarcssclass]
                Else
                    ctlMenu.MenuCSS.MenuBar = "MainMenu_MenuBar"
                End If
                If [menucontainercssclass] <> "" Then
                    ctlMenu.MenuCSS.MenuContainer = [menucontainercssclass]
                Else
                    ctlMenu.MenuCSS.MenuContainer = "MainMenu_MenuContainer"
                End If
                If [menuitemcssclass] <> "" Then
                    ctlMenu.MenuCSS.MenuItem = [menuitemcssclass]
                Else
                    ctlMenu.MenuCSS.MenuItem = "MainMenu_MenuItem"
                End If
                If [menuiconcssclass] <> "" Then
                    ctlMenu.MenuCSS.MenuIcon = [menuiconcssclass]
                Else
                    ctlMenu.MenuCSS.MenuIcon = "MainMenu_MenuIcon"
                End If
                If [submenucssclass] <> "" Then
                    ctlMenu.MenuCSS.SubMenu = [submenucssclass]
                Else
                    ctlMenu.MenuCSS.SubMenu = "MainMenu_SubMenu"
                End If
                If [menubreakcssclass] <> "" Then
                    ctlMenu.MenuCSS.MenuBreak = [menubreakcssclass]
                Else
                    ctlMenu.MenuCSS.MenuBreak = "MainMenu_MenuBreak"
                End If
                If [menuitemselcssclass] <> "" Then
                    ctlMenu.MenuCSS.MenuItemSel = [menuitemselcssclass]
                Else
                    ctlMenu.MenuCSS.MenuItemSel = "MainMenu_MenuItemSel"
                End If
                If [menuarrowcssclass] <> "" Then
                    ctlMenu.MenuCSS.MenuArrow = [menuarrowcssclass]
                Else
                    ctlMenu.MenuCSS.MenuArrow = "MainMenu_MenuArrow"
                End If
                If [menurootarrowcssclass] <> "" Then
                    ctlMenu.MenuCSS.RootMenuArrow = [menurootarrowcssclass]
                Else
                    ctlMenu.MenuCSS.RootMenuArrow = "MainMenu_RootMenuArrow"
                End If
            End If
            If [menualignment] <> "" Then
                Select Case LCase([menualignment])
                    Case "right"
                        ctlMenu.MenuAlignment = "Right"
                    Case "centered"
                        ctlMenu.MenuAlignment = "Centered"
                    Case "justified"
                        ctlMenu.MenuAlignment = "Justified"
                    Case Else
                        ctlMenu.MenuAlignment = "Left"
                End Select
            End If

        End Sub

    End Class

End Namespace
