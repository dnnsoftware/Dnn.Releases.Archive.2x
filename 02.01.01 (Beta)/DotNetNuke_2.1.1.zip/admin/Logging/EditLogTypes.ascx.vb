'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke.Logging

    Public Class EditLogTypes
        Inherits PortalModuleControl

        Protected WithEvents pnlLogTypeConfigInfo As System.Web.UI.WebControls.Panel
        Protected WithEvents txtLogTypeKey As System.Web.UI.WebControls.TextBox
        Protected WithEvents ddlKeepMostRecent As System.Web.UI.WebControls.DropDownList
        Protected WithEvents txtFileName As System.Web.UI.WebControls.TextBox
        Protected WithEvents pnlEditLogTypeConfigInfo As System.Web.UI.WebControls.Panel
        Protected WithEvents chkIsActive As System.Web.UI.WebControls.CheckBox
        Protected WithEvents txtLogTypeFriendlyName As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtLogTypeDescription As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtLogTypeOwner As System.Web.UI.WebControls.TextBox
        Protected WithEvents chkEmailNotificationStatus As System.Web.UI.WebControls.CheckBox
        Protected WithEvents ddlThreshold As System.Web.UI.WebControls.DropDownList
        Protected WithEvents txtMailFromAddress As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtMailToAddress As System.Web.UI.WebControls.TextBox
        Protected WithEvents ddlThresholdNotificationTime As System.Web.UI.WebControls.DropDownList
        Protected WithEvents ddlThresholdNotificationTimeType As System.Web.UI.WebControls.DropDownList
        Protected WithEvents ddlLogTypePortalID As System.Web.UI.WebControls.DropDownList
        Protected WithEvents ddlLogTypeKey As System.Web.UI.WebControls.DropDownList
        Protected WithEvents btnSave As System.Web.UI.WebControls.LinkButton
        Protected WithEvents btnDelete As System.Web.UI.WebControls.LinkButton
        Protected WithEvents dgLogTypeConfigInfo As System.Web.UI.WebControls.DataGrid



#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
            MyBase.Actions.Add(GetNextActionID, "Add Log Configurations", "", URL:=EditURL("action", "add"), secure:=SecurityAccessLevel.Admin, Visible:=True)
        End Sub

#End Region


        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If Not Page.IsPostBack Then
                    If Request.QueryString("action") = "add" Then
                        BindDetailData()
                    Else
                        BindSummaryData()
                    End If
                End If


            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub BindSummaryData()
            Dim objLogController As New LogController
            Dim arrLogTypeConfigInfo As ArrayList = objLogController.GetLogTypeConfigInfo()
            dgLogTypeConfigInfo.DataSource() = arrLogTypeConfigInfo
            dgLogTypeConfigInfo.DataBind()
            pnlEditLogTypeConfigInfo.Visible = False
            pnlLogTypeConfigInfo.Visible = True
        End Sub
        Private Sub BindDetailData()
            Dim pc As New PortalController
            ddlLogTypePortalID.DataTextField = "PortalName"
            ddlLogTypePortalID.DataValueField = "PortalID"
            ddlLogTypePortalID.DataSource = pc.GetPortals()
            ddlLogTypePortalID.DataBind()

            Dim i As New ListItem
            i.Text = "All"
            i.Value = "*"
            ddlLogTypePortalID.Items.Insert(0, i)


            pnlEditLogTypeConfigInfo.Visible = True
            pnlLogTypeConfigInfo.Visible = False
            Dim l As New LogController

            Dim arrLogTypeInfo As ArrayList
            arrLogTypeInfo = l.GetLogTypeInfo()

            arrLogTypeInfo.Sort(New LogTypeSortFriendlyName)


            ddlLogTypeKey.DataTextField = "LogTypeFriendlyName"
            ddlLogTypeKey.DataValueField = "LogTypeKey"
            ddlLogTypeKey.DataSource = arrLogTypeInfo
            ddlLogTypeKey.DataBind()

            Dim j As New ListItem
            j.Text = "All"
            j.Value = "*"
            ddlLogTypeKey.Items.Insert(0, j)
        End Sub
        Public Sub dgLogTypeConfigInfo_EditCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dgLogTypeConfigInfo.EditCommand
            Dim LogID As String = Convert.ToString(dgLogTypeConfigInfo.DataKeys(e.Item.ItemIndex))
            ViewState("LogID") = LogID

            BindDetailData()

            Dim l As New LogController

            Dim objLogTypeConfigInfo As LogTypeConfigInfo = l.GetLogTypeConfigInfoByID(LogID)

            txtFileName.Text = objLogTypeConfigInfo.LogFileName
            chkIsActive.Checked = objLogTypeConfigInfo.LoggingIsActive
            chkEmailNotificationStatus.Checked = objLogTypeConfigInfo.EmailNotificationIsActive

            If Not ddlLogTypeKey.Items.FindByValue(objLogTypeConfigInfo.LogTypeKey) Is Nothing Then
                ddlLogTypeKey.ClearSelection()
                ddlLogTypeKey.Items.FindByValue(objLogTypeConfigInfo.LogTypeKey).Selected = True
            End If
            If Not ddlLogTypePortalID.Items.FindByValue(objLogTypeConfigInfo.LogTypePortalID) Is Nothing Then
                ddlLogTypePortalID.ClearSelection()
                ddlLogTypePortalID.Items.FindByValue(objLogTypeConfigInfo.LogTypePortalID).Selected = True
            End If
            If Not ddlKeepMostRecent.Items.FindByValue(objLogTypeConfigInfo.KeepMostRecent) Is Nothing Then
                ddlKeepMostRecent.ClearSelection()
                ddlKeepMostRecent.Items.FindByValue(objLogTypeConfigInfo.KeepMostRecent).Selected = True
            End If
            If Not ddlThreshold.Items.FindByValue(objLogTypeConfigInfo.NotificationThreshold.ToString) Is Nothing Then
                ddlThreshold.ClearSelection()
                ddlThreshold.Items.FindByValue(objLogTypeConfigInfo.NotificationThreshold.ToString).Selected = True
            End If
            If Not ddlThresholdNotificationTime.Items.FindByValue(objLogTypeConfigInfo.NotificationThresholdTime.ToString) Is Nothing Then
                ddlThresholdNotificationTime.ClearSelection()
                ddlThresholdNotificationTime.Items.FindByValue(objLogTypeConfigInfo.NotificationThresholdTime.ToString).Selected = True
            End If
            If Not ddlThresholdNotificationTimeType.Items.FindByValue(objLogTypeConfigInfo.NotificationThresholdTimeType.ToString) Is Nothing Then
                ddlThresholdNotificationTimeType.ClearSelection()
                ddlThresholdNotificationTimeType.Items.FindByValue(objLogTypeConfigInfo.NotificationThresholdTimeType.ToString).Selected = True
            End If
            txtMailFromAddress.Text = objLogTypeConfigInfo.MailFromAddress
            txtMailToAddress.Text = objLogTypeConfigInfo.MailToAddress

            DisableLoggingControls()

        End Sub

        Private Sub DisableLoggingControls()
            If chkIsActive.Checked = True Then
                ddlLogTypeKey.Enabled = True
                ddlLogTypePortalID.Enabled = True
                ddlKeepMostRecent.Enabled = True
                txtFileName.Enabled = True
            Else
                ddlLogTypeKey.Enabled = False
                ddlLogTypePortalID.Enabled = False
                ddlKeepMostRecent.Enabled = False
                txtFileName.Enabled = False
            End If

        End Sub
        Private Sub DisableNotificationControls()
            If chkEmailNotificationStatus.Checked = True Then
                ddlThreshold.Enabled = True
                ddlThresholdNotificationTime.Enabled = True
                ddlThresholdNotificationTimeType.Enabled = True
                txtMailFromAddress.Enabled = True
                txtMailToAddress.Enabled = True
            Else
                ddlThreshold.Enabled = False
                ddlThresholdNotificationTime.Enabled = False
                ddlThresholdNotificationTimeType.Enabled = False
                txtMailFromAddress.Enabled = False
                txtMailToAddress.Enabled = False
            End If
        End Sub
        Private Sub chkIsActive_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkIsActive.CheckedChanged
            DisableLoggingControls()
        End Sub

        Private Sub chkEmailNotificationStatus_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkEmailNotificationStatus.CheckedChanged
            DisableNotificationControls()
        End Sub

        Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
            Dim objLogTypeConfigInfo As New LogTypeConfigInfo
            objLogTypeConfigInfo.LoggingIsActive = chkIsActive.Checked
            objLogTypeConfigInfo.LogTypeKey = ddlLogTypeKey.SelectedItem.Value
            objLogTypeConfigInfo.LogTypePortalID = ddlLogTypePortalID.SelectedItem.Value
            objLogTypeConfigInfo.KeepMostRecent = ddlKeepMostRecent.SelectedItem.Value
            objLogTypeConfigInfo.LogFileName = txtFileName.Text

            objLogTypeConfigInfo.EmailNotificationIsActive = chkEmailNotificationStatus.Checked
            objLogTypeConfigInfo.NotificationThreshold = Convert.ToInt32(ddlThreshold.SelectedItem.Value)
            objLogTypeConfigInfo.NotificationThresholdTime = Convert.ToInt32(ddlThresholdNotificationTime.SelectedItem.Value)
            objLogTypeConfigInfo.NotificationThresholdTimeType = CType(ddlThresholdNotificationTimeType.SelectedItem.Value, LogTypeConfigInfo.NotificationThresholdTimeTypes)
            objLogTypeConfigInfo.MailFromAddress = txtMailFromAddress.Text
            objLogTypeConfigInfo.MailToAddress = txtMailToAddress.Text

            Dim l As New LogController

            If Not ViewState("LogID") Is Nothing Then
                objLogTypeConfigInfo.ID = Convert.ToString(ViewState("LogID"))
                l.UpdateLogTypeConfigInfo(objLogTypeConfigInfo)
                Skin.AddModuleMessage(Me, "Log configuration has been updated.", Skins.ModuleMessage.ModuleMessageType.GreenSuccess)
            Else
                objLogTypeConfigInfo.ID = Guid.NewGuid.ToString
                l.AddLogTypeConfigInfo(objLogTypeConfigInfo)
                Skin.AddModuleMessage(Me, "Log configuration has been added.", Skins.ModuleMessage.ModuleMessageType.GreenSuccess)
            End If

            BindSummaryData()

        End Sub

        Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
            Dim objLogTypeConfigInfo As New LogTypeConfigInfo
            Dim l As New LogController
            objLogTypeConfigInfo.ID = Convert.ToString(ViewState("LogID"))
            l.DeleteLogTypeConfigInfo(objLogTypeConfigInfo)
            Skin.AddModuleMessage(Me, "The selected log configuration has been deleted.", Skins.ModuleMessage.ModuleMessageType.GreenSuccess)
            BindSummaryData()
        End Sub

    End Class





End Namespace