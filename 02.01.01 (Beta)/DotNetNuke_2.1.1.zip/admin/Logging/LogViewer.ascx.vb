'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Xml
Imports System.Configuration
Imports System.Net
Imports System.IO

Namespace DotNetNuke.Logging

    Public Class LogViewer

        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents dlLog As System.Web.UI.WebControls.DataList
        Protected WithEvents txtEmailAddress As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtMessage As System.Web.UI.WebControls.TextBox
        Protected WithEvents emailExceptions As System.Web.UI.WebControls.Panel
        Protected WithEvents txtServerSendDNNEmail As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtServerSendDNNMessage As System.Web.UI.WebControls.TextBox
        Protected WithEvents btnServerSendToDNN As System.Web.UI.HtmlControls.HtmlAnchor
        Protected WithEvents pnlSendEmail As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlSendServer As System.Web.UI.WebControls.Panel
        Protected WithEvents btnEmail As System.Web.UI.WebControls.LinkButton
        Protected WithEvents ddlPortalID As System.Web.UI.WebControls.DropDownList
        Protected WithEvents pnlOptions As System.Web.UI.WebControls.Panel
        Protected WithEvents btnDelete As System.Web.UI.WebControls.LinkButton
        Protected WithEvents btnClear As System.Web.UI.WebControls.LinkButton
        Protected WithEvents ddlLogType As System.Web.UI.WebControls.DropDownList
        Protected WithEvents pnlSendExceptions As System.Web.UI.WebControls.Panel
        Protected WithEvents chkColorCoding As System.Web.UI.WebControls.CheckBox
        Protected WithEvents pnlLegend As System.Web.UI.WebControls.Panel
        Protected WithEvents txtShowing As System.Web.UI.WebControls.Label
        Protected WithEvents tblInstructions As System.Web.UI.HtmlControls.HtmlTable

        Dim arrLogTypeInfo As ArrayList
        Dim htLogTypeInfo As Hashtable
        Protected WithEvents minLegend As System.Web.UI.WebControls.ImageButton
        Dim ColorCodingOn As Boolean = False
        Protected WithEvents ddlShowRecords As System.Web.UI.WebControls.DropDownList
        Protected WithEvents lblPortalID As System.Web.UI.WebControls.Label
        Protected WithEvents lblType As System.Web.UI.WebControls.Label
        Dim ColorCodingLegendOn As Boolean = True

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            If IsEditable Then
                MyBase.Actions.Add(GetNextActionID, "Edit Log Configurations", "", URL:=EditURL(), secure:=SecurityAccessLevel.Admin, Visible:=True)
            End If

            InitializeComponent()
            Dim l As New LogController
            arrLogTypeInfo = l.GetLogTypeInfo()

            htLogTypeInfo = New Hashtable

            Dim i As Integer
            For i = 0 To arrLogTypeInfo.Count - 1
                Dim objLogTypeInfo As LogTypeInfo = CType(arrLogTypeInfo(i), LogTypeInfo)
                htLogTypeInfo.Add(objLogTypeInfo.LogTypeKey, objLogTypeInfo)
            Next

            Dim objPersonalization As New Personalization
            Dim ColorCoding As String
            ColorCoding = Convert.ToString(objPersonalization.GetProfile("LogViewer", "ColorCoding"))
            If ColorCoding = "0" Then
                ColorCodingOn = False
            ElseIf ColorCoding = "1" Then
                ColorCodingOn = True
            Else
                ColorCodingOn = True
            End If

            Dim ColorCodingLegend As String
            ColorCodingLegend = Convert.ToString(objPersonalization.GetProfile("LogViewer", "ColorCodingLegend"))
            If ColorCodingLegend = "0" Then
                ColorCodingLegendOn = False
            ElseIf ColorCodingLegend = "1" Then
                ColorCodingLegendOn = True
            Else
                ColorCodingLegendOn = True
            End If

        End Sub

#End Region
        '*******************************************************
        '
        ' The Page_Load server event handler on this user control is used
        ' to populate the current site settings from the config system
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                ' Obtain PortalSettings from Current Context
                Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)
                Dim objPortalSecurity As New PortalSecurity

                ' If this is the first visit to the page, populate the site data
                If Page.IsPostBack = False Then
                    Dim objLC As New LogController
                    objLC.PurgeLogBuffer()

                    BindPortalDropDown()
                    BindLogTypeDropDown()
                    BindData()
                End If

            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub
        Private Sub BindPortalDropDown()
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)
            Dim objPortalSecurity As New PortalSecurity

            If Convert.ToInt32(Context.User.Identity.Name) = _portalSettings.SuperUserId Then
                Dim objPortalController As New PortalController
                Dim arrPortals As New ArrayList
                arrPortals = objPortalController.GetPortals()
                arrPortals.Sort(New PortalSortTitle)
                ddlPortalID.DataTextField = "PortalName"
                ddlPortalID.DataValueField = "PortalID"
                ddlPortalID.DataSource = arrPortals
                ddlPortalID.DataBind()
                Dim ddlAllPortals As New ListItem("All", "-1")
                ddlPortalID.Items.Insert(0, ddlAllPortals)
            Else
                lblPortalID.Visible = False
                ddlPortalID.Visible = False
            End If
        End Sub
        Private Sub BindLogTypeDropDown()
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim objLogController As New LogController
            Dim arrLogTypes As New ArrayList
            arrLogTypes = objLogController.GetLogTypeInfo()
            arrLogTypes.Sort(New LogTypeSortFriendlyName)
            ddlLogType.DataTextField = "LogTypeFriendlyName"
            ddlLogType.DataValueField = "LogTypeKey"
            ddlLogType.DataSource = arrLogTypes
            ddlLogType.DataBind()
            Dim ddlAllPortals As New ListItem("All", "*")
            ddlLogType.Items.Insert(0, ddlAllPortals)

        End Sub
        Private Sub BindShowRecords(ByVal intLogCount As Integer)
            Dim strSelectedValue As String
            If Not ddlShowRecords.SelectedItem Is Nothing Then
                strSelectedValue = ddlShowRecords.SelectedItem.Value
            Else
                strSelectedValue = "1"
            End If
            ddlShowRecords.Items.Clear()
            Dim tmpItem As ListItem
            If intLogCount >= 100 Then
                tmpItem = New ListItem("1 - 100", "1")
            ElseIf intLogCount = 0 Then
                tmpItem = New ListItem("0", "0")
            Else
                tmpItem = New ListItem("1 - " + intLogCount.ToString, "1")
            End If
            ddlShowRecords.Items.Add(tmpItem)

            Dim i As Integer
            Dim j As Integer
            For i = 0 To intLogCount
                j += 100
                If intLogCount > j Then
                    If intLogCount > j + 100 Then
                        tmpItem = New ListItem((j + 1).ToString + " - " + (j + 99).ToString, (j + 1).ToString)
                    Else
                        tmpItem = New ListItem((j + 1).ToString + " - " + intLogCount.ToString, (j + 1).ToString)
                    End If
                    ddlShowRecords.Items.Add(tmpItem)
                End If
            Next


            Dim ddlAllPortals As New ListItem("All", "*")
            ddlShowRecords.Items.Add(ddlAllPortals)

            If Not ddlShowRecords.Items.FindByValue(strSelectedValue) Is Nothing Then
                ddlShowRecords.Items.FindByValue(strSelectedValue).Selected = True
            End If
        End Sub

        Private Sub BindData()
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)


            If ColorCodingOn Then
                chkColorCoding.Checked = True
            Else
                chkColorCoding.Checked = False
            End If

            If ColorCodingLegendOn Then
                pnlLegend.Visible = True
            Else
                pnlLegend.Visible = False
            End If

            Dim intPortalID As Integer = -1
            If Convert.ToInt32(Context.User.Identity.Name) = _portalSettings.SuperUserId Then
                btnClear.Visible = True
                btnDelete.Visible = True
                intPortalID = Int32.Parse(ddlPortalID.SelectedItem.Value)
            Else
                btnClear.Visible = False
                btnDelete.Visible = False
                intPortalID = PortalId
            End If

            pnlSendEmail.Visible = True
            pnlSendServer.Visible = True

            Dim strLogTypeKey As String = ddlLogType.SelectedItem.Value

            Dim objLog As LogInfoArray

            Dim objLogController As New LogController
            If intPortalID = -1 And strLogTypeKey = "*" Then
                objLog = objLogController.GetLog()
            ElseIf intPortalID = -1 And strLogTypeKey <> "*" Then
                objLog = objLogController.GetLog(strLogTypeKey)
            ElseIf intPortalID <> -1 And strLogTypeKey = "*" Then
                objLog = objLogController.GetLog(intPortalID)
            ElseIf intPortalID <> -1 And strLogTypeKey <> "*" Then
                objLog = objLogController.GetLog(intPortalID, strLogTypeKey)
            Else
                objLog = objLogController.GetLog(strLogTypeKey)
            End If

            BindShowRecords(objLog.Count)

            Dim MinRec, MaxRec As Integer
            If ddlShowRecords.SelectedItem Is Nothing Then
                MinRec = 1
                If objLog.Count < 100 Then
                    MaxRec = objLog.Count - 1
                Else
                    MaxRec = 100
                End If

            ElseIf ddlShowRecords.SelectedItem.Value = "*" Then
                MinRec = 1
                MaxRec = MinRec + objLog.Count
            Else
                MinRec = Convert.ToInt32(ddlShowRecords.SelectedItem.Value)
                If MinRec = 1000 Then
                    MaxRec = Int32.MaxValue
                Else
                    If objLog.Count - MinRec < 100 Then
                        MaxRec = MinRec + (objLog.Count - MinRec) + 1
                    Else
                        MaxRec = MinRec + 100
                    End If

                End If
            End If


            If objLog.Count > 0 Then
                txtShowing.Text = "Showing " + MinRec.ToString + " to " + (MaxRec - 1).ToString + " of " + objLog.Count.ToString
                Dim b As New LogInfoArray
                Dim myEnumerator As System.Collections.IEnumerator
                myEnumerator = objLog.GetEnumerator(MinRec - 1, MaxRec - MinRec)

                While myEnumerator.MoveNext
                    b.Add(CType(myEnumerator.Current, LogInfo))
                End While
                objLog = b

                dlLog.Visible = True
                pnlSendExceptions.Visible = True
                If Convert.ToInt32(Context.User.Identity.Name) = _portalSettings.SuperUserId Then
                    btnDelete.Visible = True
                    btnClear.Visible = True
                End If
                pnlOptions.Visible = True
                tblInstructions.Visible = True
                dlLog.DataSource = objLog
                dlLog.DataBind()
            Else
                Skin.AddModuleMessage(Me, "There are no log entries.", Skins.ModuleMessage.ModuleMessageType.YellowWarning)
                dlLog.Visible = False
                pnlSendExceptions.Visible = False
                btnDelete.Visible = False
                btnClear.Visible = False
                pnlLegend.Visible = False
                tblInstructions.Visible = False
            End If



        End Sub

        Public Function GetPropertiesText(ByVal obj As Object) As String

            Dim objLogInfo As LogInfo = CType(obj, LogInfo)

            Dim objLogProperties As LogProperties = objLogInfo.LogProperties
            Dim str As New System.Text.StringBuilder

            Dim i As Integer
            For i = 0 To objLogProperties.Count - 1
                ' display the values in the Panel child controls.
                Dim ldi As LogDetailInfo = CType(objLogProperties(i), LogDetailInfo)
                str.Append("<b>" + ldi.PropertyName + "</b>: " + Server.HtmlEncode(ldi.PropertyValue) + "<br>")
            Next
            Return str.ToString
        End Function

        Private Sub ddlPortalID_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddlPortalID.SelectedIndexChanged
            BindData()
        End Sub
        Private Sub ddlLogType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddlLogType.SelectedIndexChanged
            BindData()
        End Sub

        Protected Function GetMyLogType(ByVal LogTypeKey As String) As LogTypeInfo
            Dim objLogTypeInfo As LogTypeInfo
            If Not htLogTypeInfo(LogTypeKey) Is Nothing Then
                objLogTypeInfo = CType(htLogTypeInfo(LogTypeKey), LogTypeInfo)
                If Not ColorCodingOn Then
                    objLogTypeInfo.LogTypeCSSClass = "Normal"
                End If
                Return objLogTypeInfo
            Else
                Return New LogTypeInfo
            End If
        End Function
        Private Sub chkColorCoding_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkColorCoding.CheckedChanged
            Dim objPersonalization As New Personalization
            Dim i As Integer
            If chkColorCoding.Checked Then
                i = 1
                ColorCodingOn = True
                ColorCodingLegendOn = True
                objPersonalization.SetProfile("LogViewer", "ColorCodingLegend", "1")
            Else
                i = 0
                ColorCodingOn = False
                ColorCodingLegendOn = False
            End If
            objPersonalization.SetProfile("LogViewer", "ColorCoding", i)
            BindData()
        End Sub

        Private Sub minLegend_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles minLegend.Click
            Dim objPersonalization As New Personalization
            objPersonalization.SetProfile("LogViewer", "ColorCodingLegend", "0")
            ColorCodingLegendOn = False
            pnlLegend.Visible = False
            BindData()
        End Sub

        Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
            Dim objLoggingController As New LogController
            objLoggingController.ClearLog()
            Skin.AddModuleMessage(Me, "The log has been cleared.", Skins.ModuleMessage.ModuleMessageType.GreenSuccess)
            BindPortalDropDown()
            dlLog.Visible = False
            pnlSendExceptions.Visible = False
            btnDelete.Visible = False
            btnClear.Visible = False
            pnlOptions.Visible = False
            pnlLegend.Visible = False
            tblInstructions.Visible = False
        End Sub
        Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
            DeleteSelectedExceptions()
        End Sub

        Private Function DeleteSelectedExceptions() As String
            Try
                Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)
                Dim strXMLOut As New System.Text.StringBuilder
                Dim s As String = Request.Form("Exception")
                If Not s Is Nothing Then
                    Dim arrExcPositions() As String
                    If s.LastIndexOf(",") > 0 Then
                        arrExcPositions = s.Split(Convert.ToChar(","))
                    ElseIf s.Length > 0 Then
                        ReDim arrExcPositions(0)
                        arrExcPositions(0) = s
                    End If


                    Dim objLoggingController As New LogController



                    Dim i As Integer
                    Dim j As Integer = arrExcPositions.Length()
                    For i = 1 To arrExcPositions.Length
                        j -= 1
                        Dim excKey() As String
                        excKey = arrExcPositions(j).Split(Convert.ToChar("|"))
                        Dim objLogInfo As New LogInfo
                        objLogInfo.LogGUID = excKey(0)
                        objLogInfo.LogFileID = excKey(1)
                        objLoggingController.DeleteLog(objLogInfo)
                    Next
                    Skin.AddModuleMessage(Me, "The selected exceptions were successfully deleted.", Skins.ModuleMessage.ModuleMessageType.GreenSuccess)
                End If
                BindPortalDropDown()
                BindData()
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

        Private Sub ddlShowRecords_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddlShowRecords.SelectedIndexChanged
            BindData()
        End Sub

        Protected Sub btnEmail_Clicked(ByVal Sender As Object, ByVal e As EventArgs) Handles btnEmail.Click
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim strEmail As String = GetSelectedExceptions().OuterXml
            Dim strFromEmailAddress As String
            Dim _userController As New UserController
            Dim _userInfo As UserInfo
            _userInfo = _userController.GetUser(_portalSettings.PortalId, CType(HttpContext.Current.User.Identity.Name, Integer))
            If _userInfo.Email <> "" Then
                strFromEmailAddress = _userInfo.Email
            Else
                strFromEmailAddress = _portalSettings.Email
            End If
            Dim ReturnMsg As String = SendNotification(strFromEmailAddress, txtEmailAddress.Text, "", _portalSettings.PortalName & " Exceptions", Server.HtmlEncode(txtMessage.Text + vbCrLf + strEmail.ToString), "", "html")

            If ReturnMsg = "" Then
                pnlSendEmail.Visible = False
                Skin.AddModuleMessage(Me, "Your email has been sent.", Skins.ModuleMessage.ModuleMessageType.GreenSuccess)
            Else
                pnlSendExceptions.Visible = False
                Skin.AddModuleMessage(Me, "Your email has <b>not</b> been sent.  " + ReturnMsg, Skins.ModuleMessage.ModuleMessageType.RedError)
            End If
            BindData()
        End Sub

        Private Sub btnServerSendToDNN_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnServerSendToDNN.ServerClick
            Try
                Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

                Dim xmlDoc As New XmlDocument
                xmlDoc = GetSelectedExceptions()

                Dim strXMLOut As New System.Text.StringBuilder

                strXMLOut.Append("<exceptions>")
                Dim xEl As XmlElement

                Dim xmlNode As xmlNode
                For Each xmlNode In xmlDoc.SelectNodes("/LogEntries/log")
                    Dim submissionInfo As XmlElement
                    submissionInfo = xmlDoc.CreateElement("SubmissionDetails")
                    Dim emailNode As XmlElement
                    emailNode = xmlDoc.CreateElement("EmailAddress")
                    Dim emailInfo As XmlCDataSection = xmlDoc.CreateCDataSection(txtServerSendDNNEmail.Text)
                    emailNode.AppendChild(emailInfo)
                    submissionInfo.AppendChild(emailNode)
                    Dim messageNode As XmlElement
                    messageNode = xmlDoc.CreateElement("Comments")
                    Dim messageInfo As XmlCDataSection = xmlDoc.CreateCDataSection(txtServerSendDNNMessage.Text)
                    messageNode.AppendChild(messageInfo)
                    submissionInfo.AppendChild(messageNode)
                    xEl.AppendChild(submissionInfo)
                    strXMLOut.Append(xEl.OuterXml)
                Next
                strXMLOut.Append("</exceptions>")

                Dim RedirectURL As String

                Dim x As New DotNetNuke.WebServices.ExceptionsReceiver
                RedirectURL = x.SendExceptions(xmlDoc.OuterXml)
                Try
                    Response.Redirect(RedirectURL, True)
                Catch exc As ArgumentNullException
                    ProcessModuleLoadException("The web service at DotNetNuke.com is currently unavailable.", Me, exc)
                End Try

            Catch exc As WebException
                ProcessModuleLoadException("The web service at DotNetNuke.com is currently unavailable.", Me, exc)
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub

        Private Function GetSelectedExceptions() As XmlDocument
            Try
                Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)
                Dim strXMLOut As New System.Text.StringBuilder
                Dim s As String = Request.Form("Exception")
                If Not s Is Nothing Then
                    Dim arrExcPositions() As String
                    If s.LastIndexOf(",") > 0 Then
                        arrExcPositions = s.Split(Convert.ToChar(","))
                    ElseIf s.Length > 0 Then
                        ReDim arrExcPositions(0)
                        arrExcPositions(0) = s
                    End If


                    Dim objLoggingController As New LogController

                    Dim objXML As New XmlDocument
                    objXML.LoadXml("<LogEntries></LogEntries>")

                    Dim i As Integer
                    Dim j As Integer = arrExcPositions.Length()
                    For i = 1 To arrExcPositions.Length
                        j -= 1
                        Dim excKey() As String
                        excKey = arrExcPositions(j).Split(Convert.ToChar("|"))
                        Dim objLogInfo As New LogInfo
                        objLogInfo.LogGUID = excKey(0)
                        objLogInfo.LogFileID = excKey(1)
                        Dim objNode As XmlNode
                        objNode = objXML.ImportNode(CType(objLoggingController.GetSingleLog(objLogInfo, LoggingProvider.ReturnType.XML), XmlNode), True)
                        objXML.DocumentElement.AppendChild(objNode)
                    Next
                    Return objXML
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

    End Class

    Public Class LogTypeSortFriendlyName
        Implements System.Collections.IComparer


        Public Function Compare(ByVal x As Object, ByVal y As Object) As Integer Implements System.Collections.IComparer.Compare
            Return CType(x, LogTypeInfo).LogTypeFriendlyName.CompareTo(CType(y, LogTypeInfo).LogTypeFriendlyName)
        End Function
    End Class

    Public Class PortalSortTitle
        Implements System.Collections.IComparer


        Public Function Compare(ByVal x As Object, ByVal y As Object) As Integer Implements System.Collections.IComparer.Compare
            Return CType(x, PortalInfo).PortalName.CompareTo(CType(y, PortalInfo).PortalName)
        End Function
    End Class

End Namespace
