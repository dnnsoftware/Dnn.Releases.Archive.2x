'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Web.Security

Namespace DotNetNuke

    Public MustInherit Class Signin
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents txtUsername As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtPassword As System.Web.UI.WebControls.TextBox
        Protected WithEvents rowVerification1 As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents rowVerification2 As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents txtVerification As System.Web.UI.WebControls.TextBox
        Protected WithEvents chkCookie As System.Web.UI.WebControls.CheckBox
        Protected WithEvents cmdLogin As System.Web.UI.WebControls.ImageButton
        Protected WithEvents cmdRegister As System.Web.UI.WebControls.ImageButton
        Protected WithEvents cmdSendPassword As System.Web.UI.WebControls.ImageButton
        Protected WithEvents lblLogin As System.Web.UI.WebControls.Label
        Private ipAddress As String

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            If Not HttpContext.Current.Request.UserHostAddress Is Nothing Then
                ipAddress = HttpContext.Current.Request.UserHostAddress
            End If

            If _portalSettings.UserRegistration = 0 Then
                cmdRegister.Visible = False
            End If

            txtPassword.Attributes.Add("value", txtPassword.Text)

            If Page.IsPostBack = False Then
                Try
                    SetFormFocus(txtUsername)
                Catch
                    'control not there or error setting focus
                End Try
            End If

            Dim objSystemMessages As New SystemMessageController
            lblLogin.Text = objSystemMessages.FormatSystemMessage(PortalId, "MESSAGE_LOGIN_INSTRUCTIONS", UserId)

        End Sub

        Private Sub cmdLogin_Click(ByVal sender As Object, ByVal e As ImageClickEventArgs) Handles cmdLogin.Click

            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim objUsers As New UserController
            Dim objSecurity As New PortalSecurity()

            Dim blnLogin As Boolean = True

            If _portalSettings.UserRegistration = 3 Then ' verified
                Dim objUser As UserInfo = objUsers.GetUserByUsername(_portalSettings.PortalId, txtUsername.Text)
                'If Not objUser.UserID = -1 Then
                If Not objUser Is Nothing Then
                    If objUser.LastLoginDate = Date.MinValue And objUser.IsSuperUser = False Then
                        blnLogin = False
                        If rowVerification1.Visible Then
                            If txtVerification.Text <> "" Then
                                If txtVerification.Text = (_portalSettings.PortalId.ToString & "-" & objUser.UserID) Then
                                    ' set the authorization bit and login time in the userportals table
                                    DataProvider.Instance().UpdatePortalUser(_portalSettings.PortalId, objUser.UserID, True, Now)
                                    blnLogin = True
                                Else
                                    Skin.AddModuleMessage(Me, "Invalid Verification Code", Skins.ModuleMessage.ModuleMessageType.RedError)
                                End If
                            Else
                                Skin.AddModuleMessage(Me, "Enter Your Verification Code", Skins.ModuleMessage.ModuleMessageType.GreenSuccess)
                            End If
                        Else
                            rowVerification1.Visible = True
                            rowVerification2.Visible = True
                        End If
                    End If
                End If
            End If

            If blnLogin Then
                ' Attempt to Validate User Credentials
                Dim userId As Integer = objSecurity.UserLogin(txtUsername.Text, txtPassword.Text, _portalSettings.PortalId)

                If userId >= 0 Then
                    ' Use security system to set the UserID within a client-side Cookie
                    FormsAuthentication.SetAuthCookie(Convert.ToString(userId), chkCookie.Checked)

                    Dim objEventLog As New Logging.EventLogController
                    Dim objUser As UserInfo = objUsers.GetUser(_portalSettings.PortalId, userId)

                    Dim objEventLogInfo As New Logging.EventLogInfo
                    objEventLogInfo.AddProperty("IP", ipAddress)
                    objEventLogInfo.LogPortalID = _portalSettings.PortalId
                    objEventLogInfo.LogPortalName = _portalSettings.PortalName
                    objEventLogInfo.LogUserID = userId
                    objEventLogInfo.LogUserName = txtUsername.Text
                    If objUser.IsSuperUser Then
                        objEventLogInfo.LogTypeKey = "LOGIN_SUPERUSER"
                        objEventLog.AddLog(objEventLogInfo)
                    Else
                        objEventLogInfo.LogTypeKey = "LOGIN_SUCCESS"
                        objEventLog.AddLog(objEventLogInfo)
                    End If
                    ' redirect browser - override is used if the user defined login tab has no signin control
                    If _portalSettings.HomeTabId <> -1 And Request.QueryString("override") Is Nothing Then
                        ' user defined tab
                        Response.Redirect("~/" & glbDefaultPage & "?tabid=" & _portalSettings.HomeTabId.ToString, True)
                    Else
                        ' admin tab
                        Response.Redirect("~/" & glbDefaultPage & "?tabid=" & _portalSettings.ActiveTab.TabId.ToString, True)
                    End If
                Else
                    Skin.AddModuleMessage(Me, "Login Failed", Skins.ModuleMessage.ModuleMessageType.RedError)

                    Dim objEventLog As New Logging.EventLogController
                    Dim objEventLogInfo As New Logging.EventLogInfo
                    objEventLogInfo.AddProperty("IP", ipAddress)
                    objEventLogInfo.LogPortalID = _portalSettings.PortalId
                    objEventLogInfo.LogPortalName = _portalSettings.PortalName
                    objEventLogInfo.LogUserID = userId
                    objEventLogInfo.LogUserName = txtUsername.Text
                    objEventLogInfo.LogTypeKey = "LOGIN_FAILURE"
                    objEventLog.AddLog(objEventLogInfo)
                End If
            End If

        End Sub

        Private Sub cmdSendPassword_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmdSendPassword.Click

            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            If Trim(txtUsername.Text) <> "" Then
                Dim objUsers As New UserController
                Dim objSecurity As New PortalSecurity()

                Dim objUser As UserInfo = objUsers.GetUserByUsername(_portalSettings.PortalId, txtUsername.Text)

                If Not objUser Is Nothing Then

                    Dim objSystemMessages As New SystemMessageController
                    SendNotification(_portalSettings.Email, objUser.Email, "", objSystemMessages.FormatSystemMessage(PortalId, "EMAIL_PASSWORD_REMINDER_SUBJECT", objUser.UserID), objSystemMessages.FormatSystemMessage(PortalId, "EMAIL_PASSWORD_REMINDER_BODY", objUser.UserID))

                    Skin.AddModuleMessage(Me, "Password Has Been Sent To<br>Your Email Address.", Skins.ModuleMessage.ModuleMessageType.GreenSuccess)
                    Dim objEventLog As New Logging.EventLogController
                    Dim objEventLogInfo As New Logging.EventLogInfo
                    objEventLogInfo.AddProperty("IP", ipAddress)
                    objEventLogInfo.LogPortalID = _portalSettings.PortalId
                    objEventLogInfo.LogPortalName = _portalSettings.PortalName
                    objEventLogInfo.LogUserID = UserId
                    objEventLogInfo.LogUserName = txtUsername.Text
                    objEventLogInfo.LogTypeKey = "PASSWORD_SENT_SUCCESS"
                    objEventLog.AddLog(objEventLogInfo)
                Else
                    Dim objEventLog As New Logging.EventLogController
                    Dim objEventLogInfo As New Logging.EventLogInfo
                    objEventLogInfo.AddProperty("IP", ipAddress)
                    objEventLogInfo.LogPortalID = _portalSettings.PortalId
                    objEventLogInfo.LogPortalName = _portalSettings.PortalName
                    objEventLogInfo.LogUserID = UserId
                    objEventLogInfo.LogUserName = txtUsername.Text
                    objEventLogInfo.LogTypeKey = "PASSWORD_SENT_FAILURE"
                    objEventLog.AddLog(objEventLogInfo)
                    Skin.AddModuleMessage(Me, "Username Does Not Exist", Skins.ModuleMessage.ModuleMessageType.RedError)
                End If

            Else
                Skin.AddModuleMessage(Me, "Please Enter Your Username", Skins.ModuleMessage.ModuleMessageType.RedError)
            End If

        End Sub

        Private Sub cmdRegister_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmdRegister.Click
            If PortalSettings.UserTabId <> -1 Then
                ' user defined tab
                Response.Redirect("~/" & glbDefaultPage & "?tabid=" & PortalSettings.UserTabId.ToString, True)
            Else
                ' admin tab
                Response.Redirect("~/" & glbDefaultPage & "?tabid=" & PortalSettings.ActiveTab.TabId & "&ctl=Register", True)
            End If
        End Sub

    End Class

End Namespace
