'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public Class EditFAQs
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents QuestionField As System.Web.UI.WebControls.TextBox
        Protected WithEvents AnswerField As System.Web.UI.WebControls.TextBox
        '<JPW bug=#151 type=add comment=added a RequiredFieldValidator for QuestionField>
        Protected WithEvents valQuestionField As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents valAnswerField As System.Web.UI.WebControls.RequiredFieldValidator
        '</JPW>
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton
        Protected WithEvents pnlAudit As System.Web.UI.WebControls.Panel
        Protected WithEvents CreatedBy As System.Web.UI.WebControls.Label
        Protected WithEvents CreatedDate As System.Web.UI.WebControls.Label

        Private ItemId As Integer = -1


#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this page is used
        ' to populate the role information for the page
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                ' Determine ItemId of Contacts to Update
                If Not (Request.Params("ItemId") Is Nothing) Then
                    ItemId = Int32.Parse(Request.Params("ItemId"))
                End If

                ' If this is the first visit to the page, bind the role data to the datalist
                If Page.IsPostBack = False Then

                    cmdDelete.Attributes.Add("onClick", "javascript:return confirm('Are You Sure You Wish To Delete This Item ?');")

                    If ItemId <> -1 Then

                        ' Obtain a single row of FAQ information
                        Dim objFAQs As New FAQsController
                        Dim objFAQ As FAQsInfo = objFAQs.GetFAQ(ItemId, ModuleId)

                        ' Read first row from database
                        If Not objFAQ Is Nothing Then
                            QuestionField.Text = Server.HtmlDecode(Replace(CType(objFAQ.Question, String), "<br>", vbCrLf))
                            AnswerField.Text = Server.HtmlDecode(Replace(CType(objFAQ.Answer, String), "<br>", vbCrLf))
                            CreatedBy.Text = objFAQ.CreatedByUser
                            CreatedDate.Text = objFAQ.CreatedDate.ToString



                        Else ' security violation attempt to access item not related to this Module

                            Response.Redirect(NavigateURL(), True)
                        End If

                    Else
                        cmdDelete.Visible = False
                        pnlAudit.Visible = False
                    End If

                End If
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        '****************************************************************
        '
        ' The cmdUpdate_Click event handler on this Page is used to either
        ' create or update a FAQ.  It  uses the DotNetNuke.FAQsDB()
        ' data component to encapsulate all data functionality.
        '
        '****************************************************************

        Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs)
            Try
                ' Only Update if Entered data is Valid
                If Page.IsValid = True Then

                    Dim objFAQ As New FAQsInfo
                    objFAQ.ItemId = ItemId
                    objFAQ.ModuleId = ModuleId
                    objFAQ.CreatedByUser = Context.User.Identity.Name
                    objFAQ.Question = Replace(Server.HtmlEncode(QuestionField.Text), vbCrLf, "<br>")
                    objFAQ.Answer = Replace(Server.HtmlEncode(AnswerField.Text), vbCrLf, "<br>")

                    ' Create an instance of the FAQsDB component
                    Dim objFAQs As New FAQsController

                    If Null.IsNull(ItemId) Then
                        ' Add the FAQ within the FAQs table
                        objFAQs.AddFAQ(objFAQ)
                    Else
                        ' Update the FAQ within the FAQs table
                        objFAQs.UpdateFAQ(objFAQ)
                    End If

                    ' Redirect back to the portal home page
                    Response.Redirect(NavigateURL(), True)

                End If
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        '****************************************************************
        '
        ' The cmdDelete_Click event handler on this Page is used to delete an
        ' a FAQ.  It  uses the DotNetNuke.FAQsDB()
        ' data component to encapsulate all data functionality.
        '
        '****************************************************************

        Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs)
            Try
                ' Only attempt to delete the item if it is an existing item
                ' (new items will have "ItemId" of -1)
                If Not Null.IsNull(ItemId) Then

                    Dim objFAQs As New FAQsController
                    objFAQs.DeleteFAQ(ItemId)

                End If

                ' Redirect back to the portal home page
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        '****************************************************************
        '
        ' The cmdCancel_Click event handler on this Page is used to cancel
        ' out of the page, and return the user back to the portal home
        ' page.
        '
        '****************************************************************

        Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs)
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

    End Class

End Namespace