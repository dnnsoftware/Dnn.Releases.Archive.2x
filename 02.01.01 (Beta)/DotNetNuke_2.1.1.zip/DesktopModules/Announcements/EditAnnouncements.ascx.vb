'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO

Namespace DotNetNuke

    Public Class EditAnnouncements

        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents txtTitle As System.Web.UI.WebControls.TextBox
        Protected WithEvents chkAddDate As System.Web.UI.WebControls.CheckBox
        Protected WithEvents valTitle As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents txtDescription As System.Web.UI.WebControls.TextBox
        Protected WithEvents valDescription As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents ctlURL As DotNetNuke.URLControl
        Protected WithEvents txtExpires As System.Web.UI.WebControls.TextBox
        Protected WithEvents cmdCalendar As System.Web.UI.WebControls.HyperLink
        Protected WithEvents valExpires As System.Web.UI.WebControls.CompareValidator
        Protected WithEvents txtViewOrder As System.Web.UI.WebControls.TextBox
        Protected WithEvents valViewOrder As System.Web.UI.WebControls.CompareValidator

        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

        Protected WithEvents ctlAudit As DotNetNuke.ModuleAuditControl
        Protected WithEvents ctlTracking As DotNetNuke.URLTrackingControl

        Private itemId As Integer

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '****************************************************************
        '
        ' The Page_Load event on this Page is used to obtain the ModuleId
        ' and ItemId of the announcement to edit.
        '
        ' It then uses the DotNetNuke.AnnouncementsDB() data component
        ' to populate the page's edit controls with the annoucement details.
        '
        '****************************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim objModules As New ModuleController

                ' Determine ItemId of Announcement to Update
                If Not (Request.Params("ItemId") Is Nothing) Then
                    itemId = Int32.Parse(Request.Params("ItemId"))
                Else
                    itemId = Convert.ToInt32(Null.SetNull(itemId))
                End If

                If Page.IsPostBack = False Then

                    cmdDelete.Attributes.Add("onClick", "javascript:return confirm('Are You Sure You Wish To Delete This Item ?');")
                    cmdCalendar.NavigateUrl = AdminDB.InvokePopupCal(txtExpires)

                    If Not Null.IsNull(itemId) Then

                        ' Obtain a single row of announcement information
                        Dim objAnnouncements As New AnnouncementsController
                        Dim objAnnouncement As AnnouncementInfo = objAnnouncements.GetAnnouncement(itemId, ModuleId)

                        ' Load first row 
                        If Not objAnnouncement Is Nothing Then

                            txtTitle.Text = objAnnouncement.Title.ToString
                            txtDescription.Text = objAnnouncement.Description.ToString
                            ctlURL.URL = objAnnouncement.Url
                            If Not Null.IsNull(objAnnouncement.ExpireDate) Then
                                txtExpires.Text = objAnnouncement.ExpireDate.ToShortDateString()
                            End If
                            If Not Null.IsNull(objAnnouncement.ViewOrder) Then
                                txtViewOrder.Text = Convert.ToString(objAnnouncement.ViewOrder)
                            End If

                            ctlAudit.CreatedDate = objAnnouncement.CreatedDate.ToString
                            ctlAudit.CreatedByUser = objAnnouncement.CreatedByUser.ToString

                            ctlTracking.URL = objAnnouncement.Url
                            ctlTracking.ModuleID = ModuleId

                        Else ' security violation attempt to access item not related to this Module
                            Response.Redirect(NavigateURL(), True)
                        End If
                    Else
                        cmdDelete.Visible = False
                        ctlAudit.Visible = False
                        ctlTracking.Visible = False
                    End If

                End If
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        '****************************************************************
        '
        ' The cmdUpdate_Click event handler on this Page is used to either
        ' create or update an announcement.  It  uses the DotNetNuke.AnnouncementsDB()
        ' data component to encapsulate all data functionality.
        '
        '****************************************************************

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                Dim strLink As String
                ' Only Update if the Entered Data is Valid
                If Page.IsValid = True Then

                    Dim objAnnouncement As New AnnouncementInfo

                    objAnnouncement = CType(CBO.InitializeObject(objAnnouncement, GetType(AnnouncementInfo)), AnnouncementInfo)

                    'bind text values to object
                    objAnnouncement.ItemId = itemId
                    objAnnouncement.ModuleId = ModuleId
                    objAnnouncement.CreatedByUser = Context.User.Identity.Name
                    objAnnouncement.Title = txtTitle.Text
                    If chkAddDate.Checked Then
                        objAnnouncement.Title += " - " & Now.ToLongDateString
                    End If
                    objAnnouncement.Description = txtDescription.Text
                    objAnnouncement.Url = ctlURL.URL
                    objAnnouncement.Syndicate = False
                    If txtViewOrder.Text <> "" Then
                        objAnnouncement.ViewOrder = Convert.ToInt32(txtViewOrder.Text)
                    End If
                    If txtExpires.Text <> "" Then
                        objAnnouncement.ExpireDate = Convert.ToDateTime(txtExpires.Text)
                    End If

                    Dim objAnnouncements As New AnnouncementsController
                    If Null.IsNull(itemId) Then
                        objAnnouncements.AddAnnouncement(objAnnouncement)
                    Else
                        objAnnouncements.UpdateAnnouncement(objAnnouncement)
                    End If

                    ' url tracking
                    Dim objUrls As New UrlController
                    objUrls.UpdateUrl(PortalId, ctlURL.URL, ctlURL.UrlType, ctlURL.Log)

                    ' Redirect back to the portal home page
                    Response.Redirect(NavigateURL(), True)

                End If
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        '****************************************************************
        '
        ' The cmdDelete_Click event handler on this Page is used to delete
        ' an announcement.  It  uses the DotNetNuke.AnnouncementsDB()
        ' data component to encapsulate all data functionality.
        '
        '****************************************************************

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
            Try
                If Not Null.IsNull(itemId) Then
                    Dim objAnnouncements As New AnnouncementsController
                    objAnnouncements.DeleteAnnouncement(itemId)
                End If

                ' Redirect back to the portal home page
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        '****************************************************************
        '
        ' The cmdCancel_Click event handler on this Page is used to cancel
        ' out of the page, and return the user back to the portal home
        ' page.
        '
        '****************************************************************

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

    End Class

End Namespace