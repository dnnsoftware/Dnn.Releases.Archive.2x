'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Data
Imports DotNetNuke

Namespace CompanyName.Survey

    Public Class SurveyInfo

        ' local property declarations
        Private _SurveyId As Integer
        Private _ModuleId As Integer
        Private _Question As String
        Private _ViewOrder As Integer
        Private _OptionType As String
        Private _CreatedByUser As String
        Private _CreatedDate As Date
        Private _Votes As Integer

        ' initialization
        Public Sub New()
        End Sub

        ' public properties
        Public Property SurveyId() As Integer
            Get
                Return _SurveyId
            End Get
            Set(ByVal Value As Integer)
                _SurveyId = Value
            End Set
        End Property

        Public Property ModuleId() As Integer
            Get
                Return _ModuleId
            End Get
            Set(ByVal Value As Integer)
                _ModuleId = Value
            End Set
        End Property

        Public Property Question() As String
            Get
                Return _Question
            End Get
            Set(ByVal Value As String)
                _Question = Value
            End Set
        End Property

        Public Property ViewOrder() As Integer
            Get
                Return _ViewOrder
            End Get
            Set(ByVal Value As Integer)
                _ViewOrder = Value
            End Set
        End Property

        Public Property OptionType() As String
            Get
                Return _OptionType
            End Get
            Set(ByVal Value As String)
                _OptionType = Value
            End Set
        End Property

        Public Property CreatedByUser() As String
            Get
                Return _CreatedByUser
            End Get
            Set(ByVal Value As String)
                _CreatedByUser = Value
            End Set
        End Property

        Public Property CreatedDate() As Date
            Get
                Return _CreatedDate
            End Get
            Set(ByVal Value As Date)
                _CreatedDate = Value
            End Set
        End Property

        Public Property Votes() As Integer
            Get
                Return _Votes
            End Get
            Set(ByVal Value As Integer)
                _Votes = Value
            End Set
        End Property

    End Class

    Public Class SurveyController

        Public Function GetSurveys(ByVal ModuleId As Integer) As ArrayList

            Return CBO.FillCollection(DataProvider.Instance().GetSurveys(ModuleId), GetType(SurveyInfo))

        End Function

        Public Function GetSurvey(ByVal SurveyID As Integer, ByVal ModuleId As Integer) As SurveyInfo

            Return CType(CBO.FillObject(DataProvider.Instance().GetSurvey(SurveyID, ModuleId), GetType(SurveyInfo)), SurveyInfo)

        End Function

        Public Sub DeleteSurvey(ByVal SurveyID As Integer)

            DataProvider.Instance().DeleteSurvey(SurveyID)

        End Sub

        Public Function AddSurvey(ByVal objSurvey As SurveyInfo) As Integer

            Return CType(DataProvider.Instance().AddSurvey(objSurvey.ModuleId, objSurvey.Question, objSurvey.ViewOrder, objSurvey.OptionType, objSurvey.CreatedByUser), Integer)

        End Function

        Public Sub UpdateSurvey(ByVal objSurvey As SurveyInfo)

            DataProvider.Instance().UpdateSurvey(objSurvey.SurveyId, objSurvey.Question, objSurvey.ViewOrder, objSurvey.OptionType, objSurvey.CreatedByUser)

        End Sub

    End Class

    Public Class SurveyOptionInfo

        ' local property declarations
        Private _SurveyOptionId As Integer
        Private _SurveyId As Integer
        Private _ViewOrder As Integer
        Private _OptionName As String
        Private _Votes As Integer

        ' initialization
        Public Sub New()
        End Sub

        ' public properties
        Public Property SurveyOptionId() As Integer
            Get
                Return _SurveyOptionId
            End Get
            Set(ByVal Value As Integer)
                _SurveyOptionId = Value
            End Set
        End Property

        Public Property SurveyId() As Integer
            Get
                Return _SurveyId
            End Get
            Set(ByVal Value As Integer)
                _SurveyId = Value
            End Set
        End Property

        Public Property ViewOrder() As Integer
            Get
                Return _ViewOrder
            End Get
            Set(ByVal Value As Integer)
                _ViewOrder = Value
            End Set
        End Property

        Public Property OptionName() As String
            Get
                Return _OptionName
            End Get
            Set(ByVal Value As String)
                _OptionName = Value
            End Set
        End Property

        Public Property Votes() As Integer
            Get
                Return _Votes
            End Get
            Set(ByVal Value As Integer)
                _Votes = Value
            End Set
        End Property

    End Class

    Public Class SurveyOptionController

        Public Function GetSurveyOptions(ByVal SurveyId As Integer) As ArrayList

            Return CBO.FillCollection(DataProvider.Instance().GetSurveyOptions(SurveyId), GetType(SurveyOptionInfo))

        End Function

        Public Sub DeleteSurveyOption(ByVal SurveyOptionID As Integer)

            DataProvider.Instance().DeleteSurveyOption(SurveyOptionID)

        End Sub

        Public Function AddSurveyOption(ByVal objSurveyOption As SurveyOptionInfo) As Integer

            Return CType(DataProvider.Instance().AddSurveyOption(objSurveyOption.SurveyId, objSurveyOption.OptionName, objSurveyOption.ViewOrder), Integer)

        End Function

        Public Sub UpdateSurveyOption(ByVal objSurveyOption As SurveyOptionInfo)

            DataProvider.Instance().UpdateSurveyOption(objSurveyOption.SurveyOptionId, objSurveyOption.OptionName, objSurveyOption.ViewOrder)

        End Sub

        Public Sub AddSurveyResult(ByVal SurveyOptionID As Integer)

            DataProvider.Instance().AddSurveyResult(SurveyOptionID)

        End Sub

    End Class

End Namespace
