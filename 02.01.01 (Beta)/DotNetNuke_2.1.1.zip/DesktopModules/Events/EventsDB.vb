'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data

Namespace DotNetNuke
    Public Class EventInfo
        ' local property declarations
        Private _ItemId As Integer
        Private _ModuleId As Integer
        Private _Description As String
        Private _DateTime As Date
        Private _Title As String
        Private _ExpireDate As Date
        Private _CreatedByUser As String
        Private _CreatedDate As Date
        Private _Every As Integer
        Private _Period As String
        Private _IconFile As String
        Private _AltText As String
        Private _MaxWidth As Integer

        ' initialization
        Public Sub New()
        End Sub

        ' public properties
        Public Property ItemId() As Integer
            Get
                Return _ItemId
            End Get
            Set(ByVal Value As Integer)
                _ItemId = Value
            End Set
        End Property

        Public Property ModuleId() As Integer
            Get
                Return _ModuleId
            End Get
            Set(ByVal Value As Integer)
                _ModuleId = Value
            End Set
        End Property
        Public Property Description() As String
            Get
                Return _Description
            End Get
            Set(ByVal Value As String)
                _Description = Value
            End Set
        End Property
        Public Property DateTime() As Date
            Get
                Return _DateTime
            End Get
            Set(ByVal Value As Date)
                _DateTime = Value
            End Set
        End Property
        Public Property Title() As String
            Get
                Return _Title
            End Get
            Set(ByVal Value As String)
                _Title = Value
            End Set
        End Property
        Public Property ExpireDate() As Date
            Get
                Return _ExpireDate
            End Get
            Set(ByVal Value As Date)
                _ExpireDate = Value
            End Set
        End Property
        Public Property CreatedByUser() As String
            Get
                Return _CreatedByUser
            End Get
            Set(ByVal Value As String)
                _CreatedByUser = Value
            End Set
        End Property

        Public Property CreatedDate() As Date
            Get
                Return _CreatedDate
            End Get
            Set(ByVal Value As Date)
                _CreatedDate = Value
            End Set
        End Property

        Public Property Every() As Integer
            Get
                Return _Every
            End Get
            Set(ByVal Value As Integer)
                _Every = Value
            End Set
        End Property

        Public Property Period() As String
            Get
                Return _Period
            End Get
            Set(ByVal Value As String)
                _Period = Value
            End Set
        End Property

        Public Property IconFile() As String
            Get
                Return _IconFile
            End Get
            Set(ByVal Value As String)
                _IconFile = Value
            End Set
        End Property
        Public Property AltText() As String
            Get
                Return _AltText
            End Get
            Set(ByVal Value As String)
                _AltText = Value
            End Set
        End Property
        Public Property MaxWidth() As Integer
            Get
                Return _MaxWidth
            End Get
            Set(ByVal Value As Integer)
                _MaxWidth = Value
            End Set
        End Property
    End Class
    Public Class EventController

        Public Function GetModuleEvents(ByVal ModuleId As Integer, ByVal StartDate As Date, ByVal EndDate As Date) As ArrayList

            If (Not Null.IsNull(StartDate)) And (Not Null.IsNull(EndDate)) Then

                Return CBO.FillCollection(DataProvider.Instance().GetModuleEventsByDate(ModuleId, StartDate, EndDate), GetType(EventInfo))
            Else

                Return CBO.FillCollection(DataProvider.Instance().GetModuleEvents(ModuleId), GetType(EventInfo))
            End If

        End Function


        Public Function GetModuleEvent(ByVal ItemId As Integer, ByVal ModuleId As Integer) As EventInfo


            Return CType(CBO.FillObject(DataProvider.Instance().GetModuleEvent(ItemId, ModuleId), GetType(EventInfo)), EventInfo)

        End Function


        Public Sub DeleteModuleEvent(ByVal ItemID As Integer)

            DataProvider.Instance().DeleteModuleEvent(ItemID)

        End Sub


        Public Sub AddModuleEvent(ByVal objEvent As EventInfo)

            DataProvider.Instance().AddModuleEvent(objEvent.ModuleId, objEvent.Description, objEvent.DateTime, objEvent.Title, objEvent.ExpireDate, objEvent.CreatedByUser, objEvent.Every, objEvent.Period, objEvent.IconFile, objEvent.AltText)

        End Sub


        Public Sub UpdateModuleEvent(ByVal objEvent As EventInfo)

            DataProvider.Instance().UpdateModuleEvent(objEvent.ItemId, objEvent.Description, objEvent.DateTime, objEvent.Title, objEvent.ExpireDate, objEvent.CreatedByUser, objEvent.Every, objEvent.Period, objEvent.IconFile, objEvent.AltText)

        End Sub

    End Class

End Namespace